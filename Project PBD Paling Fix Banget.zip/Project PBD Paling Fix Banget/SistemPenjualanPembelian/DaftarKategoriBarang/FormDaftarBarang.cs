﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using SistemPenjualanPembelian;

using Microsoft.Reporting.WinForms;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarBarang : Form
    {
        DaftarBarang daftar = new DaftarBarang();
        public FormDaftarBarang()
        {
            InitializeComponent();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahBarang formTambah = new FormTambahBarang(); //coding menampilkan form tambah barang
            formTambah.Owner = this; //means: form Tambah Ownernya adalah Form Daftar Barang
            formTambah.Show(); //form tambah ditampilkan
            this.Enabled = false;

        
        }

        private void buttonUbah_Click(object sender, EventArgs e)
        {
            FormUbahBarang formUbah = new FormUbahBarang(); //coding menampilkan form ubah barang
            formUbah.Owner = this; //means: form Ubah Ownernya adalah Form Daftar Barang
            formUbah.Show(); //form ubah ditampilkan
            this.Enabled = false;
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            FormHapusBarang formHapus = new FormHapusBarang(); //coding menampilkan form hapus barang
            formHapus.Owner = this; //means: form Hapus Ownernya adalah Form Daftar Barang
            formHapus.Show(); //form hapus ditampilkan
            this.Enabled = false;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close(); //keluar dari Form Daftar Barang
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            DaftarBarang daftar = new DaftarBarang();

            string kriteria = "";
            if (comboBoxCari.Text == "Kode Barang") //ketika user memilih combobox dengan value "Kode Barang"
            {
                kriteria = "KodeBarang"; 
            }
            else if (comboBoxCari.Text == "Nama Barang") //ketika user memilih combobox dengan value "Nama Barang"
            {
                kriteria = "Nama";
            }
            else if (comboBoxCari.Text == "Harga Jual") //ketika user memilih combobox dengan value "Harga Jual"
            {
                kriteria = "HargaJual";
            }
            else if (comboBoxCari.Text == "Stok")//ketika user memilih combobox dengan value "Stok"
            {
                kriteria = "Stok";
            }
            else if (comboBoxCari.Text == "Kode Kategori")//ketika user memilih combobox dengan value "Kode Kategori"
            {
                kriteria = "KodeKategori";
            }
            else //ketika user memilih combobox dengan value "Kode Kategori"
            {
               kriteria = "NamaKategori";
            }

            string hasil = daftar.CariData(kriteria, textBoxCari.Text); //method cari data daftar barang

            if (hasil == "sukses")
            {
                dataGridViewBarang.Rows.Clear(); //mengapus row atau baris dari datagridview

                //tampilkan semua isi listBarang di datagridview
                //dengan perulangan dibawah ini, isi dari datagridview isihya sudah ada berupa kodebarang, namabarang, hargajual
                //-, stok, dan nama kategori
                for (int i = 0; i < daftar.JumlahBarang; i++)
                {
                    string kodeBrg = daftar.ListBarang[i].KodeBarang;
                    string namaBrg = daftar.ListBarang[i].NamaBarang;
                    int hrgJual = daftar.ListBarang[i].HargaJual;
                    int stok = daftar.ListBarang[i].GetStok;
                    string kodeKategori = daftar.ListBarang[i].KategoriBarang.KodeKategori;
                    string namaKategori = daftar.ListBarang[i].KategoriBarang.NamaKategori;

                    dataGridViewBarang.Rows.Add(kodeBrg, namaBrg, hrgJual, stok, kodeKategori, namaKategori);
                }
            }
            else
            {
                MessageBox.Show("Gagal mencari data. Pesan kesalahan : " + hasil, "Kesalahan"); //pesan kesalahan kalau gagal menampilkan data
            }

            
        }

        public void FormDaftarBarang_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList; //merubah style combobox menjadi combobox dropdown list

            daftar = new DaftarBarang(); //membuat objek baru daftar barang

            LoadBarang();
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewBarang.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewBarang.Columns.Add("KodeBarang", "Kode Barang");
            dataGridViewBarang.Columns.Add("NamaBarang", "Nama Barang");
            dataGridViewBarang.Columns.Add("HargaJual", "Harga Jual");
            dataGridViewBarang.Columns.Add("Stok", "Stok");
            dataGridViewBarang.Columns.Add("KodeKategori", "Kode Kategori");
            dataGridViewBarang.Columns.Add("NamaKategori", "Nama Kategori");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewBarang.Columns["KodeBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["NamaBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["HargaJual"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["Stok"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["KodeKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["NamaKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            //agar harga jual dan stok rata kanan
            dataGridViewBarang.Columns["HargaJual"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewBarang.Columns["Stok"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //agar harga jual ditampilkan dengan format pemisah ribuan (1000 delimiter)
            dataGridViewBarang.Columns["HargaJual"].DefaultCellStyle.Format = "#,###.,00";
        }

        public void LoadBarang()
        {
            string hasil = daftar.BacaSemuaData(); //memanggil method bacasemuadata

            if (hasil == "sukses")
            {
                FormatDataGrid(); //memanggil method formatdatagrid yang ada di Form Daftar Barang

                dataGridViewBarang.Rows.Clear(); //mengapus row atau baris dari datagridview

                //tampilkan semua isi listBarang di datagridview
                //dengan perulangan dibawah ini, isi dari datagridview isihya sudah ada berupa kodebarang, namabarang, hargajual
                //-, stok, dan nama kategori
                for (int i = 0; i < daftar.JumlahBarang; i++)
                {
                    string kodeBrg = daftar.ListBarang[i].KodeBarang;
                    string namaBrg = daftar.ListBarang[i].NamaBarang;
                    int hrgJual = daftar.ListBarang[i].HargaJual;
                    int stok = daftar.ListBarang[i].GetStok;
                    string kodeKategori = daftar.ListBarang[i].KategoriBarang.KodeKategori;
                    string namaKategori = daftar.ListBarang[i].KategoriBarang.NamaKategori;

                    dataGridViewBarang.Rows.Add(kodeBrg, namaBrg, hrgJual, stok, kodeKategori, namaKategori);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan : " + hasil, "Kesalahan"); //pesan kesalahan kalau gagal menampilkan data
            }
        }
    }
}
