﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarKategoriBarang : Form
    {
        public FormDaftarKategoriBarang()
        {
            InitializeComponent();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahKategoriBarang formTambah = new FormTambahKategoriBarang();
            formTambah.Owner = this;
            formTambah.Show();
            this.Enabled = false;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonUbah_Click(object sender, EventArgs e)
        {
            FormUbahKategoriBarang formUbah = new FormUbahKategoriBarang();
            formUbah.Owner = this;
            formUbah.Show();
            this.Enabled = false;
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            FormHapusKategoriBarang formHapus = new FormHapusKategoriBarang();
            formHapus.Owner = this;
            formHapus.Show();
            this.Enabled = false;
        }

        public void FormDaftarKategoriBarang_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList;

            DaftarKategori daftar = new DaftarKategori ();

            string hasil = daftar.BacaSemuaData();
            if(hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewKategoriBarang.Rows.Clear();

                for (int i = 0; i < daftar.JumlahKategoriBarang; i++)
                {
                    string kodeKategori = daftar.DaftarKategoriBarang[i].KodeKategori;
                    string namaKategori = daftar.DaftarKategoriBarang[i].NamaKategori;

                    dataGridViewKategoriBarang.Rows.Add(kodeKategori, namaKategori);
                }
            }
            else
            {
                dataGridViewKategoriBarang.Rows.Clear();
            }
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            DaftarKategori daftar = new DaftarKategori();

            string kriteria = "";

            if (comboBoxCari.Text == "Kode Kategori")
            {
                kriteria = "KodeKategori";
            }
            else if(comboBoxCari.Text == "Nama Kategori")
            {
                kriteria = "Nama";
            }                                                           

            string hasil = daftar.CariData(kriteria, textBoxCari.Text);

            if(hasil == "sukses")
            {
                dataGridViewKategoriBarang.Rows.Clear();

                for (int i = 0; i < daftar.JumlahKategoriBarang; i++)
                {
                    string kodeKategori = daftar.DaftarKategoriBarang[i].KodeKategori;
                    string namaKategori = daftar.DaftarKategoriBarang[i].NamaKategori;

                    dataGridViewKategoriBarang.Rows.Add(kodeKategori, namaKategori);
                }
            }
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewKategoriBarang.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewKategoriBarang.Columns.Add("KodeKategori", "Kode Kategori");
            dataGridViewKategoriBarang.Columns.Add("NamaKategori", "Nama Kategori");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewKategoriBarang.Columns["KodeKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewKategoriBarang.Columns["NamaKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }
    }
}
