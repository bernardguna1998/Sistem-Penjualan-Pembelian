﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarNotaBeli : Form
    {
        string kriteria = "";
        DaftarNotaBeli daftar;
        public FormDaftarNotaBeli()
        {
            InitializeComponent();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahNotaBeli form = new FormTambahNotaBeli();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void FormDaftarNotaBeli_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList;

            daftar = new DaftarNotaBeli();

            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewDaftarNota.Rows.Clear();

                for (int i = 0; i < daftar.JumlahNotaBeli; i++)
                {
                    string noNota = daftar.ListNotaBeli[i].NoNota;
                    DateTime tgl = daftar.ListNotaBeli[i].Tanggal;
                    int kodeSup = daftar.ListNotaBeli[i].Supplier.KodeSupplier;
                    string namaSup = daftar.ListNotaBeli[i].Supplier.NamaSupplier;
                    string almt = daftar.ListNotaBeli[i].Supplier.Alamat;
                    int kodePeg = daftar.ListNotaBeli[i].Pegawai.KodePegawai;
                    string namaPeg = daftar.ListNotaBeli[i].Pegawai.Nama;

                    dataGridViewDaftarNota.Rows.Add(noNota, tgl.ToString("yyyy-MM-dd"), kodeSup, namaSup, almt, kodePeg, namaPeg);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan : " + hasil, "Kesalahan");
            }
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            daftar = new DaftarNotaBeli();

            if (comboBoxCari.Text == "No Nota")
            {
                kriteria = "n.NoNota";
            }
            else if (comboBoxCari.Text == "Tanggal")
            {
                kriteria = "n.Tanggal";
            }
            else if (comboBoxCari.Text == "Kode Supplier")
            {
                kriteria = "n.KodeSupplier";
            }
            else if (comboBoxCari.Text == "Nama Supplier")
            {
                kriteria = "s.Nama";
            }
            else if (comboBoxCari.Text == "Alamat")
            {
                kriteria = "s.Alamat";
            }
            else if (comboBoxCari.Text == "Kode Pegawai")
            {
                kriteria = "peg.KodePegawai";
            }
            else if (comboBoxCari.Text == "Nama Pegawai")
            {
                kriteria = "peg.Nama";
            }

            string hasil = daftar.CariData(kriteria, textBoxCari.Text);

            if (hasil == "sukses")
            {
                dataGridViewDaftarNota.Rows.Clear();

                for (int i = 0; i < daftar.JumlahNotaBeli; i++)
                {
                    string noNota = daftar.ListNotaBeli[i].NoNota;
                    DateTime tgl = DateTime.Parse(daftar.ListNotaBeli[i].Tanggal.ToString());
                    int kodePlg = daftar.ListNotaBeli[i].Supplier.KodeSupplier;
                    string namaPlg = daftar.ListNotaBeli[i].Supplier.NamaSupplier;
                    string almt = daftar.ListNotaBeli[i].Supplier.Alamat;
                    int kodePeg = daftar.ListNotaBeli[i].Pegawai.KodePegawai;
                    string namaPeg = daftar.ListNotaBeli[i].Pegawai.Nama;

                    dataGridViewDaftarNota.Rows.Add(noNota, tgl, kodePlg, namaPlg, almt, kodePeg, namaPeg);
                }
            }
            else
            {
                MessageBox.Show("Gagal mencari data. Pesan kesalahan : " + hasil, "kesalahan");
            }
        }

        private void FormatDataGrid()
        {
            dataGridViewDaftarNota.Columns.Clear();

            dataGridViewDaftarNota.Columns.Add("NoNota", "No Nota");
            dataGridViewDaftarNota.Columns.Add("Tanggal", "Tanggal");
            dataGridViewDaftarNota.Columns.Add("KodeSupplier", "Kode Supplier");
            dataGridViewDaftarNota.Columns.Add("NamaSupplier", "NamaSupplier");
            dataGridViewDaftarNota.Columns.Add("Alamat", "Alamat");
            dataGridViewDaftarNota.Columns.Add("KodePegawai", "Kode Pegawai");
            dataGridViewDaftarNota.Columns.Add("NamaPegawai", "Nama Pegawai");

            dataGridViewDaftarNota.Columns["NoNota"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["Tanggal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodeSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["Alamat"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodePegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaPegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

        }

        private void buttonCetak_Click(object sender, EventArgs e)
        {
            if (comboBoxCari.Text == "No Nota")
            {
                kriteria = "n.NoNota";
            }
            else if (comboBoxCari.Text == "Tanggal")
            {
                kriteria = "n.Tanggal";
            }
            else if (comboBoxCari.Text == "Kode Supplier")
            {
                kriteria = "n.KodeSupplier";
            }
            else if (comboBoxCari.Text == "Nama Supplier")
            {
                kriteria = "s.Nama";
            }
            else if (comboBoxCari.Text == "Alamat")
            {
                kriteria = "s.Alamat";
            }
            else if (comboBoxCari.Text == "Kode Pegawai")
            {
                kriteria = "peg.KodePegawai";
            }
            else if (comboBoxCari.Text == "Nama Pegawai")
            {
                kriteria = "peg.Nama";
            }

            daftar = new DaftarNotaBeli();

            daftar.CetakNota(kriteria, textBoxCari.Text, "nota_beli.txt");

            MessageBox.Show("Nota beli telah tercetak");
        }
    }
}
