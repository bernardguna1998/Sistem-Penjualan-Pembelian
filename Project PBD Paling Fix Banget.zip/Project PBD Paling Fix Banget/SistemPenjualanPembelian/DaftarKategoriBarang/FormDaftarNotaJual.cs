﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarNotaJual : Form
    {
        string kriteria = "";
        DaftarNotaJual daftar;
        public FormDaftarNotaJual()
        {
            InitializeComponent();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahNotaJual form = new FormTambahNotaJual();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormatDataGrid()
        {
            dataGridViewDaftarNota.Columns.Clear();

            dataGridViewDaftarNota.Columns.Add("NoNota", "No Nota");
            dataGridViewDaftarNota.Columns.Add("Tanggal", "Tanggal");
            dataGridViewDaftarNota.Columns.Add("KodePelanggan", "Kode Pelanggan");
            dataGridViewDaftarNota.Columns.Add("NamaPelanggan", "NamaPelanggan");
            dataGridViewDaftarNota.Columns.Add("AlamatPelanggan", "Alamat Pelanggan");
            dataGridViewDaftarNota.Columns.Add("KodePegawai", "Kode Pegawai");
            dataGridViewDaftarNota.Columns.Add("NamaPegawai", "Nama Pegawai");

            dataGridViewDaftarNota.Columns["NoNota"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["Tanggal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodePelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["AlamatPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodePegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaPegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

        }

        public void FormDaftarNotaJual_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList;
            this.dataGridViewDaftarNota.DefaultCellStyle.ForeColor = Color.Black;
            daftar = new DaftarNotaJual();

            string hasil = daftar.BacaSemuaData();

            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewDaftarNota.Rows.Clear();

                //tampilkan semua isi listBarang di datagridview
                for (int i = 0; i < daftar.JumlahNotaJual; i++)
                {
                    string noNota = daftar.ListNotaJual[i].NoNota;

                    string tgl = daftar.ListNotaJual[i].Tanggal.ToString("yyyy-MM-dd");

                    int kodePelanggan = daftar.ListNotaJual[i].Pelanggan.KodePelanggan;

                    string namaPelanggan = daftar.ListNotaJual[i].Pelanggan.NamaPelanggan;

                    string alamatPelanggan = daftar.ListNotaJual[i].Pelanggan.Alamat;

                    int kodePegawai = daftar.ListNotaJual[i].Pegawai.KodePegawai;

                    string namaPegawai = daftar.ListNotaJual[i].Pegawai.Nama;

                    dataGridViewDaftarNota.Rows.Add(noNota, tgl, kodePelanggan, namaPelanggan, alamatPelanggan, kodePegawai, namaPegawai);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan = " + hasil, "Kesalahan");
            }
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            daftar = new DaftarNotaJual();

            if (comboBoxCari.Text == "No Nota")
            {
                kriteria = "n.NoNota";
            }
            else if (comboBoxCari.Text == "Tanggal")
            {
                kriteria = "n.Tanggal";
            }
            else if (comboBoxCari.Text == "Kode Pelanggan")
            {
                kriteria = "n.KodePelanggan";
            }
            else if (comboBoxCari.Text == "Nama Pelanggan")
            {
                kriteria = "plg.Nama";
            }
            else if (comboBoxCari.Text == "Alamat")
            {
                kriteria = "plg.Alamat";
            }
            else if (comboBoxCari.Text == "Kode Pegawai")
            {
                kriteria = "peg.KodePegawai";
            }
            else if (comboBoxCari.Text == "Nama Pegawai")
            {
                kriteria = "peg.Nama";
            }

            string hasil = daftar.CariData(kriteria, textBoxCari.Text);

            if (hasil == "sukses")
            {
                dataGridViewDaftarNota.Rows.Clear();

                for (int i = 0; i < daftar.JumlahNotaJual; i++)
                {
                    string noNota = daftar.ListNotaJual[i].NoNota;
                    DateTime tgl = DateTime.Parse(daftar.ListNotaJual[i].Tanggal.ToString());
                    int kodePlg = daftar.ListNotaJual[i].Pelanggan.KodePelanggan;
                    string namaPlg = daftar.ListNotaJual[i].Pelanggan.NamaPelanggan;
                    string almt = daftar.ListNotaJual[i].Pelanggan.Alamat;
                    int kodePeg = daftar.ListNotaJual[i].Pegawai.KodePegawai;
                    string namaPeg = daftar.ListNotaJual[i].Pegawai.Nama;

                    dataGridViewDaftarNota.Rows.Add(noNota, tgl, kodePlg, namaPlg, almt, kodePeg, namaPeg);
                }
            }
            else
            {
                MessageBox.Show("Gagal mencari data. Pesan kesalahan = " + hasil, "kesalahan");
            }
        }

        private void buttonCetak_Click(object sender, EventArgs e)
        {
            daftar = new DaftarNotaJual();

            daftar.CetakNota(kriteria, textBoxCari.Text, "nota_jual.txt");

            MessageBox.Show("Nota jual telah tercetak");
        }
    }
}
