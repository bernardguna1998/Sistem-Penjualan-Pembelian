﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarPegawai : Form
    {
        public FormDaftarPegawai()
        {
            InitializeComponent();
        }

        public void FormDaftarPegawai_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList;

            DaftarPegawai daftar = new DaftarPegawai();

            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewPegawai.Rows.Clear();

                //tampilkan semua isi listBarang di datagridview
                for (int i = 0; i < daftar.JumlahPegawai; i++)
                {
                    int kodePgw = daftar.ListPegawai[i].KodePegawai;
                    string namaPgw = daftar.ListPegawai[i].Nama;
                    DateTime tglLhr = daftar.ListPegawai[i].TanggalLhr;
                    string tgl = tglLhr.ToString("yyyy-MM-dd");
                    string alamat = daftar.ListPegawai[i].Alamat;
                    int gaji = daftar.ListPegawai[i].Gaji;
                    string username = daftar.ListPegawai[i].Username;
                    string pwd = daftar.ListPegawai[i].Pwd;
                    string idJabatan = daftar.ListPegawai[i].Jabatan.IdJabatan;
                    string namaJabatan = daftar.ListPegawai[i].Jabatan.NamaJabatan;

                    dataGridViewPegawai.Rows.Add(kodePgw, namaPgw, tgl, alamat, gaji, username, pwd, idJabatan, namaJabatan);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan = " + hasil, "Kesalahan");
            }
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            DaftarPegawai daftar = new DaftarPegawai();

            string kriteria = "";

            if (comboBoxCari.Text == "Kode Pegawai")
            {
                kriteria = "KodePegawai";
            }
            else if (comboBoxCari.Text == "Nama")
            {
                kriteria = "Nama";
            }
            else if (comboBoxCari.Text == "Tanggal Lahir")
            {
                kriteria = "TglLahir";
            }
            else if (comboBoxCari.Text == "Alamat")
            {
                kriteria = "Alamat";
            }
            else if (comboBoxCari.Text == "Gaji")
            {
                kriteria = "Gaji";
            }
            else if (comboBoxCari.Text == "Username")
            {
                kriteria = "Username";
            }
            else if (comboBoxCari.Text == "Password")
            {
                kriteria = "Password";

            }
            else if (comboBoxCari.Text == "Id Jabatan")
            {
                kriteria = "IdJabatan";
            }
            else
            {
                kriteria = "NamaJabatan";
            }

            string hasil = daftar.CariData(kriteria, textBoxCari.Text);

            if (hasil == "sukses")
            {
                dataGridViewPegawai.Rows.Clear();

                //tampilkan semua isi listBarang di datagridview
                for (int i = 0; i < daftar.JumlahPegawai; i++)
                {
                    int kodePgw = daftar.ListPegawai[i].KodePegawai;
                    string namaPgw = daftar.ListPegawai[i].Nama;
                    DateTime tglLhr = daftar.ListPegawai[i].TanggalLhr;
                    string tgl = tglLhr.ToString("yyyy-MM-dd");
                    string alamat = daftar.ListPegawai[i].Alamat;
                    int gaji = daftar.ListPegawai[i].Gaji;
                    string username = daftar.ListPegawai[i].Username;
                    string pwd = daftar.ListPegawai[i].Pwd;
                    string idJabatan = daftar.ListPegawai[i].Jabatan.IdJabatan;
                    string namaJabatan = daftar.ListPegawai[i].Jabatan.NamaJabatan;

                    dataGridViewPegawai.Rows.Add(kodePgw, namaPgw, tgl, alamat, gaji, username, pwd, idJabatan, namaJabatan);
                }
            }
            else
            {
                MessageBox.Show("Gagal mencari data. Pesan kesalahan = " + hasil, "Kesalahan");
            }
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahPegawai form = new FormTambahPegawai();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonUbah_Click(object sender, EventArgs e)
        {
            FormUbahPegawai form = new FormUbahPegawai();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            FormHapusPegawai form = new FormHapusPegawai();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewPegawai.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewPegawai.Columns.Add("KodePegawai", "Kode Pegawai");
            dataGridViewPegawai.Columns.Add("Nama", "Nama");
            dataGridViewPegawai.Columns.Add("TglLahir", "Tanggal Lahir");
            dataGridViewPegawai.Columns.Add("Alamat", "Alamat");
            dataGridViewPegawai.Columns.Add("Gaji", "Gaji");
            dataGridViewPegawai.Columns.Add("Username", "Username");
            dataGridViewPegawai.Columns.Add("Password", "Password");
            dataGridViewPegawai.Columns.Add("IdJabatan", "Id Jabatan");
            dataGridViewPegawai.Columns.Add("NamaJabatan", "Nama Jabatan");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewPegawai.Columns["KodePegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Nama"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["TglLahir"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Alamat"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Gaji"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Username"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Password"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["IdJabatan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["NamaJabatan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            //agar harga jual dan stok rata kanan
            dataGridViewPegawai.Columns["Gaji"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //agar harga jual ditampilkan dengan format pemisah ribuan (1000 delimiter)
            dataGridViewPegawai.Columns["Gaji"].DefaultCellStyle.Format = "#,###.,00";
        }
    }
}
