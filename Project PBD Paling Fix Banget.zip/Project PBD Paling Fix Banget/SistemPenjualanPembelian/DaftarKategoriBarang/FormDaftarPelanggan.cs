﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarPelanggan : Form
    {
        public FormDaftarPelanggan()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahPelanggan formTambah = new FormTambahPelanggan();
            formTambah.Owner = this;
            formTambah.Show();
            this.Enabled = false;
        }

        private void buttonUbah_Click(object sender, EventArgs e)
        {
            FormUbahPelanggan formUbah = new FormUbahPelanggan();
            formUbah.Owner = this;
            formUbah.Show();
            this.Enabled = false;
        }

        public void FormDaftarPelanggan_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList;

            DaftarPelanggan daftar = new DaftarPelanggan();

            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewPelanggan.Rows.Clear();

                for(int i=0; i<daftar.JumlahPelanggan;i++)
                {
                    int kodePelanggan = daftar.DaftarInformasiPelanggan[i].KodePelanggan;
                    string namaPelanggan = daftar.DaftarInformasiPelanggan[i].NamaPelanggan;
                    string alamatPelanggan = daftar.DaftarInformasiPelanggan[i].Alamat;
                    string telp = daftar.DaftarInformasiPelanggan[i].Telepon;

                    dataGridViewPelanggan.Rows.Add(kodePelanggan, namaPelanggan, alamatPelanggan, telp);
                }
            }
            else
            {
                dataGridViewPelanggan.Rows.Clear();
            }
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            DaftarPelanggan daftar = new DaftarPelanggan();

            string kriteria = "";
            if (comboBoxCari.Text == "Kode Pelanggan")
            {
                kriteria = "KodePelanggan";
            }
            else if (comboBoxCari.Text == "Nama Pelanggan")
            {
                kriteria = "Nama";
            }
            else if (comboBoxCari.Text == "Alamat Pelanggan")
            {
                kriteria = "Alamat";
            }
            else if (comboBoxCari.Text == "Telepon")
            {
                kriteria = "Telepon";
            }

            string hasil = daftar.CariData(kriteria, textBoxCari.Text);
            if (hasil == "sukses")
            {
                dataGridViewPelanggan.Rows.Clear();

                for (int i = 0; i < daftar.JumlahPelanggan; i++)
                {
                    int kodePelanggan = daftar.DaftarInformasiPelanggan[i].KodePelanggan;
                    string namaPelanggan = daftar.DaftarInformasiPelanggan[i].NamaPelanggan;
                    string alamatPelanggan = daftar.DaftarInformasiPelanggan[i].Alamat;
                    string telp = daftar.DaftarInformasiPelanggan[i].Telepon;

                    dataGridViewPelanggan.Rows.Add(kodePelanggan, namaPelanggan, alamatPelanggan, telp);
                }
            }
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            FormHapusPelanggan formHapus = new FormHapusPelanggan();
            formHapus.Owner = this;
            formHapus.Show();
            this.Enabled = false;
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewPelanggan.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewPelanggan.Columns.Add("KodePelanggan", "Kode Pelanggan");
            dataGridViewPelanggan.Columns.Add("NamaPelanggan", "Nama Pelanggan");
            dataGridViewPelanggan.Columns.Add("AlamatPelanggan", "Alamat Pelanggan");
            dataGridViewPelanggan.Columns.Add("Telepon", "Telepon");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewPelanggan.Columns["KodePelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPelanggan.Columns["NamaPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPelanggan.Columns["AlamatPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPelanggan.Columns["Telepon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }
    }
}
