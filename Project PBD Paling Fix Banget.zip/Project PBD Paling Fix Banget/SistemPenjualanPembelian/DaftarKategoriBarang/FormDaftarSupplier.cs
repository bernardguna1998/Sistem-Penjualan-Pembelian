﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormDaftarSupplier : Form
    {
        public FormDaftarSupplier()
        {
            InitializeComponent();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            FormTambahSupplier form = new FormTambahSupplier();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonUbah_Click(object sender, EventArgs e)
        {
            FormUbahSupplier form = new FormUbahSupplier();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            FormHapusSupplier form = new FormHapusSupplier();
            form.Owner = this;
            form.Show();
            this.Enabled = false;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void FormDaftarSupplier_Load(object sender, EventArgs e)
        {
            comboBoxCari.DropDownStyle = ComboBoxStyle.DropDownList;

            DaftarSupplier daftar = new DaftarSupplier();

            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewSupplier.Rows.Clear();

                for (int i = 0; i < daftar.JumlahSupplier; i++)
                {
                    int kodeSupplier = daftar.ListSupplier[i].KodeSupplier;
                    string namaSupplier = daftar.ListSupplier[i].NamaSupplier;
                    string alamatSupplier = daftar.ListSupplier[i].Alamat;

                    dataGridViewSupplier.Rows.Add(kodeSupplier, namaSupplier, alamatSupplier);
                }
            }
            else
            {
                dataGridViewSupplier.Rows.Clear();
            }
        }

        private void textBoxCari_TextChanged(object sender, EventArgs e)
        {
            DaftarSupplier daftar = new DaftarSupplier();

            string kriteria = "";
            if (comboBoxCari.Text == "Kode Supplier")
            {
                kriteria = "KodeSupplier";
            }
            else if (comboBoxCari.Text == "Nama Supplier")
            {
                kriteria = "Nama";
            }
            else if (comboBoxCari.Text == "Alamat Supplier")
            {
                kriteria = "Alamat";
            }

            string hasil = daftar.CariData(kriteria, textBoxCari.Text);

            if (hasil == "sukses")
            {
                dataGridViewSupplier.Rows.Clear();

                for(int i=0; i<daftar.JumlahSupplier; i++)
                {
                    int kodeSupplier = daftar.ListSupplier[i].KodeSupplier;
                    string namaSupplier = daftar.ListSupplier[i].NamaSupplier;
                    string alamatSupplier = daftar.ListSupplier[i].Alamat;

                    dataGridViewSupplier.Rows.Add(kodeSupplier, namaSupplier, alamatSupplier);
                }
            }
            else
            {
                MessageBox.Show("Gagal mencari data. Pesan kesalahan : " + hasil, "Kesalahan");
            }
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewSupplier.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewSupplier.Columns.Add("KodeSupplier", "Kode Supplier");
            dataGridViewSupplier.Columns.Add("NamaSupplier", "Nama Supplier");
            dataGridViewSupplier.Columns.Add("AlamatSupplier", "Alamat Supplier");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewSupplier.Columns["KodeSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewSupplier.Columns["NamaSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewSupplier.Columns["AlamatSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }
    }
}
