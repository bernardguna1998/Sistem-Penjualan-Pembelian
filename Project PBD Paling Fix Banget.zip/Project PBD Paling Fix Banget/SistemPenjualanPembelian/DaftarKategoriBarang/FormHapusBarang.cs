﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormHapusBarang : Form
    {
        FormDaftarBarang form;
        
        public FormHapusBarang()
        {
            InitializeComponent();
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            
                DialogResult konfirmasi = MessageBox.Show("Data barang akan terhapus. Apakah anda yakin? ", "Konfirmasi", MessageBoxButtons.YesNo);

                if (konfirmasi == System.Windows.Forms.DialogResult.Yes)
                {
                    string kodeKategori = comboBoxKodeKategori.Text.Substring(0, 2); //dimulai dari 0, diambilnya cuman 2
                    string namaKategori = comboBoxKodeKategori.Text.Substring(5, comboBoxKodeKategori.Text.Length - 5);

                    Kategori kat = new Kategori(kodeKategori, namaKategori);

                    Barang b = new Barang(textBoxKodeBarang.Text, textBoxNamaBarang.Text, int.Parse(textBoxHargaJual.Text), int.Parse(textBoxStok.Text), kat);

                    DaftarBarang daftar = new DaftarBarang();

                    string hasil = daftar.HapusData(b);
                    if (hasil == "sukses")
                    {
                        MessageBox.Show("Data telah terhapus", "Info");
                        buttonKosongi_Click(buttonHapus, e);
                    }
                    else
                    {
                        MessageBox.Show("Data gagal dihapus. Pesan kesalahan : " + hasil, "Kesalahan");
                    }
                }
            }
            
        

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeBarang.Clear();
            textBoxNamaBarang.Clear();
            textBoxHargaJual.Clear();
            textBoxStok.Clear();
            comboBoxKodeKategori.SelectedIndex = 0;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarBarang)this.Owner;
            form.FormDaftarBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxKodeBarang_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodeBarang.Text.Length == textBoxKodeBarang.MaxLength)
            {
                DaftarBarang daftar = new DaftarBarang();
                string hasil = daftar.CariData("KodeBarang", textBoxKodeBarang.Text);
                if (hasil == "sukses")
                {
                    if (daftar.JumlahBarang > 0)
                    {
                        textBoxNamaBarang.Text = daftar.ListBarang[0].NamaBarang;
                        textBoxStok.Text = daftar.ListBarang[0].Stok.ToString();
                        comboBoxKodeKategori.Text = daftar.ListBarang[0].KategoriBarang.KodeKategori + " - " + daftar.ListBarang[0].KategoriBarang.NamaKategori;
                        textBoxHargaJual.Text = daftar.ListBarang[0].HargaJual.ToString();

                        textBoxNamaBarang.Enabled = false;
                        textBoxStok.Enabled = false;
                        comboBoxKodeKategori.Enabled = false;
                        textBoxHargaJual.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Kode barang tidak ditemukan. Proses Hapus Data tidak bisa dilakukan.");
                        
                        textBoxHargaJual.Clear();
                        textBoxNamaBarang.Clear();
                        textBoxStok.Clear();
                        textBoxKodeBarang.Clear();
                        comboBoxKodeKategori.SelectedIndex = 0;
                    }


                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }
            else if (textBoxKodeBarang.Text == "")
            {
                textBoxHargaJual.Clear();
                textBoxNamaBarang.Clear();
                textBoxStok.Clear();
                comboBoxKodeKategori.SelectedIndex = 0;
            }
        }

        private void FormHapusBarang_Load(object sender, EventArgs e)
        {
            textBoxKodeBarang.MaxLength = 5;

            textBoxNamaBarang.Enabled = false;
            textBoxStok.Enabled = false;
            textBoxHargaJual.Enabled = false;
            comboBoxKodeKategori.Enabled = false;

            DaftarKategori daftarKat = new DaftarKategori();
            string hasilBaca = daftarKat.BacaSemuaData();

            if (hasilBaca == "sukses")
            {
                comboBoxKodeKategori.Items.Clear();

                for (int i = 0; i < daftarKat.JumlahKategoriBarang; i++)
                {
                    comboBoxKodeKategori.Items.Add(daftarKat.DaftarKategoriBarang[i].KodeKategori + " - " + daftarKat.DaftarKategoriBarang[i].NamaKategori);
                }
            }
            else
            {
                MessageBox.Show("Kategori gagal ditampilkan di comboBox. Pesan kesalahan : " + hasilBaca);
            }

            comboBoxKodeKategori.SelectedIndex = 0;
        }

        private void FormHapusBarang_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarBarang)this.Owner;
            form.FormDaftarBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void panelInputKategori_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
