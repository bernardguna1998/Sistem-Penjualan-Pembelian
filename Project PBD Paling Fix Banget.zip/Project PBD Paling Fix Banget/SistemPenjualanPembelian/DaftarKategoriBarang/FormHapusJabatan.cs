﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormHapusJabatan : Form
    {
        FormDaftarJabatan form;
        
        public FormHapusJabatan()
        {
            InitializeComponent();
        }

        private void FormHapusJabatan_Load(object sender, EventArgs e)
        {
            textBoxIdJabatan.Select();
            textBoxIdJabatan.Focus();
            textBoxIdJabatan.MaxLength = 2;
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            
                DialogResult konfirmasi = MessageBox.Show("Data jabatan akan terhapus. Apakah anda yakin? ", "Konfirmasi", MessageBoxButtons.YesNo);

                if (konfirmasi == System.Windows.Forms.DialogResult.Yes)
                {
                    Jabatan j = new Jabatan(textBoxIdJabatan.Text, textBoxNama.Text);

                    DaftarJabatan daftar = new DaftarJabatan();

                    string hasilHapus = daftar.HapusData(j);

                    if (hasilHapus == "sukses")
                    {
                        MessageBox.Show("Data jabatan berhasil dihapus", "Info");
                        buttonKosongi_Click(buttonSimpan, e);
                    }
                    else
                    {
                        MessageBox.Show("Data jabatan tidak berhasil dihapus. Pesan Kesalahan : " + hasilHapus, " Kesalahan");
                    }
                }
            
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxIdJabatan.Clear();
            textBoxNama.Clear();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarJabatan)this.Owner;
            form.FormDaftarJabatan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxIdJabatan_TextChanged(object sender, EventArgs e)
        {
            if (textBoxIdJabatan.Text.Length == textBoxIdJabatan.MaxLength)
            {
                DaftarJabatan daftar = new DaftarJabatan();
                string hasil = daftar.CariData("IdJabatan", textBoxIdJabatan.Text);
                if (hasil == "sukses")
                {
                    if (daftar.JumlahJabatan > 0)
                    {
                        textBoxNama.Text = daftar.ListJabatan[0].NamaJabatan;
                        textBoxNama.Enabled = false;

                    }
                    else
                    {
                        MessageBox.Show("Id Jabatan tidak ditemukan. Proses hapus data tidak bisa dilakukan");
                        textBoxNama.Text = "";
                        textBoxIdJabatan.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }

            else if (textBoxIdJabatan.Text == "")
            {
                textBoxNama.Clear();
            }
        }

        private void FormHapusJabatan_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarJabatan)this.Owner;
            form.FormDaftarJabatan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }
    }
}
