﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormHapusKategoriBarang : Form
    {
        FormDaftarKategoriBarang form;
        
        public FormHapusKategoriBarang()
        {
            InitializeComponent();
        }

        private void buttonHapus_Click(object sender, EventArgs e)
        {
            
                DialogResult konfirmasi = MessageBox.Show("Data kategori akan terhapus. Apakah anda yakin? ", "Konfirmasi", MessageBoxButtons.YesNo);

                if (konfirmasi == System.Windows.Forms.DialogResult.Yes)
                {
                    Kategori k = new Kategori(textBoxKodeKategori.Text, textBoxNamaKategori.Text);

                    DaftarKategori daftar = new DaftarKategori();

                    string hasilHapus = daftar.HapusData(k);

                    if (hasilHapus == "sukses")
                    {
                        MessageBox.Show("Data kategori berhasil dihapus", "Info");
                        buttonKosongi_Click(buttonHapus, e);
                    }
                    else
                    {
                        MessageBox.Show("Data kategori tidak berhasil dihapus. Pesan Kesalahan : " + hasilHapus, " Kesalahan");
                    }
                }
            
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeKategori.Text = "";
            textBoxNamaKategori.Text = "";
            textBoxKodeKategori.Focus();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarKategoriBarang)this.Owner;
            form.FormDaftarKategoriBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxKodeKategori_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodeKategori.Text.Length == textBoxKodeKategori.MaxLength)
            {
                DaftarKategori daftar = new DaftarKategori();
                string hasil = daftar.CariData("KodeKategori", textBoxKodeKategori.Text);
                if (hasil == "sukses")
                {
                    if (daftar.JumlahKategoriBarang > 0)
                    {
                        textBoxNamaKategori.Text = daftar.DaftarKategoriBarang[0].NamaKategori;
                        textBoxNamaKategori.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Kode kategori tidak ditemukan. Proses hapus data tidak bisa dilakukan");
                        textBoxKodeKategori.Clear();
                        textBoxNamaKategori.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }

            else if (textBoxKodeKategori.Text == "")
            {
                textBoxNamaKategori.Clear();
            }
        }

        private void FormHapusKategoriBarang_Load(object sender, EventArgs e)
        {
            textBoxKodeKategori.MaxLength = 2;

            textBoxNamaKategori.Enabled = false;
        }

        private void FormHapusKategoriBarang_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarKategoriBarang)this.Owner;
            form.FormDaftarKategoriBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }
    }
}
