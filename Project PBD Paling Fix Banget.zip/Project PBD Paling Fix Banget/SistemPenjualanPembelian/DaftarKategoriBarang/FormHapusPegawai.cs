﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormHapusPegawai : Form
    {
        FormDaftarPegawai form;
        
        public FormHapusPegawai()
        {
            InitializeComponent();
        }

        private void FormHapusPegawai_Load(object sender, EventArgs e)
        {
            textBoxKodePegawai.MaxLength = 11;

            //set enabled false
            textBoxGaji.Enabled = false;
            textBoxNamaPegawai.Enabled = false;
            textBoxPwd.Enabled = false;
            textBoxUsername.Enabled = false;
            richTextBoxAlamat.Enabled = false;
            dateTimePickerTglLhr.Enabled = false;
            comboBoxJabatan.Enabled = false;

            DaftarJabatan daftarJ = new DaftarJabatan();

            string hasil = daftarJ.BacaSemuaData();

            if (hasil == "sukses")
            {
                comboBoxJabatan.Items.Clear();

                for (int i = 0; i < daftarJ.JumlahJabatan; i++)
                {
                    comboBoxJabatan.Items.Add(daftarJ.ListJabatan[i].IdJabatan + " - " + daftarJ.ListJabatan[i].NamaJabatan);
                }

                comboBoxJabatan.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Id Jabatan gagal ditampilkan di comboBox. Pesan kesalahan : " + hasil);
            }
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            
                DialogResult konfirmasi = MessageBox.Show("Data barang akan terhapus. Apakah anda yakin? ", "Konfirmasi", MessageBoxButtons.YesNo);

                if (konfirmasi == System.Windows.Forms.DialogResult.Yes)
                {
                    string kodeJab = comboBoxJabatan.Text.Substring(0, 2); //dimulai dari 0, diambilnya cuman 2
                    string namaJab = comboBoxJabatan.Text.Substring(5, comboBoxJabatan.Text.Length - 5);

                    Jabatan j = new Jabatan(kodeJab, namaJab);

                    Pegawai p = new Pegawai(int.Parse(textBoxKodePegawai.Text), textBoxNamaPegawai.Text, dateTimePickerTglLhr.Value, richTextBoxAlamat.Text, int.Parse(textBoxGaji.Text), textBoxUsername.Text, textBoxPwd.Text, j);

                    DaftarPegawai daftar = new DaftarPegawai();

                    string hasil = daftar.HapusData(p);

                    if (hasil == "sukses")
                    {
                        MessageBox.Show("Data telah terhapus", "Info");
                        buttonKosongi_Click(buttonSimpan, e);
                    }
                    else
                    {
                        MessageBox.Show("Data gagal dihapus. Pesan kesalahan : " + hasil, "Kesalahan");
                    }
                }
            
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodePegawai.Clear();
            textBoxNamaPegawai.Clear();
            textBoxPwd.Clear();
            comboBoxJabatan.SelectedIndex = 0;
            textBoxUsername.Clear();
            dateTimePickerTglLhr.Value = DateTime.Now;
            textBoxGaji.Clear();
            richTextBoxAlamat.Clear();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarPegawai)this.Owner;
            form.FormDaftarPegawai_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxKodePegawai_TextChanged(object sender, EventArgs e)
        {

            if (textBoxKodePegawai.Text.Length <= textBoxKodePegawai.MaxLength)
            {
                DaftarPegawai daftar = new DaftarPegawai();

                string hasil = daftar.CariData("KodePegawai", textBoxKodePegawai.Text);

                if (hasil == "sukses")
                {
                    if (textBoxKodePegawai.Text == "")
                    {
                        textBoxNamaPegawai.Clear();
                        textBoxPwd.Clear();
                        comboBoxJabatan.SelectedIndex = 0;
                        textBoxUsername.Clear();
                        dateTimePickerTglLhr.Value = DateTime.Now;
                        textBoxGaji.Clear();
                        richTextBoxAlamat.Clear();
                    }
                    else if (daftar.JumlahPegawai > 0)
                    {
                        textBoxNamaPegawai.Text = daftar.ListPegawai[0].Nama;
                        dateTimePickerTglLhr.Value = DateTime.Parse(daftar.ListPegawai[0].TanggalLahir);
                        richTextBoxAlamat.Text = daftar.ListPegawai[0].Alamat;
                        textBoxUsername.Text = daftar.ListPegawai[0].Username;
                        textBoxPwd.Text = daftar.ListPegawai[0].Pwd;
                        textBoxGaji.Text = daftar.ListPegawai[0].Gaji.ToString();
                        comboBoxJabatan.Text = daftar.ListPegawai[0].Jabatan.IdJabatan + " - " + daftar.ListPegawai[0].Jabatan.NamaJabatan;

                        textBoxNamaPegawai.Enabled = false;
                        dateTimePickerTglLhr.Enabled = false;
                        richTextBoxAlamat.Enabled = false;
                        textBoxUsername.Enabled = false;
                        textBoxPwd.Enabled = false;
                        textBoxGaji.Enabled = false;
                        comboBoxJabatan.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Kode pegawai tidak ditemukan. Proses Hapus Data tidak bisa dilakukan.");
                        textBoxKodePegawai.Clear();
                        textBoxNamaPegawai.Clear();
                        textBoxPwd.Clear();
                        comboBoxJabatan.SelectedIndex = 0;
                        textBoxUsername.Clear();
                        dateTimePickerTglLhr.Value = DateTime.Now;
                        textBoxGaji.Clear();
                        richTextBoxAlamat.Clear();
                    }


                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }
        }

        private void FormHapusPegawai_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarPegawai)this.Owner;
            form.FormDaftarPegawai_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        
    }
}
