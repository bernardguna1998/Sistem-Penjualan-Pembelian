﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormHapusPelanggan : Form
    {
        FormDaftarPelanggan form;
        
        public FormHapusPelanggan()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodePelanggan.Text = "";
            textBoxNamaPelanggan.Text = "";
            textBoxKodePelanggan.Focus();
        }

        private void buttonKeluar_Click_1(object sender, EventArgs e)
        {
            form = (FormDaftarPelanggan)this.Owner;
            form.FormDaftarPelanggan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonHapus_Click_1(object sender, EventArgs e)
        {
                DialogResult konfirmasi = MessageBox.Show("Data pelanggan akan terhapus. Apakah anda yakin? ", "Konfirmasi", MessageBoxButtons.YesNo);

                if (konfirmasi == System.Windows.Forms.DialogResult.Yes)
                {
                    Pelanggan p = new Pelanggan(int.Parse(textBoxKodePelanggan.Text), textBoxNamaPelanggan.Text);

                    DaftarPelanggan daftar = new DaftarPelanggan();

                    string hasilHapus = daftar.HapusData(p);

                    if (hasilHapus == "sukses")
                    {
                        MessageBox.Show("Data pelanggan berhasil dihapus", "Info");
                        buttonKosongi_Click(buttonHapus, e);
                    }
                    else
                    {
                        MessageBox.Show("Data pelanggan tidak berhasil dihapus. Pesan Kesalahan : " + hasilHapus, " Kesalahan");
                    }
                }
            
        }

        private void FormHapusPelanggan_Load(object sender, EventArgs e)
        {
            textBoxKodePelanggan.MaxLength = 11;
            textBoxTelepon.MaxLength = 20;

            //set enabled false
            textBoxAlamat.Enabled = false;
            textBoxNamaPelanggan.Enabled = false;
            textBoxTelepon.Enabled = false;
        }

        private void textBoxKodePelanggan_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodePelanggan.Text.Length <= textBoxKodePelanggan.MaxLength)
            {
                DaftarPelanggan daftar = new DaftarPelanggan();
                string hasil = daftar.CariData("KodePelanggan", textBoxKodePelanggan.Text);
                if (hasil == "sukses")
                {
                    if (textBoxKodePelanggan.Text == "")
                    {
                        textBoxNamaPelanggan.Clear();
                        textBoxTelepon.Clear();
                        textBoxAlamat.Clear();
                    }
                    else if (daftar.JumlahPelanggan > 0)
                    {
                        textBoxNamaPelanggan.Text = daftar.DaftarInformasiPelanggan[0].NamaPelanggan;
                        textBoxAlamat.Text = daftar.DaftarInformasiPelanggan[0].Alamat;
                        textBoxTelepon.Text = daftar.DaftarInformasiPelanggan[0].Telepon;

                        textBoxNamaPelanggan.Enabled = false;
                        textBoxAlamat.Enabled = false;
                        textBoxTelepon.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Kode pelanggan tidak ditemukan. Proses Hapus Data tidak bisa dilakukan.");
                        textBoxKodePelanggan.Clear();
                        textBoxNamaPelanggan.Clear();
                        textBoxTelepon.Clear();
                        textBoxAlamat.Clear();
                    }


                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }
        }

        private void buttonKosongi_Click_1(object sender, EventArgs e)
        {
            textBoxKodePelanggan.Text = "";
            textBoxNamaPelanggan.Text = "";
            textBoxAlamat.Text = "";
            textBoxTelepon.Text = "";
        }

        private void FormHapusPelanggan_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarPelanggan)this.Owner;
            form.FormDaftarPelanggan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }
    }
}
