﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormHapusSupplier : Form
    {
        FormDaftarSupplier form;
        
        public FormHapusSupplier()
        {
            InitializeComponent();
        }

        private void textBoxKodeSupplier_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodeSupplier.Text.Length <= textBoxKodeSupplier.MaxLength)
            {
                DaftarSupplier daftar = new DaftarSupplier();

                string hasil = daftar.CariData("KodeSupplier", textBoxKodeSupplier.Text);

                if (hasil == "sukses")
                {
                    if (daftar.JumlahSupplier > 0)
                    {
                        textBoxNama.Text = daftar.ListSupplier[0].NamaSupplier;
                        richTextBoxAlamat.Text = daftar.ListSupplier[0].Alamat;
                        textBoxNama.Enabled = false;
                        richTextBoxAlamat.Enabled = false;

                    }
                    else
                    {
                        MessageBox.Show("Kode Supplier tidak ditemukan. Proses hapus data tidak bisa dilakukan");
                        textBoxKodeSupplier.Clear();
                        textBoxNama.Text = "";
                        richTextBoxAlamat.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }

                if (textBoxKodeSupplier.Text == "")
                {
                    textBoxNama.Clear();
                    richTextBoxAlamat.Clear();
                }
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarSupplier)this.Owner;
            form.FormDaftarSupplier_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeSupplier.Clear();
            textBoxNama.Clear();
            richTextBoxAlamat.Clear();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Supplier s = new Supplier();
                s.KodeSupplier = int.Parse(textBoxKodeSupplier.Text);
                s.NamaSupplier = textBoxNama.Text;
                s.Alamat = richTextBoxAlamat.Text;

                DaftarSupplier daftar = new DaftarSupplier();

                string hasilTambah = daftar.HapusData(s);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data supplier berhasil dihapus", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data supplier tidak berhasil dihapus. Pesan kesalahan : " + hasilTambah, " Kesalahan");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menghapus data. Pesan kesalahan: " + ex.Message, "Info");
            }
        }

        private void FormHapusSupplier_Load(object sender, EventArgs e)
        {
            textBoxKodeSupplier.MaxLength = 11;

            //set enabled false
            textBoxNama.Enabled = false;
            richTextBoxAlamat.Enabled = false;
        }

        private void FormHapusSupplier_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarSupplier)this.Owner;
            form.FormDaftarSupplier_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }
    }
}
