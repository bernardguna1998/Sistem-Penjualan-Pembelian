﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DaftarKategoriBarang;

namespace SistemPenjualanPembelian
{
    public partial class FormLoadBarcode : Form
    {
        public FormLoadBarcode()
        {
            InitializeComponent();
        }

        private void FormLoadBarcode_Load(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            // set file filter of dialog 
            dlg.Filter = "pdf files (*.pdf) |*.pdf;";
            dlg.ShowDialog();
            if (dlg.FileName != null)
            {
                // use the LoadFile(ByVal fileName As String) function for open the pdf in control
                axAcroPDF1.LoadFile(dlg.FileName);
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
