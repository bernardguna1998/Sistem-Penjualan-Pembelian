﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            this.Height = 50 + panelLogin.Height;

            //beri nilai awal server dan database
            textBoxServer.Text = "localhost";
            textBoxDatabase.Text = "si_jual_beli";
            textBoxUsername.Text = "";
            textBoxPassword.Text = "";
        }

        private void linkLabelPengaturan_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Height = 50 + panelLogin.Height +panelPengaturan.Height;
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            if(textBoxDatabase.Text != "" && textBoxServer.Text != "")
            {
                this.Height = 50 + panelLogin.Height;
            }
            else if(textBoxDatabase.Text == "")
            {
                MessageBox.Show("Nama Database tidak boleh kosong", "Info Kesalahan");
            }
            else if(textBoxServer.Text == "")
            {
                MessageBox.Show("Nama Server tidak boleh kosong", "Info Kesalahan");
            }
            
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if(textBoxUsername.Text != "" && textBoxPassword.Text != "")
            {
                Koneksi k = new Koneksi(textBoxServer.Text, textBoxDatabase.Text, textBoxUsername.Text, textBoxPassword.Text);

                string hasilConnect = k.Connect();

                if(hasilConnect == "sukses")
                {
                    MessageBox.Show("Selamat Datang di Sistem Penjualan Pembelian", "Info");

                    FormUtama frm = (FormUtama)this.Owner;
                    DaftarPegawai daftar = new DaftarPegawai();
                    string hasil = daftar.CariData("username", textBoxUsername.Text);

                    if(hasil == "sukses")
                    {
                        frm.Enabled = true;

                        frm.labelKodePegawai.Text = daftar.ListPegawai[0].KodePegawai.ToString();
                        frm.labelNamaPegawai.Text = daftar.ListPegawai[0].Nama;
                        frm.labelJabatan.Text = daftar.ListPegawai[0].Jabatan.NamaJabatan;

                        PengaturanHakAksesMenu(daftar.ListPegawai[0].Jabatan.NamaJabatan);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Gagal mencari data pegawai. Pesan kesalahan : " + hasil);
                    }
                    //this.Owner.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Koneksi gagal. Pesan Kesalahan : " + hasilConnect, "Kesalahan");
                }
            }
            else if(textBoxUsername.Text == "")
            {
                MessageBox.Show("Username tidak boleh dikosongi", "Info Kesalahan");
            }
            else if(textBoxPassword.Text == "")
            {
                MessageBox.Show("Password tidak boleh dikosongi", "Info Kesalahan");
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PengaturanHakAksesMenu(string jabatan)
        {
            FormUtama frm = (FormUtama)this.Owner;

            if(jabatan == "Kasir")
            {
                frm.masterToolStripMenuItem.Visible = false;
                frm.penjualanToolStripMenuItem.Visible = true;
                frm.pembelianToolStripMenuItem.Visible = false;
                frm.laporanMasterToolStripMenuItem.Visible = false;
                frm.laporanTransaksiPenjualan.Visible = true;
                frm.laporanTransaksiPembelian.Visible = false;
            }
            else if(jabatan == "Pegawai Pembelian")
            {

                frm.masterToolStripMenuItem.Visible = false;
                frm.penjualanToolStripMenuItem.Visible = false;
                frm.pembelianToolStripMenuItem.Visible = true;
                frm.laporanMasterToolStripMenuItem.Visible = false;
                frm.laporanTransaksiPenjualan.Visible = false;
                frm.laporanTransaksiPembelian.Visible = true;
            }
            else if (jabatan == "Manajer")
            {

                frm.masterToolStripMenuItem.Visible = true;
                frm.penjualanToolStripMenuItem.Visible = true;
                frm.pembelianToolStripMenuItem.Visible = true;
                frm.laporanMasterToolStripMenuItem.Visible = true;
                frm.laporanTransaksiPenjualan.Visible = true;
                frm.laporanTransaksiPembelian.Visible = true;
            }
        }

        private void textBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (textBoxUsername.Text == "")
                {
                    MessageBox.Show("Username tidak boleh kosong.");
                }
                else if (textBoxPassword.Text == "")
                {
                    MessageBox.Show("Password tidak boleh kosong.");
                }
                else if (textBoxUsername.Text != "" && textBoxPassword.Text != "")
                {
                    buttonLogin_Click(sender, e);
                }
            }
        }

        private void textBoxUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Jika User menekan Key "Enter" pada keyboard
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (textBoxUsername.Text == "")
                {
                    MessageBox.Show("Username tidak boleh kosong.");
                }
                else if (textBoxPassword.Text == "")
                {
                    MessageBox.Show("Password tidak boleh kosong.");
                }
                else if (textBoxUsername.Text != "" && textBoxPassword.Text != "")
                {
                    //Melakukan perintah sama seperti User mengklik button "Login"
                    buttonLogin_Click(sender, e);
                }
            }
        }
    }
}
