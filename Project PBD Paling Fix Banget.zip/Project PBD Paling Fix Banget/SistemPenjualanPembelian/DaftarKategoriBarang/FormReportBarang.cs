﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemPenjualanPembelian;
using PenjualanPembelian_LIB;
using DaftarKategoriBarang;
using Microsoft.Office.Interop.Excel;


namespace SistemPenjualanPembelian
{
    public partial class FormReportBarang : Form
    {
        FormDaftarBarang form;
        DaftarBarang daftar = new DaftarBarang();
        public FormReportBarang()
        {
            InitializeComponent();
        }

        private void FormReport_Load(object sender, EventArgs e)
        {
            string hasil = daftar.BacaSemuaData(); //memanggil method bacasemuadata

            if (hasil == "sukses")
            {
                FormatDataGrid(); //memanggil method formatdatagrid yang ada di Form Daftar Barang

                dataGridViewBarang.Rows.Clear(); //mengapus row atau baris dari datagridview

                //tampilkan semua isi listBarang di datagridview
                //dengan perulangan dibawah ini, isi dari datagridview isihya sudah ada berupa kodebarang, namabarang, hargajual
                //-, stok, dan nama kategori
                for (int i = 0; i < daftar.JumlahBarang; i++)
                {
                    string kodeBrg = daftar.ListBarang[i].KodeBarang;
                    string namaBrg = daftar.ListBarang[i].NamaBarang;
                    int hrgJual = daftar.ListBarang[i].HargaJual;
                    int stok = daftar.ListBarang[i].GetStok;
                    string kodeKategori = daftar.ListBarang[i].KategoriBarang.KodeKategori;
                    string namaKategori = daftar.ListBarang[i].KategoriBarang.NamaKategori;

                    dataGridViewBarang.Rows.Add(kodeBrg, namaBrg, hrgJual, stok, kodeKategori, namaKategori);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan : " + hasil, "Kesalahan"); //pesan kesalahan kalau gagal menampilkan data
            }

            int jumlah_barang = daftar.HitungJumlahBarang();

            labelJumlah.Text = jumlah_barang.ToString();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewBarang.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewBarang.Columns.Add("KodeBarang", "Kode Barang");
            dataGridViewBarang.Columns.Add("NamaBarang", "Nama Barang");
            dataGridViewBarang.Columns.Add("HargaJual", "Harga Jual");
            dataGridViewBarang.Columns.Add("Stok", "Stok");
            dataGridViewBarang.Columns.Add("KodeKategori", "Kode Kategori");
            dataGridViewBarang.Columns.Add("NamaKategori", "Nama Kategori");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewBarang.Columns["KodeBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["NamaBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["HargaJual"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["Stok"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["KodeKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewBarang.Columns["NamaKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            //agar harga jual dan stok rata kanan
            dataGridViewBarang.Columns["HargaJual"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewBarang.Columns["Stok"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //agar harga jual ditampilkan dengan format pemisah ribuan (1000 delimiter)
            dataGridViewBarang.Columns["HargaJual"].DefaultCellStyle.Format = "#,###.,00";
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewBarang.Width, this.dataGridViewBarang.Height);

            dataGridViewBarang.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewBarang.Width, this.dataGridViewBarang.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "Kode Barang";
            ws.Cells[1, 2] = "Nama Barang";
            ws.Cells[1, 3] = "Harga Jual";
            ws.Cells[1, 4] = "Stok";
            ws.Cells[1, 5] = "Kode Kategori";
            ws.Cells[1, 6] = "Nama Kategori";
            
            for(int j=2; j<= dataGridViewBarang.Rows.Count; j++)
            {
                for(int i=1; i<=6; i++)
                {
                    ws.Cells[j, i] = dataGridViewBarang.Rows[j - 2].Cells[i - 1].Value;
                }
            }

        }
    }
}
