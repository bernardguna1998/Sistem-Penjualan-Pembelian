﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using Microsoft.Office.Interop.Excel;

namespace SistemPenjualanPembelian
{
    public partial class FormReportKategori : Form
    {
        DaftarKategori daftar = new DaftarKategori();
        public FormReportKategori()
        {
            InitializeComponent();
        }

        private void FormReportKategori_Load(object sender, EventArgs e)
        {
            int jumlah = daftar.HitungJumlahKategori();

            labelJumlah.Text = jumlah.ToString();

            string hasil = daftar.BacaSemuaData();

            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewKategori.Rows.Clear();

                for (int i = 0; i < daftar.JumlahKategoriBarang; i++)
                {
                    string kodeKategori = daftar.DaftarKategoriBarang[i].KodeKategori;
                    string namaKategori = daftar.DaftarKategoriBarang[i].NamaKategori;

                    dataGridViewKategori.Rows.Add(kodeKategori, namaKategori);
                }
            }
            else
            {
                dataGridViewKategori.Rows.Clear();
            }

        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewKategori.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewKategori.Columns.Add("KodeKategori", "Kode Kategori");
            dataGridViewKategori.Columns.Add("NamaKategori", "Nama Kategori");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewKategori.Columns["KodeKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewKategori.Columns["NamaKategori"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewKategori.Width, this.dataGridViewKategori.Height);

            dataGridViewKategori.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewKategori.Width, this.dataGridViewKategori.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "Kode Kategori";
            ws.Cells[1, 2] = "Nama Kategori";

            for (int j = 2; j <= dataGridViewKategori.Rows.Count; j++)
            {
                for (int i = 1; i <= 2; i++)
                {
                    ws.Cells[j, i] = dataGridViewKategori.Rows[j - 2].Cells[i - 1].Value;
                }
            }
        }
    }
}
