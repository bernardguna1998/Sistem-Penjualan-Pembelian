﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using Microsoft.Office.Interop.Excel;

namespace SistemPenjualanPembelian
{
    public partial class FormReportPegawai : Form
    {
        DaftarPegawai daftar = new DaftarPegawai();
        public FormReportPegawai()
        {
            InitializeComponent();
        }

        private void FormReportPegawai_Load(object sender, EventArgs e)
        {
            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewPegawai.Rows.Clear();

                //tampilkan semua isi listBarang di datagridview
                for (int i = 0; i < daftar.JumlahPegawai; i++)
                {
                    int kodePgw = daftar.ListPegawai[i].KodePegawai;
                    string namaPgw = daftar.ListPegawai[i].Nama;
                    DateTime tglLhr = daftar.ListPegawai[i].TanggalLhr;
                    string tgl = tglLhr.ToString("yyyy-MM-dd");
                    string alamat = daftar.ListPegawai[i].Alamat;
                    int gaji = daftar.ListPegawai[i].Gaji;
                    string username = daftar.ListPegawai[i].Username;
                    string pwd = daftar.ListPegawai[i].Pwd;
                    string idJabatan = daftar.ListPegawai[i].Jabatan.IdJabatan;
                    string namaJabatan = daftar.ListPegawai[i].Jabatan.NamaJabatan;

                    dataGridViewPegawai.Rows.Add(kodePgw, namaPgw, tgl, alamat, gaji, username, pwd, idJabatan, namaJabatan);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan = " + hasil, "Kesalahan");
            }

            int jumlah = daftar.HitungJumlahPegawai();

            labelJumlah.Text = jumlah.ToString();
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewPegawai.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewPegawai.Columns.Add("KodePegawai", "Kode Pegawai");
            dataGridViewPegawai.Columns.Add("Nama", "Nama");
            dataGridViewPegawai.Columns.Add("TglLahir", "Tanggal Lahir");
            dataGridViewPegawai.Columns.Add("Alamat", "Alamat");
            dataGridViewPegawai.Columns.Add("Gaji", "Gaji");
            dataGridViewPegawai.Columns.Add("Username", "Username");
            dataGridViewPegawai.Columns.Add("Password", "Password");
            dataGridViewPegawai.Columns.Add("IdJabatan", "Id Jabatan");
            dataGridViewPegawai.Columns.Add("NamaJabatan", "Nama Jabatan");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewPegawai.Columns["KodePegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Nama"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["TglLahir"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Alamat"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Gaji"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Username"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["Password"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["IdJabatan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPegawai.Columns["NamaJabatan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            //agar harga jual dan stok rata kanan
            dataGridViewPegawai.Columns["Gaji"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //agar harga jual ditampilkan dengan format pemisah ribuan (1000 delimiter)
            dataGridViewPegawai.Columns["Gaji"].DefaultCellStyle.Format = "#,###.,00";
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewPegawai.Width, this.dataGridViewPegawai.Height);

            dataGridViewPegawai.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewPegawai.Width, this.dataGridViewPegawai.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "Kode Pegawai";
            ws.Cells[1, 2] = "Nama Pegawai";
            ws.Cells[1, 3] = "Tanggal Lahir";
            ws.Cells[1, 4] = "Alamat";
            ws.Cells[1, 5] = "Gaji";
            ws.Cells[1, 6] = "Username";
            ws.Cells[1, 7] = "Password";
            ws.Cells[1, 8] = "Id Jabatan";
            ws.Cells[1, 9] = "Nama Jabatan";

            for (int j = 2; j <= dataGridViewPegawai.Rows.Count; j++)
            {
                for (int i = 1; i <= 9; i++)
                {
                    ws.Cells[j, i] = dataGridViewPegawai.Rows[j - 2].Cells[i - 1].Value;
                }
            }
        }
    }
}
