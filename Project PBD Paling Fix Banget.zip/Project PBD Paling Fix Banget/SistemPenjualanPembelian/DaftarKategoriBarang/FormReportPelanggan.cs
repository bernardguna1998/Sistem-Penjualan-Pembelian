﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using Microsoft.Office.Interop.Excel;

namespace SistemPenjualanPembelian
{
    public partial class FormReportPelanggan : Form
    {
        DaftarPelanggan daftar = new DaftarPelanggan();
        public FormReportPelanggan()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormReportPelanggan_Load(object sender, EventArgs e)
        {
            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewPelanggan.Rows.Clear();

                for (int i = 0; i < daftar.JumlahPelanggan; i++)
                {
                    int kodePelanggan = daftar.DaftarInformasiPelanggan[i].KodePelanggan;
                    string namaPelanggan = daftar.DaftarInformasiPelanggan[i].NamaPelanggan;
                    string alamatPelanggan = daftar.DaftarInformasiPelanggan[i].Alamat;
                    string telp = daftar.DaftarInformasiPelanggan[i].Telepon;

                    dataGridViewPelanggan.Rows.Add(kodePelanggan, namaPelanggan, alamatPelanggan, telp);
                }
            }
            else
            {
                dataGridViewPelanggan.Rows.Clear();
            }

            int jumlah = daftar.HitungJumlahPelanggan();
            labelJumlah.Text = jumlah.ToString();
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewPelanggan.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewPelanggan.Columns.Add("KodePelanggan", "Kode Pelanggan");
            dataGridViewPelanggan.Columns.Add("NamaPelanggan", "Nama Pelanggan");
            dataGridViewPelanggan.Columns.Add("AlamatPelanggan", "Alamat Pelanggan");
            dataGridViewPelanggan.Columns.Add("Telepon", "Telepon");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewPelanggan.Columns["KodePelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPelanggan.Columns["NamaPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPelanggan.Columns["AlamatPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewPelanggan.Columns["Telepon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewPelanggan.Width, this.dataGridViewPelanggan.Height);

            dataGridViewPelanggan.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewPelanggan.Width, this.dataGridViewPelanggan.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "Kode Pelanggan";
            ws.Cells[1, 2] = "Nama Pelanggan";
            ws.Cells[1, 3] = "Alamat";
            ws.Cells[1, 4] = "Telepon";

            for (int j = 2; j <= dataGridViewPelanggan.Rows.Count; j++)
            {
                for (int i = 1; i <= 4; i++)
                {
                    ws.Cells[j, i] = dataGridViewPelanggan.Rows[j - 2].Cells[i - 1].Value;
                }
            }
        }
    }
}
