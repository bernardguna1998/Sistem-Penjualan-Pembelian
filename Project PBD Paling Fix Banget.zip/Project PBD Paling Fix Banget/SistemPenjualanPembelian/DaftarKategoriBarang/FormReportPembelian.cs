﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using Microsoft.Office.Interop.Excel;

namespace SistemPenjualanPembelian
{
    public partial class FormReportPembelian : Form
    {
        DaftarNotaBeli daftar = new DaftarNotaBeli();

        public FormReportPembelian()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormReportPembelian_Load(object sender, EventArgs e)
        {
            int jumlah = daftar.HitungJumlahNotaBeli();
            labelJumlah.Text = jumlah.ToString();

            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewDaftarNota.Rows.Clear();

                for (int i = 0; i < daftar.JumlahNotaBeli; i++)
                {
                    string noNota = daftar.ListNotaBeli[i].NoNota;
                    DateTime tgl = daftar.ListNotaBeli[i].Tanggal;
                    int kodeSup = daftar.ListNotaBeli[i].Supplier.KodeSupplier;
                    string namaSup = daftar.ListNotaBeli[i].Supplier.NamaSupplier;
                    string almt = daftar.ListNotaBeli[i].Supplier.Alamat;
                    int kodePeg = daftar.ListNotaBeli[i].Pegawai.KodePegawai;
                    string namaPeg = daftar.ListNotaBeli[i].Pegawai.Nama;

                    dataGridViewDaftarNota.Rows.Add(noNota, tgl.ToString("yyyy-MM-dd"), kodeSup, namaSup, almt, kodePeg, namaPeg);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan : " + hasil, "Kesalahan");
            }
        }

        private void FormatDataGrid()
        {
            dataGridViewDaftarNota.Columns.Clear();

            dataGridViewDaftarNota.Columns.Add("NoNota", "No Nota");
            dataGridViewDaftarNota.Columns.Add("Tanggal", "Tanggal");
            dataGridViewDaftarNota.Columns.Add("KodeSupplier", "Kode Supplier");
            dataGridViewDaftarNota.Columns.Add("NamaSupplier", "NamaSupplier");
            dataGridViewDaftarNota.Columns.Add("Alamat", "Alamat");
            dataGridViewDaftarNota.Columns.Add("KodePegawai", "Kode Pegawai");
            dataGridViewDaftarNota.Columns.Add("NamaPegawai", "Nama Pegawai");

            dataGridViewDaftarNota.Columns["NoNota"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["Tanggal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodeSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["Alamat"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodePegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaPegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;


        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewDaftarNota.Width, this.dataGridViewDaftarNota.Height);

            dataGridViewDaftarNota.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewDaftarNota.Width, this.dataGridViewDaftarNota.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "No Nota";
            ws.Cells[1, 2] = "Tanggal";
            ws.Cells[1, 3] = "Kode Supplier";
            ws.Cells[1, 4] = "Nama Supplier";
            ws.Cells[1, 5] = "Alamat Supplier";
            ws.Cells[1, 6] = "Kode Pegawai";
            ws.Cells[1, 7] = "Nama Pegawai";

            for (int j = 2; j <= dataGridViewDaftarNota.Rows.Count; j++)
            {
                for (int i = 1; i <= 7; i++)
                {
                    ws.Cells[j, i] = dataGridViewDaftarNota.Rows[j - 2].Cells[i - 1].Value;
                }
            }
        }
    }
}
