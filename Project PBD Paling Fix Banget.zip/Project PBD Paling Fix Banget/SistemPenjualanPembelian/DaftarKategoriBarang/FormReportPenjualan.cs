﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using Microsoft.Office.Interop.Excel;

namespace SistemPenjualanPembelian
{
    public partial class FormReportPenjualan : Form
    {
        DaftarNotaJual daftar = new DaftarNotaJual();

        public FormReportPenjualan()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormReportPenjualan_Load(object sender, EventArgs e)
        {
            int jumlah = daftar.HitungJumlahNotaJual();
            labelJumlah.Text = jumlah.ToString();

            string hasil = daftar.BacaSemuaData();

            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewDaftarNota.Rows.Clear();

                //tampilkan semua isi listBarang di datagridview
                for (int i = 0; i < daftar.JumlahNotaJual; i++)
                {
                    string noNota = daftar.ListNotaJual[i].NoNota;

                    string tgl = daftar.ListNotaJual[i].Tanggal.ToString("yyyy-MM-dd");

                    int kodePelanggan = daftar.ListNotaJual[i].Pelanggan.KodePelanggan;

                    string namaPelanggan = daftar.ListNotaJual[i].Pelanggan.NamaPelanggan;

                    string alamatPelanggan = daftar.ListNotaJual[i].Pelanggan.Alamat;

                    int kodePegawai = daftar.ListNotaJual[i].Pegawai.KodePegawai;

                    string namaPegawai = daftar.ListNotaJual[i].Pegawai.Nama;

                    dataGridViewDaftarNota.Rows.Add(noNota, tgl, kodePelanggan, namaPelanggan, alamatPelanggan, kodePegawai, namaPegawai);
                }
            }
            else
            {
                MessageBox.Show("Gagal menampilkan data. Pesan kesalahan = " + hasil, "Kesalahan");
            }
        }

        private void FormatDataGrid()
        {
            dataGridViewDaftarNota.Columns.Clear();

            dataGridViewDaftarNota.Columns.Add("NoNota", "No Nota");
            dataGridViewDaftarNota.Columns.Add("Tanggal", "Tanggal");
            dataGridViewDaftarNota.Columns.Add("KodePelanggan", "Kode Pelanggan");
            dataGridViewDaftarNota.Columns.Add("NamaPelanggan", "NamaPelanggan");
            dataGridViewDaftarNota.Columns.Add("AlamatPelanggan", "Alamat Pelanggan");
            dataGridViewDaftarNota.Columns.Add("KodePegawai", "Kode Pegawai");
            dataGridViewDaftarNota.Columns.Add("NamaPegawai", "Nama Pegawai");

            dataGridViewDaftarNota.Columns["NoNota"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["Tanggal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodePelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["AlamatPelanggan"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["KodePegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewDaftarNota.Columns["NamaPegawai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewDaftarNota.Width, this.dataGridViewDaftarNota.Height);

            dataGridViewDaftarNota.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewDaftarNota.Width, this.dataGridViewDaftarNota.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "No Nota";
            ws.Cells[1, 2] = "Tanggal";
            ws.Cells[1, 3] = "Kode Pelanggan";
            ws.Cells[1, 4] = "Nama Pelanggan";
            ws.Cells[1, 5] = "Alamat Pelanggan";
            ws.Cells[1, 6] = "Kode Pegawai";
            ws.Cells[1, 7] = "Nama Pegawai";

            for (int j = 2; j <= dataGridViewDaftarNota.Rows.Count; j++)
            {
                for (int i = 1; i <= 7; i++)
                {
                    ws.Cells[j, i] = dataGridViewDaftarNota.Rows[j - 2].Cells[i - 1].Value;
                }
            }
        }
    }
}
