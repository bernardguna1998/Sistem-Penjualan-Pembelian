﻿using DaftarKategoriBarang;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using System.Drawing.Printing;
using Microsoft.Office.Interop.Excel;

namespace SistemPenjualanPembelian
{
    public partial class FormReportSupplier : Form
    {
        DaftarSupplier daftar = new DaftarSupplier();
        public FormReportSupplier()
        {
            InitializeComponent();
        }

        private void FormReportSupplier_Load(object sender, EventArgs e)
        {
            int jumlah = daftar.HitungJumlahPelanggan();
            labelJumlah.Text = jumlah.ToString();


            string hasil = daftar.BacaSemuaData();
            if (hasil == "sukses")
            {
                FormatDataGrid();

                dataGridViewSupplier.Rows.Clear();

                for (int i = 0; i < daftar.JumlahSupplier; i++)
                {
                    int kodeSupplier = daftar.ListSupplier[i].KodeSupplier;
                    string namaSupplier = daftar.ListSupplier[i].NamaSupplier;
                    string alamatSupplier = daftar.ListSupplier[i].Alamat;

                    dataGridViewSupplier.Rows.Add(kodeSupplier, namaSupplier, alamatSupplier);
                }
            }
            else
            {
                dataGridViewSupplier.Rows.Clear();
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewSupplier.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewSupplier.Columns.Add("KodeSupplier", "Kode Supplier");
            dataGridViewSupplier.Columns.Add("NamaSupplier", "Nama Supplier");
            dataGridViewSupplier.Columns.Add("AlamatSupplier", "Alamat Supplier");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewSupplier.Columns["KodeSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewSupplier.Columns["NamaSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewSupplier.Columns["AlamatSupplier"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridViewSupplier.Width, this.dataGridViewSupplier.Height);

            dataGridViewSupplier.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.dataGridViewSupplier.Width, this.dataGridViewSupplier.Height));
            e.Graphics.DrawImage(bm, 10, 10);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb = Excel.Workbooks.Add(XlSheetType.xlWorksheet);

            Worksheet ws = (Worksheet)Excel.ActiveSheet;
            Excel.Visible = true;

            ws.Cells[1, 1] = "Kode Supplier";
            ws.Cells[1, 2] = "Nama Supplier";
            ws.Cells[1, 3] = "Alamat";

            for (int j = 2; j <= dataGridViewSupplier.Rows.Count; j++)
            {
                for (int i = 1; i <= 3; i++)
                {
                    ws.Cells[j, i] = dataGridViewSupplier.Rows[j - 2].Cells[i - 1].Value;
                }
            }
        }
    }
}
