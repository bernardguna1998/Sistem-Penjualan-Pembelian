﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;
using SistemPenjualanPembelian;

namespace DaftarKategoriBarang
{
    public partial class FormTambahBarang : Form
    {
        FormDaftarBarang form;
        Barang brg;
        DaftarBarang daftar;
        public FormTambahBarang()
        {
            InitializeComponent();
        }

        private void FormTambahBarang_Load(object sender, EventArgs e)
        {
            buttonCetakBarcode.Enabled = false;

            //textBoxNamaBarang_Leave(sender, e);
            //textBoxHargaJual_Leave(sender, e);
            //textBoxStok_Leave(sender, e);


            textBoxNamaBarang.MaxLength = 45;
            textBoxHargaJual.MaxLength = 11;
            textBoxStok.MaxLength = 6;

            //memanggil method generate code
            GenerateCode();

            //memanggil method generate category
            GenerateCategory();
            
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                int hrgJual = int.Parse(textBoxHargaJual.Text);
                int stok = int.Parse(textBoxStok.Text);

                string kodeKategori = comboBoxKodeKategori.Text.Substring(0, 2); //dimulai dari 0, diambilnya cuman 2
                string namaKategori = comboBoxKodeKategori.Text.Substring(5, comboBoxKodeKategori.Text.Length - 5);

                Kategori katBarang = new Kategori(kodeKategori, namaKategori);

                brg = new Barang();

                brg.KodeBarang = textBoxKodeBarang.Text;
                brg.NamaBarang = textBoxNamaBarang.Text;
                brg.Stok = stok;
                brg.HargaJual = hrgJual;
                brg.KategoriBarang = katBarang;

                daftar = new DaftarBarang();

                string hasilTambah = daftar.TambahData(brg);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data barang telah tersimpan", "Info");

                    buttonKosongi_Click(buttonSimpan, e);
                    buttonCetakBarcode.Enabled = true;
                    //FormTambahBarang_Load(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data barang gagal tersimpan. Pesan kesalahan : " + hasilTambah, "Kesalahan");
                }
            }
            catch (Exception ex)
            {
                if(textBoxStok.Text == "")
                {
                    MessageBox.Show("Gagal menambah data. Stok tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
                else if(textBoxHargaJual.Text == "")
                {
                    MessageBox.Show("Gagal menambah data. Harga Jual tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
                else
                {
                    MessageBox.Show("Gagal menambah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
            }
            }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarBarang)this.Owner;
            form.FormDaftarBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            //memanggil method ClearAll
            ClearAll();

            FormTambahBarang_Load(buttonKosongi, e);
        }

        private void FormTambahBarang_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarBarang)this.Owner;
            form.FormDaftarBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void buttonCetakBarcode_Click(object sender, EventArgs e)
        {
            string hasilCetak = daftar.CetakBarcode(brg);

            if (hasilCetak == "sukses")
            {
                MessageBox.Show("Proses cetak barcode berhasil.","Info");
               
                GenerateCode();
                GenerateCategory();
                ClearAll();
            }
            else
            {
                MessageBox.Show("Proses cetak barcode berhasil. Pesan kesalahan : " + hasilCetak);
            }
        }

        private void textBoxNamaBarang_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (Char.IsNumber(e.KeyChar)) e.Handled = true; // user bisa input ketika inputannya bukan angka
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        private void textBoxHargaJual_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBoxStok_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void GenerateCode()
        {
            daftar = new DaftarBarang();

            string hasil = daftar.GenerateCode();

            if (hasil == "sukses")
            {
                textBoxKodeBarang.Text = daftar.KodeTerbaru;
                textBoxKodeBarang.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }
        }

        private void GenerateCategory()
        {
            DaftarKategori daftarKat = new DaftarKategori();
            string hasil = daftarKat.BacaSemuaData();

            if (hasil == "sukses")
            {
                comboBoxKodeKategori.Items.Clear();

                for (int i = 0; i < daftarKat.JumlahKategoriBarang; i++)
                {
                    comboBoxKodeKategori.Items.Add(daftarKat.DaftarKategoriBarang[i].KodeKategori + " - " + daftarKat.DaftarKategoriBarang[i].NamaKategori);
                }

                comboBoxKodeKategori.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Kategori gagal ditampilkan di comboBox. Pesan kesalahan : " + hasil);
            }
        }

        private void ClearAll()
        {
            textBoxKodeBarang.Clear();
            textBoxNamaBarang.Clear();
            textBoxHargaJual.Clear();
            textBoxStok.Clear();
            comboBoxKodeKategori.SelectedIndex = 0;
        }

        //private void textBoxNamaBarang_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxNamaBarang.Text == "Orange Squash")
        //    {
        //        textBoxNamaBarang.Clear();

        //        textBoxNamaBarang.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxNamaBarang_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxNamaBarang.Text == "")
        //    {
        //        textBoxNamaBarang.Text = "Orange Squash";

        //        textBoxNamaBarang.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxHargaJual_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxHargaJual.Text == "10000")
        //    {
        //        textBoxHargaJual.Clear();

        //        textBoxHargaJual.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxHargaJual_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxHargaJual.Text == "")
        //    {
        //        textBoxHargaJual.Text = "10000";

        //        textBoxHargaJual.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxStok_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxStok.Text == "5")
        //    {
        //        textBoxStok.Text = "";

        //        textBoxStok.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxStok_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxStok.Text == "")
        //    {
        //        textBoxStok.Text = "5";

        //        textBoxStok.ForeColor = Color.Silver;
        //    }
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            FormLoadBarcode form = new FormLoadBarcode();

            form.ShowDialog();
        }
    }
}
