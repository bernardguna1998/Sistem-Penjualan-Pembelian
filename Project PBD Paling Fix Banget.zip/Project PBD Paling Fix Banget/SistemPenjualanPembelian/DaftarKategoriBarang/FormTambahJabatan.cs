﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormTambahJabatan : Form
    {
        FormDaftarJabatan form;
        DaftarJabatan daftar = new DaftarJabatan();

        public FormTambahJabatan()
        {
            InitializeComponent();
        }

        private void FormTambahJabatan_Load(object sender, EventArgs e)
        {
            //textBoxNama_Leave(sender, e);

            daftar = new DaftarJabatan();
            daftar.BacaSemuaData();

            if(daftar.JumlahJabatan == 9)
            {
                MessageBox.Show("Mohon maaf, tambah jabatan tidak bisa dilakukan. Detail Kesalahan : Data jabatan sudah mencapai batas maksimal.", "Info");
                textBoxIdJabatan.Enabled = false;
                textBoxNama.Enabled = false;
            }
            else
            {
                textBoxNama.MaxLength = 45;

                daftar = new DaftarJabatan();

                string hasil = daftar.GenerateCode();

                if (hasil == "sukses")
                {
                    textBoxIdJabatan.Text = daftar.KodeTerbaru;
                    textBoxIdJabatan.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
                }
            }
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Jabatan j = new Jabatan();
                j.IdJabatan = textBoxIdJabatan.Text;
                j.NamaJabatan = textBoxNama.Text;

                daftar = new DaftarJabatan();

                string hasilTambah = daftar.TambahData(j);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data jabatan berhasil ditambahkan", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data jabatan tidak berhasil ditambahkan. Pesan kesalahan : " + hasilTambah, "Kesalahan");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Data jabatan tidak berhasil ditambahkan. Pesan kesalahan : " + ex.Message, "Info Kesalahan");
            }
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxIdJabatan.Clear();
            textBoxNama.Clear();

            FormTambahJabatan_Load(buttonKosongi, e);
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarJabatan)this.Owner;
            form.FormDaftarJabatan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void FormTambahJabatan_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarJabatan)this.Owner;
            form.FormDaftarJabatan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNama_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        //private void textBoxNama_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxNama.Text == "Manajer")
        //    {
        //        textBoxNama.Text = "";

        //        textBoxNama.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxNama_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxNama.Text == "")
        //    {
        //        textBoxNama.Text = "Manajer";

        //        textBoxNama.ForeColor = Color.Silver;
        //    }
        //}
    }
}
