﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormTambahKategoriBarang : Form
    {
        FormDaftarKategoriBarang form;
        public FormTambahKategoriBarang()
        {
            InitializeComponent();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Kategori k = new Kategori();
                k.KodeKategori = textBoxKodeKategori.Text;
                k.NamaKategori = textBoxNamaKategori.Text;

                DaftarKategori daftar = new DaftarKategori();

                string hasilTambah = daftar.TambahData(k);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data kategori berhasil ditambahkan", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data kategori tidak berhasil ditambahkan. Pesan kesalahan : " + hasilTambah, " Kesalahan");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Gagal menambah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarKategoriBarang)this.Owner;
            form.FormDaftarKategoriBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeKategori.Text = "";
            textBoxNamaKategori.Text = "";
            textBoxKodeKategori.Focus();

            FormTambahKategoriBarang_Load(buttonKosongi, e);
        }

        private void FormTambahKategoriBarang_Load(object sender, EventArgs e)
        {
            //textBoxNamaKategori_Leave(sender, e);
            textBoxNamaKategori.MaxLength = 30;

            DaftarKategori daftar = new DaftarKategori();

            string hasil = daftar.GenerateCode();

            if(hasil == "sukses")
            {
                textBoxKodeKategori.Text = daftar.KodeTerakhir;
                textBoxKodeKategori.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }
        }

        private void FormTambahKategoriBarang_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarKategoriBarang)this.Owner;
            form.FormDaftarKategoriBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNamaKategori_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        //private void textBoxNamaKategori_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxNamaKategori.Text == "Minuman")
        //    {
        //        textBoxNamaKategori.Text = "";

        //        textBoxNamaKategori.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxNamaKategori_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxNamaKategori.Text == "")
        //    {
        //        textBoxNamaKategori.Text = "Minuman";

        //        textBoxNamaKategori.ForeColor = Color.Silver;
        //    }
        //}
    }
}
