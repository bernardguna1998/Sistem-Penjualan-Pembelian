﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormTambahNotaBeli : Form
    {
        public FormTambahNotaBeli()
        {
            InitializeComponent();
        }

        private void FormTambahNotaBeli_Load(object sender, EventArgs e)
        {
            textBoxKodeBarang.MaxLength = 5;
            textBoxKodeBarang.MaxLength = 5;
            textBoxKodeBarang.Focus();
            textBoxKodeBarang.Select();

            DaftarNotaBeli daftar = new DaftarNotaBeli();

            string hasil = daftar.GenerateNoNota();
            if (hasil == "sukses")
            {
                labelGrandTotal.Text = "";
                textBoxNoNota.Text = daftar.NoNotaTerbaru;
                textBoxNoNota.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }

            dateTimePickerTanggal.Value = DateTime.Now;
            dateTimePickerTanggal.Enabled = false;

            comboBoxSupplier.DropDownStyle = ComboBoxStyle.DropDownList;
            DaftarSupplier daftarSupplier = new DaftarSupplier();

            hasil = daftarSupplier.BacaSemuaData();

            if (hasil == "sukses")
            {
                comboBoxSupplier.Items.Clear();

                for (int i = 0; i < daftarSupplier.JumlahSupplier; i++)
                {
                    comboBoxSupplier.Items.Add(daftarSupplier.ListSupplier[i].KodeSupplier + " - " + daftarSupplier.ListSupplier[i].NamaSupplier);
                }

                comboBoxSupplier.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Data pelanggan gagal ditampilkan di comboBox. Pesan kesalahan : " + hasil);
            }

            FormUtama formUtama = (FormUtama)this.Owner.MdiParent;
            labelKodePegawai.Text = formUtama.labelKodePegawai.Text;
            labelNamaPegawai.Text = formUtama.labelNamaPegawai.Text;

            FormatDataGrid();

            textBoxKodeBarang.MaxLength = 5;
            textBoxKodeBarang.CharacterCasing = CharacterCasing.Upper;
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewTambahNotaBeli.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewTambahNotaBeli.Columns.Add("KodeBarang", "Kode Barang");
            dataGridViewTambahNotaBeli.Columns.Add("NamaBarang", "Nama Barang");
            dataGridViewTambahNotaBeli.Columns.Add("HargaBeli", "Harga Beli");
            dataGridViewTambahNotaBeli.Columns.Add("Jumlah", "Jumlah");
            dataGridViewTambahNotaBeli.Columns.Add("SubTotal", "Sub Total");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewTambahNotaBeli.Columns["KodeBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaBeli.Columns["NamaBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaBeli.Columns["HargaBeli"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaBeli.Columns["Jumlah"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaBeli.Columns["SubTotal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            //agar harga jual dan stok rata kanan
            dataGridViewTambahNotaBeli.Columns["HargaBeli"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewTambahNotaBeli.Columns["SubTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //agar harga jual ditampilkan dengan format pemisah ribuan (1000 delimiter)
            dataGridViewTambahNotaBeli.Columns["HargaBeli"].DefaultCellStyle.Format = "#,###.,00";
            dataGridViewTambahNotaBeli.Columns["SubTotal"].DefaultCellStyle.Format = "#,###.,00";

            dataGridViewTambahNotaBeli.AllowUserToAddRows = false;
        }

        private void comboBoxSupplier_SelectedIndexChanged(object sender, EventArgs e)
        {
            string kodeSupplier = comboBoxSupplier.Text.Substring(0, 1);

            DaftarSupplier daftarSup = new DaftarSupplier();
            daftarSup.CariData("KodeSupplier", kodeSupplier);
            richTextBoxAlamat.Text = daftarSup.ListSupplier[0].Alamat;
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            if(textBoxJumlah.Text == "")
            {
                MessageBox.Show("Mohon isi jumlah barang.", "Info");
                ClearFocus();
            }
            else
            {
                int idx = 0;

                foreach (DataGridViewRow row in dataGridViewTambahNotaBeli.Rows)
                {
                    if (row.Cells["NamaBarang"].Value.ToString() == labelNamaBarang.Text) //if check ==0
                    {
                        idx = row.Index;
                    }
                }

                if (dataGridViewTambahNotaBeli.Rows.Count == 0)
                {
                    int subTotal = int.Parse(labelHarga.Text) * int.Parse(textBoxJumlah.Text);
                    dataGridViewTambahNotaBeli.Rows.Add(textBoxKodeBarang.Text, labelNamaBarang.Text, labelHarga.Text, textBoxJumlah.Text, subTotal);
                }
                else if (dataGridViewTambahNotaBeli.Rows[idx].Cells["NamaBarang"].Value.ToString() != labelNamaBarang.Text)
                {
                    int subTotal = int.Parse(labelHarga.Text) * int.Parse(textBoxJumlah.Text);
                    dataGridViewTambahNotaBeli.Rows.Add(textBoxKodeBarang.Text, labelNamaBarang.Text, labelHarga.Text, textBoxJumlah.Text, subTotal);
                }
                else if ((dataGridViewTambahNotaBeli.Rows[idx].Cells["NamaBarang"].Value.ToString() == labelNamaBarang.Text))
                {
                    dataGridViewTambahNotaBeli.Rows[idx].Cells["Jumlah"].Value = int.Parse(textBoxJumlah.Text) + int.Parse(dataGridViewTambahNotaBeli.Rows[idx].Cells["Jumlah"].Value.ToString()); //then change row color to red
                    dataGridViewTambahNotaBeli.Rows[idx].Cells["SubTotal"].Value = int.Parse(dataGridViewTambahNotaBeli.Rows[idx].Cells["HargaBeli"].Value.ToString()) * int.Parse(dataGridViewTambahNotaBeli.Rows[idx].Cells["Jumlah"].Value.ToString()); //then change row color to red
                }

                labelGrandTotal.Text = HitungGrandTotal().ToString("0,###");
                ClearFocus();
            }
            
        }

        private int HitungGrandTotal()
        {
            int grandTotal = 0;
            for (int i = 0; i < dataGridViewTambahNotaBeli.Rows.Count; i++)
            {
                int subTotal = int.Parse(dataGridViewTambahNotaBeli.Rows[i].Cells["SubTotal"].Value.ToString());
                grandTotal = grandTotal + subTotal;
            }
            return grandTotal;
        }

        private void textBoxKodeBarang_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodeBarang.Text.Length == textBoxKodeBarang.MaxLength)
            {
                DaftarBarang daftar = new DaftarBarang();
                string hasil = daftar.CariData("KodeBarang", textBoxKodeBarang.Text);
                if (hasil == "sukses")
                {
                    if (daftar.JumlahBarang > 0)
                    {
                        labelNamaBarang.Text = daftar.ListBarang[0].NamaBarang;
                        labelHarga.Text = daftar.ListBarang[0].HargaJual.ToString();
                        textBoxJumlah.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Kode barang tidak ditemukan.");
                        textBoxKodeBarang.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dilakukan. Pesan kesalahan : " + hasil);
                }
            }
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            string kodeSupplier = comboBoxSupplier.Text.Substring(0, 1);
            string namaSupplier = comboBoxSupplier.Text.Substring(4, comboBoxSupplier.Text.Length - 4);

            Supplier supplier = new Supplier();
            supplier.KodeSupplier = int.Parse(kodeSupplier);
            supplier.NamaSupplier = namaSupplier;

            Pegawai pegawai = new Pegawai();
            pegawai.KodePegawai = int.Parse(labelKodePegawai.Text);
            pegawai.Nama = labelNamaPegawai.Text;

            List<NotaBeliDetil> listNotaDetil = new List<NotaBeliDetil>();

            for (int i = 0; i < dataGridViewTambahNotaBeli.Rows.Count; i++)
            {
                Barang brg = new Barang();
                brg.KodeBarang = dataGridViewTambahNotaBeli.Rows[i].Cells["KodeBarang"].Value.ToString();
                brg.NamaBarang = dataGridViewTambahNotaBeli.Rows[i].Cells["NamaBarang"].Value.ToString();
                int harga = int.Parse(dataGridViewTambahNotaBeli.Rows[i].Cells["HargaBeli"].Value.ToString());
                int jumlah = int.Parse(dataGridViewTambahNotaBeli.Rows[i].Cells["Jumlah"].Value.ToString());
                
                NotaBeliDetil notaDetil = new NotaBeliDetil(brg, harga, jumlah);

                listNotaDetil.Add(notaDetil);
            }

            NotaBeli nota = new NotaBeli(textBoxNoNota.Text, dateTimePickerTanggal.Value, supplier, pegawai, listNotaDetil);

            DaftarNotaBeli daftar = new DaftarNotaBeli();

            string hasilTambah = daftar.TambahData(nota);

            if (hasilTambah == "sukses")
            {
                MessageBox.Show("Data nota beli telah tersimpan", "Info");
                buttonCetak_Click(buttonSimpan, e);
                FormTambahNotaBeli_Load(buttonSimpan, e);
            }
            else
            {
                MessageBox.Show("Data nota beli gagal tersimpan. Pesan kesalahan : " + hasilTambah, "Kesalahan");
            }
        }

        private void FormTambahNotaBeli_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Apakah Anda yakin untuk keluar?",
                                      "Exit", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                FormDaftarNotaBeli form = new FormDaftarNotaBeli();
                form = (FormDaftarNotaBeli)this.Owner;

                form.FormDaftarNotaBeli_Load(sender, e);
                this.Owner.Enabled = true;
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            FormDaftarNotaBeli form = new FormDaftarNotaBeli();
            form = (FormDaftarNotaBeli)this.Owner;

            form.FormDaftarNotaBeli_Load(sender, e);
            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonCetak_Click(object sender, EventArgs e)
        {
            DaftarNotaBeli daftar = new DaftarNotaBeli();
            daftar.CetakNota("NoNota", textBoxNoNota.Text, "nota_beli.txt");

            MessageBox.Show("Nota beli telah tercetak");
        }

        private void textBoxJumlah_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void ClearFocus()
        {
            textBoxKodeBarang.Clear();
            labelNamaBarang.Text = "";
            labelHarga.Text = "";
            textBoxJumlah.Clear();
            textBoxKodeBarang.Focus();
        }

    }
}
