﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormTambahNotaJual : Form
    {
        int stokDiDatabase = 0;
        public FormTambahNotaJual()
        {
            InitializeComponent();
        }

        private void buttonTambah_Click(object sender, EventArgs e)
        {
            if(textBoxJumlah.Text == "")
            {
                MessageBox.Show("Mohon isi jumlah barang.", "Info");
                ClearFocus();
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Apakah anda yakin dengan jumlah barang sebanyak " + textBoxJumlah.Text + "?", "Info", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    //do something

                    int idx = 0;

                    foreach (DataGridViewRow row in dataGridViewTambahNotaJual.Rows)
                    {
                        if (row.Cells["NamaBarang"].Value.ToString() == labelNamaBarang.Text) //if check ==0
                        {
                            idx = row.Index;
                        }
                    }

                    //kalau stok nya kurang dari nol dan lebih dari stok yang ada aku throws exception
                    DaftarBarang dft = new DaftarBarang();
                    dft.BacaSemuaData();

                    int inputStok = int.Parse(textBoxJumlah.Text);

                    if (stokDiDatabase <= 0)
                    {
                        MessageBox.Show("Mohon maaf, stok habis.", "Info");
                    }
                    else if (inputStok > stokDiDatabase)
                    {
                        MessageBox.Show("Mohon maaf, stok yang anda inputkan lebih dari stok yang tersedia. Stok Tersedia : " + stokDiDatabase, "Info");
                    }
                    else
                    {
                        if (dataGridViewTambahNotaJual.Rows.Count == 0)
                        {
                            int subTotal = int.Parse(labelHarga.Text) * int.Parse(textBoxJumlah.Text);
                            dataGridViewTambahNotaJual.Rows.Add(textBoxKodeBarang.Text, labelNamaBarang.Text, labelHarga.Text, textBoxJumlah.Text, subTotal);
                        }
                        else if (dataGridViewTambahNotaJual.Rows[idx].Cells["NamaBarang"].Value.ToString() != labelNamaBarang.Text)
                        {
                            int subTotal = int.Parse(labelHarga.Text) * int.Parse(textBoxJumlah.Text);
                            dataGridViewTambahNotaJual.Rows.Add(textBoxKodeBarang.Text, labelNamaBarang.Text, labelHarga.Text, textBoxJumlah.Text, subTotal);
                        }
                        else if ((dataGridViewTambahNotaJual.Rows[idx].Cells["NamaBarang"].Value.ToString() == labelNamaBarang.Text))
                        {
                            MessageBox.Show("Maaf anda sudah menambah barang yang sama.", "Info");
                            ClearFocus();

                            //stokDiDatabase = stokDiDatabase - inputStok;

                            //dataGridViewTambahNotaJual.Rows[idx].Cells["Jumlah"].Value = int.Parse(textBoxJumlah.Text) + int.Parse(dataGridViewTambahNotaJual.Rows[idx].Cells["Jumlah"].Value.ToString()); //then change row color to red
                            //dataGridViewTambahNotaJual.Rows[idx].Cells["SubTotal"].Value = int.Parse(dataGridViewTambahNotaJual.Rows[idx].Cells["HargaJual"].Value.ToString()) * int.Parse(dataGridViewTambahNotaJual.Rows[idx].Cells["Jumlah"].Value.ToString()); //then change row color to red
                        }

                        labelGrandTotal.Text = HitungGrandTotal().ToString("0,###");
                    }

                    ClearFocus();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do something else

                    ClearFocus();
                }
            }
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            string kodePelanggan = comboBoxPelanggan.Text.Substring(0, 1);
            string namaPelanggan = comboBoxPelanggan.Text.Substring(4, comboBoxPelanggan.Text.Length - 4);

            Pelanggan pelanggan = new Pelanggan();
            pelanggan.KodePelanggan = int.Parse(kodePelanggan);
            pelanggan.NamaPelanggan = namaPelanggan;

            Pegawai pegawai = new Pegawai();
            pegawai.KodePegawai = int.Parse(labelKodePegawai.Text);
            pegawai.Nama = labelNamaPegawai.Text;

            List<NotaJualDetil> listNotaDetil = new List<NotaJualDetil>();

            for(int i =0; i<dataGridViewTambahNotaJual.Rows.Count; i++)
            {
                Barang brg = new Barang();
                brg.KodeBarang = dataGridViewTambahNotaJual.Rows[i].Cells["KodeBarang"].Value.ToString();
                brg.NamaBarang = dataGridViewTambahNotaJual.Rows[i].Cells["NamaBarang"].Value.ToString();
                int harga = int.Parse(dataGridViewTambahNotaJual.Rows[i].Cells["HargaJual"].Value.ToString());
                int jumlah = int.Parse(dataGridViewTambahNotaJual.Rows[i].Cells["Jumlah"].Value.ToString());
                NotaJualDetil notaDetil = new NotaJualDetil(brg, harga, jumlah);

                if(brg.KodeBarang ==  textBoxKodeBarang.Text)
                {
                    jumlah += int.Parse(textBoxJumlah.Text);
                }

                listNotaDetil.Add(notaDetil);
            }

            NotaJual nota = new NotaJual(textBoxNoNota.Text, dateTimePickerTanggal.Value, pelanggan, pegawai, listNotaDetil);

            DaftarNotaJual daftar = new DaftarNotaJual();

            string hasilTambah = daftar.TambahData(nota);

            if(hasilTambah == "sukses")
            {
                MessageBox.Show("Data nota jual telah tersimpan", "Info");
                buttonCetak_Click(buttonSimpan, e);
                FormTambahNotaJual_Load(buttonSimpan, e);  
            }
            else
            {
                MessageBox.Show("Data nota jual gagal tersimpan. Pesan kesalahan : " + hasilTambah, "Kesalahan");
            }
        }

        private void buttonCetak_Click(object sender, EventArgs e)
        {
            DaftarNotaJual daftar = new DaftarNotaJual();
            daftar.CetakNota("NoNota", textBoxNoNota.Text, "nota_jual.txt");

            MessageBox.Show("Nota jual telah tercetak");
        }

        private void FormTambahNotaJual_Load(object sender, EventArgs e)
        {
            textBoxKodeBarang.MaxLength = 5;
            textBoxKodeBarang.Focus();
            textBoxKodeBarang.Select();

            DaftarNotaJual daftar = new DaftarNotaJual();

            string hasil = daftar.GenerateCode();

            if(hasil == "sukses")
            {
                labelGrandTotal.Text = "";
                textBoxNoNota.Text = daftar.NoNotaTerbaru;
                textBoxNoNota.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }

            dateTimePickerTanggal.Value = DateTime.Now;
            dateTimePickerTanggal.Enabled = false;

            comboBoxPelanggan.DropDownStyle = ComboBoxStyle.DropDownList;
            DaftarPelanggan daftarPlg = new DaftarPelanggan();

            hasil = daftarPlg.BacaSemuaData();

            if(hasil == "sukses")
            {
                comboBoxPelanggan.Items.Clear();

                for(int i =0; i<daftarPlg.JumlahPelanggan; i++)
                {
                    comboBoxPelanggan.Items.Add(daftarPlg.DaftarInformasiPelanggan[i].KodePelanggan + " - " + daftarPlg.DaftarInformasiPelanggan[i].NamaPelanggan);
                }

                comboBoxPelanggan.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Data pelanggan gagal ditampilkan di comboBox. Pesan kesalahan : " + hasil);
            }

            FormUtama formUtama = (FormUtama)this.Owner.MdiParent;
            labelKodePegawai.Text = formUtama.labelKodePegawai.Text;
            labelNamaPegawai.Text = formUtama.labelNamaPegawai.Text;

            FormatDataGrid();

            textBoxKodeBarang.MaxLength = 5;
            textBoxKodeBarang.CharacterCasing = CharacterCasing.Upper;
        }

        private void FormatDataGrid()
        {
            //kosongi semua kolom di data grid view
            dataGridViewTambahNotaJual.Columns.Clear();

            //menambah kolom di datagridview
            dataGridViewTambahNotaJual.Columns.Add("KodeBarang", "Kode Barang");
            dataGridViewTambahNotaJual.Columns.Add("NamaBarang", "Nama Barang");
            dataGridViewTambahNotaJual.Columns.Add("HargaJual", "Harga Jual");
            dataGridViewTambahNotaJual.Columns.Add("Jumlah", "Jumlah");
            dataGridViewTambahNotaJual.Columns.Add("SubTotal", "Sub Total");

            //agar lebar kolom dapat menyesuaikan panjang/isi data
            dataGridViewTambahNotaJual.Columns["KodeBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaJual.Columns["NamaBarang"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaJual.Columns["HargaJual"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaJual.Columns["Jumlah"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewTambahNotaJual.Columns["SubTotal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            //agar harga jual dan stok rata kanan
            dataGridViewTambahNotaJual.Columns["HargaJual"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewTambahNotaJual.Columns["SubTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //agar harga jual ditampilkan dengan format pemisah ribuan (1000 delimiter)
            dataGridViewTambahNotaJual.Columns["HargaJual"].DefaultCellStyle.Format = "#,###.,00";
            dataGridViewTambahNotaJual.Columns["SubTotal"].DefaultCellStyle.Format = "#,###.,00";

            dataGridViewTambahNotaJual.AllowUserToAddRows = false;
        }

        private void comboBoxPelanggan_SelectedIndexChanged(object sender, EventArgs e)
        {
            string kodePelanggan = comboBoxPelanggan.Text.Substring(0, 1);

            DaftarPelanggan daftarPlg = new DaftarPelanggan();
            daftarPlg.CariData("KodePelanggan", kodePelanggan);
            richTextBoxAlamat.Text = daftarPlg.DaftarInformasiPelanggan[0].Alamat;
        }

        private void textBoxKodeBarang_TextChanged(object sender, EventArgs e)
        {
            if(textBoxKodeBarang.Text.Length == textBoxKodeBarang.MaxLength)
            {
                DaftarBarang daftar = new DaftarBarang();
                string hasil = daftar.CariData("KodeBarang", textBoxKodeBarang.Text);
                if(hasil == "sukses")
                {
                    if(daftar.JumlahBarang > 0)
                    {
                        labelNamaBarang.Text = daftar.ListBarang[0].NamaBarang;
                        labelHarga.Text = daftar.ListBarang[0].HargaJual.ToString();
                        stokDiDatabase = daftar.ListBarang[0].Stok;

                    }
                    else
                    {
                        MessageBox.Show("Kode barang tidak ditemukan.");
                        textBoxKodeBarang.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dilakukan. Pesan kesalahan = " + hasil);
                }
            }
        }

        private int HitungGrandTotal()
        {
            int grandTotal = 0;
            for(int i=0; i< dataGridViewTambahNotaJual.Rows.Count; i++)
            {
                int subTotal = int.Parse(dataGridViewTambahNotaJual.Rows[i].Cells["SubTotal"].Value.ToString());
                grandTotal = grandTotal + subTotal;
            }
            return grandTotal;
        }

        private void FormTambahNotaJual_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Apakah Anda yakin untuk keluar?",
                                      "Exit", MessageBoxButtons.YesNo);

            if (dr == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                FormDaftarNotaJual form = new FormDaftarNotaJual();
                form = (FormDaftarNotaJual)this.Owner;

                form.FormDaftarNotaJual_Load(sender, e);
                this.Owner.Enabled = true;
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            FormDaftarNotaJual form = new FormDaftarNotaJual();
            form = (FormDaftarNotaJual)this.Owner;

            form.FormDaftarNotaJual_Load(sender, e);
            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxJumlah_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void ClearFocus()
        {
            textBoxKodeBarang.Clear();
            labelNamaBarang.Text = "";
            labelHarga.Text = "";
            textBoxJumlah.Clear();
            textBoxKodeBarang.Focus();
        }
    }
}
