﻿namespace DaftarKategoriBarang
{
    partial class FormTambahPegawai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonKeluar = new System.Windows.Forms.Button();
            this.buttonKosongi = new System.Windows.Forms.Button();
            this.panelInputKategori = new System.Windows.Forms.Panel();
            this.comboBoxJabatan = new System.Windows.Forms.ComboBox();
            this.richTextBoxAlamat = new System.Windows.Forms.RichTextBox();
            this.dateTimePickerTglLhr = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxUlangiPwd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxPwd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxGaji = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNamaPegawai = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxKodePegawai = new System.Windows.Forms.TextBox();
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panelInputKategori.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonKeluar
            // 
            this.buttonKeluar.BackColor = System.Drawing.Color.Black;
            this.buttonKeluar.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKeluar.ForeColor = System.Drawing.Color.White;
            this.buttonKeluar.Location = new System.Drawing.Point(513, 487);
            this.buttonKeluar.Name = "buttonKeluar";
            this.buttonKeluar.Size = new System.Drawing.Size(140, 50);
            this.buttonKeluar.TabIndex = 29;
            this.buttonKeluar.Text = "KELUAR";
            this.buttonKeluar.UseVisualStyleBackColor = false;
            this.buttonKeluar.Click += new System.EventHandler(this.buttonKeluar_Click);
            // 
            // buttonKosongi
            // 
            this.buttonKosongi.BackColor = System.Drawing.Color.Black;
            this.buttonKosongi.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKosongi.ForeColor = System.Drawing.Color.White;
            this.buttonKosongi.Location = new System.Drawing.Point(283, 487);
            this.buttonKosongi.Name = "buttonKosongi";
            this.buttonKosongi.Size = new System.Drawing.Size(140, 50);
            this.buttonKosongi.TabIndex = 28;
            this.buttonKosongi.Text = "KOSONGI";
            this.buttonKosongi.UseVisualStyleBackColor = false;
            this.buttonKosongi.Click += new System.EventHandler(this.buttonKosongi_Click);
            // 
            // panelInputKategori
            // 
            this.panelInputKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelInputKategori.Controls.Add(this.comboBoxJabatan);
            this.panelInputKategori.Controls.Add(this.richTextBoxAlamat);
            this.panelInputKategori.Controls.Add(this.dateTimePickerTglLhr);
            this.panelInputKategori.Controls.Add(this.label10);
            this.panelInputKategori.Controls.Add(this.textBoxUlangiPwd);
            this.panelInputKategori.Controls.Add(this.label8);
            this.panelInputKategori.Controls.Add(this.textBoxPwd);
            this.panelInputKategori.Controls.Add(this.label9);
            this.panelInputKategori.Controls.Add(this.textBoxUsername);
            this.panelInputKategori.Controls.Add(this.label6);
            this.panelInputKategori.Controls.Add(this.textBoxGaji);
            this.panelInputKategori.Controls.Add(this.label7);
            this.panelInputKategori.Controls.Add(this.label5);
            this.panelInputKategori.Controls.Add(this.label4);
            this.panelInputKategori.Controls.Add(this.textBoxNamaPegawai);
            this.panelInputKategori.Controls.Add(this.label1);
            this.panelInputKategori.Controls.Add(this.label3);
            this.panelInputKategori.Controls.Add(this.textBoxKodePegawai);
            this.panelInputKategori.Location = new System.Drawing.Point(12, 82);
            this.panelInputKategori.Name = "panelInputKategori";
            this.panelInputKategori.Size = new System.Drawing.Size(639, 399);
            this.panelInputKategori.TabIndex = 27;
            // 
            // comboBoxJabatan
            // 
            this.comboBoxJabatan.FormattingEnabled = true;
            this.comboBoxJabatan.Location = new System.Drawing.Point(170, 361);
            this.comboBoxJabatan.Name = "comboBoxJabatan";
            this.comboBoxJabatan.Size = new System.Drawing.Size(277, 21);
            this.comboBoxJabatan.TabIndex = 19;
            // 
            // richTextBoxAlamat
            // 
            this.richTextBoxAlamat.Location = new System.Drawing.Point(170, 126);
            this.richTextBoxAlamat.Name = "richTextBoxAlamat";
            this.richTextBoxAlamat.Size = new System.Drawing.Size(277, 70);
            this.richTextBoxAlamat.TabIndex = 18;
            this.richTextBoxAlamat.Text = "";
            //this.richTextBoxAlamat.Enter += new System.EventHandler(this.richTextBoxAlamat_Enter);
            //this.richTextBoxAlamat.Leave += new System.EventHandler(this.richTextBoxAlamat_Leave);
            // 
            // dateTimePickerTglLhr
            // 
            this.dateTimePickerTglLhr.CustomFormat = "yyyy-MM-dd";
            this.dateTimePickerTglLhr.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerTglLhr.Location = new System.Drawing.Point(170, 87);
            this.dateTimePickerTglLhr.Name = "dateTimePickerTglLhr";
            this.dateTimePickerTglLhr.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerTglLhr.TabIndex = 17;
            this.dateTimePickerTglLhr.Value = new System.DateTime(1977, 3, 7, 0, 0, 0, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(76, 359);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 19);
            this.label10.TabIndex = 16;
            this.label10.Text = "Jabatan :";
            // 
            // textBoxUlangiPwd
            // 
            this.textBoxUlangiPwd.Location = new System.Drawing.Point(170, 320);
            this.textBoxUlangiPwd.Name = "textBoxUlangiPwd";
            this.textBoxUlangiPwd.PasswordChar = '*';
            this.textBoxUlangiPwd.Size = new System.Drawing.Size(176, 20);
            this.textBoxUlangiPwd.TabIndex = 15;
            //this.textBoxUlangiPwd.Enter += new System.EventHandler(this.textBoxUlangiPwd_Enter);
            //this.textBoxUlangiPwd.Leave += new System.EventHandler(this.textBoxUlangiPwd_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 318);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 19);
            this.label8.TabIndex = 14;
            this.label8.Text = "Ulangi Password :";
            // 
            // textBoxPwd
            // 
            this.textBoxPwd.Location = new System.Drawing.Point(170, 283);
            this.textBoxPwd.Name = "textBoxPwd";
            this.textBoxPwd.PasswordChar = '*';
            this.textBoxPwd.Size = new System.Drawing.Size(176, 20);
            this.textBoxPwd.TabIndex = 13;
            //this.textBoxPwd.Enter += new System.EventHandler(this.textBoxPwd_Enter);
            //this.textBoxPwd.Leave += new System.EventHandler(this.textBoxPwd_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(66, 281);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 19);
            this.label9.TabIndex = 12;
            this.label9.Text = "Password :";
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.Location = new System.Drawing.Point(170, 248);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(176, 20);
            //this.textBoxUsername.TabIndex = 11;
            //this.textBoxUsername.Enter += new System.EventHandler(this.textBoxUsername_Enter);
            //this.textBoxUsername.Leave += new System.EventHandler(this.textBoxUsername_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(59, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "Username :";
            // 
            // textBoxGaji
            // 
            this.textBoxGaji.Location = new System.Drawing.Point(170, 214);
            this.textBoxGaji.Name = "textBoxGaji";
            this.textBoxGaji.Size = new System.Drawing.Size(200, 20);
            this.textBoxGaji.TabIndex = 9;
            //this.textBoxGaji.Enter += new System.EventHandler(this.textBoxGaji_Enter);
            this.textBoxGaji.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxGaji_KeyPress);
            //this.textBoxGaji.Leave += new System.EventHandler(this.textBoxGaji_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(108, 212);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 19);
            this.label7.TabIndex = 8;
            this.label7.Text = "Gaji :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(82, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Alamat :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Tanggal Lahir :";
            // 
            // textBoxNamaPegawai
            // 
            this.textBoxNamaPegawai.Location = new System.Drawing.Point(170, 52);
            this.textBoxNamaPegawai.Name = "textBoxNamaPegawai";
            this.textBoxNamaPegawai.Size = new System.Drawing.Size(277, 20);
            this.textBoxNamaPegawai.TabIndex = 3;
            //this.textBoxNamaPegawai.Enter += new System.EventHandler(this.textBoxNamaPegawai_Enter);
            this.textBoxNamaPegawai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNamaPegawai_KeyPress);
            //this.textBoxNamaPegawai.Leave += new System.EventHandler(this.textBoxNamaPegawai_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nama Pegawai :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Kode Pegawai :";
            // 
            // textBoxKodePegawai
            // 
            this.textBoxKodePegawai.Location = new System.Drawing.Point(170, 15);
            this.textBoxKodePegawai.Name = "textBoxKodePegawai";
            this.textBoxKodePegawai.Size = new System.Drawing.Size(67, 20);
            this.textBoxKodePegawai.TabIndex = 2;
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.Color.Black;
            this.buttonSimpan.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSimpan.ForeColor = System.Drawing.Color.White;
            this.buttonSimpan.Location = new System.Drawing.Point(120, 487);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(140, 50);
            this.buttonSimpan.TabIndex = 25;
            this.buttonSimpan.Text = "SIMPAN";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(639, 62);
            this.label2.TabIndex = 26;
            this.label2.Text = "TAMBAH PEGAWAI";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormTambahPegawai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(664, 549);
            this.Controls.Add(this.buttonKeluar);
            this.Controls.Add(this.buttonKosongi);
            this.Controls.Add(this.panelInputKategori);
            this.Controls.Add(this.buttonSimpan);
            this.Controls.Add(this.label2);
            this.Name = "FormTambahPegawai";
            this.Text = "Tambah Pegawai";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormTambahPegawai_FormClosing);
            this.Load += new System.EventHandler(this.FormTambahPegawai_Load);
            this.panelInputKategori.ResumeLayout(false);
            this.panelInputKategori.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonKeluar;
        private System.Windows.Forms.Button buttonKosongi;
        private System.Windows.Forms.Panel panelInputKategori;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxUlangiPwd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxPwd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxGaji;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNamaPegawai;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxKodePegawai;
        private System.Windows.Forms.Button buttonSimpan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBoxAlamat;
        private System.Windows.Forms.DateTimePicker dateTimePickerTglLhr;
        private System.Windows.Forms.ComboBox comboBoxJabatan;
    }
}