﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormTambahPegawai : Form
    {
        FormDaftarPegawai form;
        public FormTambahPegawai()
        {
            InitializeComponent();
        }

        private void FormTambahPegawai_Load(object sender, EventArgs e)
        {
            //textBoxGaji_Leave(sender, e);
            //textBoxPwd_Leave(sender, e);
            //textBoxUsername_Leave(sender, e);
            //textBoxUlangiPwd_Leave(sender, e);
            //textBoxNamaPegawai_Leave(sender, e);
            //richTextBoxAlamat_Leave(sender, e);

            textBoxPwd.MaxLength = 8;
            textBoxUsername.MaxLength = 8;
            textBoxUlangiPwd.MaxLength = 8;
            textBoxNamaPegawai.MaxLength = 45;
            richTextBoxAlamat.MaxLength = 100;

            DaftarPegawai daftar = new DaftarPegawai();

            string hasil = daftar.GenerateCode();

            if (hasil == "sukses")
            {
                textBoxKodePegawai.Text = daftar.KodeTerbaru;
                textBoxKodePegawai.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }

            DaftarJabatan daftarJ = new DaftarJabatan();

            hasil = daftarJ.BacaSemuaData();

            if (hasil == "sukses")
            {
                comboBoxJabatan.Items.Clear();

                for (int i = 0; i < daftarJ.JumlahJabatan; i++)
                {
                    comboBoxJabatan.Items.Add(daftarJ.ListJabatan[i].IdJabatan + " - " + daftarJ.ListJabatan[i].NamaJabatan);
                }

                comboBoxJabatan.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Id Jabatan gagal ditampilkan di comboBox. Pesan kesalahan : " + hasil);
            }
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxPwd.Text == textBoxUlangiPwd.Text)
                {
                    string kodeJab = comboBoxJabatan.Text.Substring(0, 2); //dimulai dari 0, diambilnya cuman 2
                    string namaJab = comboBoxJabatan.Text.Substring(5, comboBoxJabatan.Text.Length - 5);

                    Jabatan j = new Jabatan(kodeJab, namaJab);

                    Pegawai p = new Pegawai();
                    p.KodePegawai = int.Parse(textBoxKodePegawai.Text);
                    p.Nama = textBoxNamaPegawai.Text;
                    p.TanggalLhr = dateTimePickerTglLhr.Value;
                    p.Alamat = richTextBoxAlamat.Text;
                    p.Gaji = int.Parse(textBoxGaji.Text);
                    p.Username = textBoxUsername.Text;
                    p.Pwd = textBoxPwd.Text;
                    p.Jabatan = j;

                    DaftarPegawai daftar = new DaftarPegawai();

                    string hasilTambah = daftar.TambahData(p);

                    if (hasilTambah == "sukses")
                    {
                        MessageBox.Show("Data pegawai telah tersimpan", "Info");

                        buttonKosongi_Click(buttonSimpan, e);
                        FormTambahPegawai_Load(buttonSimpan, e);
                    }
                    else
                    {
                        MessageBox.Show("Data barang gagal tersimpan. Pesan kesalahan : " + hasilTambah, "Kesalahan");
                    }
                }
                else
                {
                    MessageBox.Show("Password yang Anda Masukan Tidak Sama. Mohon periksa kembali password anda");
                }
            }
            catch(Exception ex)
            {
                if (textBoxGaji.Text == "")
                {
                    MessageBox.Show("Gagal menambah data. Gaji tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
                else
                {
                    MessageBox.Show("Gagal menambah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
            }
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodePegawai.Clear();
            textBoxNamaPegawai.Clear();
            textBoxPwd.Clear();
            textBoxUlangiPwd.Clear();
            comboBoxJabatan.SelectedIndex = 0;
            textBoxUsername.Clear();
            dateTimePickerTglLhr.Value = DateTime.Now;
            textBoxGaji.Clear();
            richTextBoxAlamat.Clear();

            FormTambahPegawai_Load(buttonKosongi, e);
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarPegawai)this.Owner;
            form.FormDaftarPegawai_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void FormTambahPegawai_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarPegawai)this.Owner;
            form.FormDaftarPegawai_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNamaPegawai_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        private void textBoxGaji_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        //private void textBoxNamaPegawai_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxNamaPegawai.Text == "")
        //    {
        //        textBoxNamaPegawai.Text = "Andrew Gunawan";

        //        textBoxNamaPegawai.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxNamaPegawai_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxNamaPegawai.Text == "Andrew Gunawan")
        //    {
        //        textBoxNamaPegawai.Text = "";

        //        textBoxNamaPegawai.ForeColor = Color.Black;
        //    }
        //}

        //private void richTextBoxAlamat_Leave(object sender, EventArgs e)
        //{
        //    if (richTextBoxAlamat.Text == "")
        //    {
        //        richTextBoxAlamat.Text = "Jln. Margerejo Indah XVII No. 43";

        //        richTextBoxAlamat.ForeColor = Color.Silver;
        //    }
        //}

        //private void richTextBoxAlamat_Enter(object sender, EventArgs e)
        //{
        //    if (richTextBoxAlamat.Text == "Jln. Margerejo Indah XVII No. 43")
        //    {
        //        richTextBoxAlamat.Text = "";

        //        richTextBoxAlamat.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxGaji_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxGaji.Text == "")
        //    {
        //        textBoxGaji.Text = "3000000";

        //        textBoxGaji.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxGaji_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxGaji.Text == "3000000")
        //    {
        //        textBoxGaji.Text = "";

        //        textBoxGaji.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxUsername_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxUsername.Text == "")
        //    {
        //        textBoxUsername.Text = "andrew";

        //        textBoxUsername.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxUsername_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxUsername.Text == "andrew")
        //    {
        //        textBoxUsername.Text = "";

        //        textBoxUsername.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxUlangiPwd_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxUlangiPwd.Text == "")
        //    {
        //        textBoxUlangiPwd.Text = "123";

        //        textBoxUlangiPwd.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxUlangiPwd_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxUlangiPwd.Text == "123")
        //    {
        //        textBoxUlangiPwd.Text = "";

        //        textBoxUlangiPwd.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxPwd_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxPwd.Text == "123")
        //    {
        //        textBoxPwd.Text = "";

        //        textBoxPwd.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxPwd_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxPwd.Text == "")
        //    {
        //        textBoxPwd.Text = "123";

        //        textBoxPwd.ForeColor = Color.Silver;
        //    }
        //}
    }
}
