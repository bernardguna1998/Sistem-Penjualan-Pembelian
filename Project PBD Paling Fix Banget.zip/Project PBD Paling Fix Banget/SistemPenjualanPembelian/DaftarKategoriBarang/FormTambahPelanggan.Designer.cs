﻿namespace DaftarKategoriBarang
{
    partial class FormTambahPelanggan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonKeluar = new System.Windows.Forms.Button();
            this.buttonKosongi = new System.Windows.Forms.Button();
            this.panelInputKategori = new System.Windows.Forms.Panel();
            this.textBoxTelepon = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxAlamat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNamaPelanggan = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxKodePelanggan = new System.Windows.Forms.TextBox();
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panelInputKategori.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonKeluar
            // 
            this.buttonKeluar.BackColor = System.Drawing.Color.Black;
            this.buttonKeluar.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKeluar.ForeColor = System.Drawing.Color.White;
            this.buttonKeluar.Location = new System.Drawing.Point(515, 350);
            this.buttonKeluar.Name = "buttonKeluar";
            this.buttonKeluar.Size = new System.Drawing.Size(140, 50);
            this.buttonKeluar.TabIndex = 24;
            this.buttonKeluar.Text = "KELUAR";
            this.buttonKeluar.UseVisualStyleBackColor = false;
            this.buttonKeluar.Click += new System.EventHandler(this.buttonKeluar_Click);
            // 
            // buttonKosongi
            // 
            this.buttonKosongi.BackColor = System.Drawing.Color.Black;
            this.buttonKosongi.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKosongi.ForeColor = System.Drawing.Color.White;
            this.buttonKosongi.Location = new System.Drawing.Point(285, 350);
            this.buttonKosongi.Name = "buttonKosongi";
            this.buttonKosongi.Size = new System.Drawing.Size(140, 50);
            this.buttonKosongi.TabIndex = 23;
            this.buttonKosongi.Text = "KOSONGI";
            this.buttonKosongi.UseVisualStyleBackColor = false;
            this.buttonKosongi.Click += new System.EventHandler(this.buttonKosongi_Click);
            // 
            // panelInputKategori
            // 
            this.panelInputKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelInputKategori.Controls.Add(this.textBoxTelepon);
            this.panelInputKategori.Controls.Add(this.label5);
            this.panelInputKategori.Controls.Add(this.textBoxAlamat);
            this.panelInputKategori.Controls.Add(this.label4);
            this.panelInputKategori.Controls.Add(this.textBoxNamaPelanggan);
            this.panelInputKategori.Controls.Add(this.label1);
            this.panelInputKategori.Controls.Add(this.label3);
            this.panelInputKategori.Controls.Add(this.textBoxKodePelanggan);
            this.panelInputKategori.Location = new System.Drawing.Point(16, 89);
            this.panelInputKategori.Name = "panelInputKategori";
            this.panelInputKategori.Size = new System.Drawing.Size(639, 237);
            this.panelInputKategori.TabIndex = 22;
            // 
            // textBoxTelepon
            // 
            this.textBoxTelepon.Location = new System.Drawing.Point(170, 171);
            this.textBoxTelepon.Name = "textBoxTelepon";
            this.textBoxTelepon.Size = new System.Drawing.Size(406, 20);
            this.textBoxTelepon.TabIndex = 7;
            //this.textBoxTelepon.Enter += new System.EventHandler(this.textBoxTelepon_Enter);
            this.textBoxTelepon.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxTelepon_KeyDown);
            //this.textBoxTelepon.Leave += new System.EventHandler(this.textBoxTelepon_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(76, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Telepon :";
            // 
            // textBoxAlamat
            // 
            this.textBoxAlamat.Location = new System.Drawing.Point(170, 125);
            this.textBoxAlamat.Name = "textBoxAlamat";
            this.textBoxAlamat.Size = new System.Drawing.Size(406, 20);
            this.textBoxAlamat.TabIndex = 5;
            //this.textBoxAlamat.Enter += new System.EventHandler(this.textBoxAlamat_Enter);
            //this.textBoxAlamat.Leave += new System.EventHandler(this.textBoxAlamat_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(82, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Alamat :";
            // 
            // textBoxNamaPelanggan
            // 
            this.textBoxNamaPelanggan.Location = new System.Drawing.Point(170, 78);
            this.textBoxNamaPelanggan.Name = "textBoxNamaPelanggan";
            this.textBoxNamaPelanggan.Size = new System.Drawing.Size(406, 20);
            this.textBoxNamaPelanggan.TabIndex = 3;
            //this.textBoxNamaPelanggan.Enter += new System.EventHandler(this.textBoxNamaPelanggan_Enter);
            this.textBoxNamaPelanggan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNamaPelanggan_KeyPress);
            //this.textBoxNamaPelanggan.Leave += new System.EventHandler(this.textBoxNamaPelanggan_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nama Pelanggan :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Kode Pelanggan :";
            // 
            // textBoxKodePelanggan
            // 
            this.textBoxKodePelanggan.Location = new System.Drawing.Point(170, 34);
            this.textBoxKodePelanggan.Name = "textBoxKodePelanggan";
            this.textBoxKodePelanggan.Size = new System.Drawing.Size(67, 20);
            this.textBoxKodePelanggan.TabIndex = 2;
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.Color.Black;
            this.buttonSimpan.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSimpan.ForeColor = System.Drawing.Color.White;
            this.buttonSimpan.Location = new System.Drawing.Point(122, 350);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(140, 50);
            this.buttonSimpan.TabIndex = 20;
            this.buttonSimpan.Text = "SIMPAN";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(16, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(639, 62);
            this.label2.TabIndex = 21;
            this.label2.Text = "TAMBAH PELANGGAN";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormTambahPelanggan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(668, 412);
            this.Controls.Add(this.buttonKeluar);
            this.Controls.Add(this.buttonKosongi);
            this.Controls.Add(this.panelInputKategori);
            this.Controls.Add(this.buttonSimpan);
            this.Controls.Add(this.label2);
            this.Name = "FormTambahPelanggan";
            this.Text = "Tambah Pelanggan";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormTambahPelanggan_FormClosing);
            this.Load += new System.EventHandler(this.FormTambahPelanggan_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormTambahPelanggan_KeyDown);
            this.panelInputKategori.ResumeLayout(false);
            this.panelInputKategori.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonKeluar;
        private System.Windows.Forms.Button buttonKosongi;
        private System.Windows.Forms.Panel panelInputKategori;
        private System.Windows.Forms.TextBox textBoxTelepon;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxAlamat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNamaPelanggan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxKodePelanggan;
        private System.Windows.Forms.Button buttonSimpan;
        private System.Windows.Forms.Label label2;
    }
}