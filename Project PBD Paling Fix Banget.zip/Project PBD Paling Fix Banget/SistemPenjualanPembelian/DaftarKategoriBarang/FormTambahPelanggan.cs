﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;


namespace DaftarKategoriBarang
{
    public partial class FormTambahPelanggan : Form
    {
        FormDaftarPelanggan form;
        public FormTambahPelanggan()
        {
            InitializeComponent();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Pelanggan p = new Pelanggan();
                p.KodePelanggan = int.Parse(textBoxKodePelanggan.Text);
                p.NamaPelanggan = textBoxNamaPelanggan.Text;
                p.Alamat = textBoxAlamat.Text;
                p.Telepon = textBoxTelepon.Text;

                DaftarPelanggan daftar = new DaftarPelanggan();

                string hasilTambah = daftar.TambahData(p);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data pelanggan berhasil ditambahkan", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data pelanggan tidak berhasil ditambahkan. Pesan kesalahan: " + hasilTambah, " Kesalahan");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Gagal menambah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
            }
            
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodePelanggan.Text = "";
            textBoxNamaPelanggan.Text = "";
            textBoxAlamat.Text = "";
            textBoxTelepon.Text = "";

            FormTambahPelanggan_Load(buttonKosongi, e);
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarPelanggan)this.Owner;
            form.FormDaftarPelanggan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void FormTambahPelanggan_Load(object sender, EventArgs e)
        {
        //    textBoxAlamat_Leave(sender, e);
        //    textBoxTelepon_Leave(sender, e);
        //    textBoxNamaPelanggan_Leave(sender, e);

            textBoxTelepon.MaxLength = 20;
            textBoxNamaPelanggan.MaxLength = 50;
            textBoxAlamat.MaxLength = 100;

            DaftarPelanggan daftar = new DaftarPelanggan();

            string hasil = daftar.GenerateCode();

            if (hasil == "sukses")
            {
                textBoxKodePelanggan.Text = daftar.KodeTerakhir;
                textBoxKodePelanggan.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }
        }

        private void FormTambahPelanggan_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarPelanggan)this.Owner;
            form.FormDaftarPelanggan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxTelepon_KeyDown(object sender, KeyEventArgs e)
        {
            //digit = angka
            //suppressKey berfungsi untuk mencegah apakah inputan boleh dimasukkan ke textBox atau tidak           
            if (!Char.IsDigit((char)e.KeyValue)) //artinya kalao karakternya bukan digit (means: huruf) maka lakukan perintah dibaah ini
            {
                if (e.KeyCode == Keys.Back || e.KeyCode == Keys.OemCloseBrackets || e.KeyCode == Keys.OemOpenBrackets || e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Oemplus)
                {
                    e.SuppressKeyPress = false;
                }
                else
                {
                    e.SuppressKeyPress = true; //selain back/hapus, (, ), -, maka tidak bisa diakses
                }
            }   
        }

        private void FormTambahPelanggan_KeyDown(object sender, KeyEventArgs e)
        {
            //digit = angka
            //suppressKey berfungsi untuk mencegah apakah inputan boleh dimasukkan ke textBox atau tidak           
            if (!Char.IsDigit((char)e.KeyValue)) //artinya kalao karakternya bukan digit (means: huruf) maka lakukan perintah dibaah ini
            {
                if (e.KeyCode == Keys.Back || e.KeyCode == Keys.OemCloseBrackets || e.KeyCode == Keys.OemOpenBrackets || e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Oemplus)
                {
                    e.SuppressKeyPress = false;
                }
                else
                {
                    e.SuppressKeyPress = true; //selain back/hapus, (, ), -, maka tidak bisa diakses
                }
            }   
        }

        private void textBoxNamaPelanggan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        //private void textBoxNamaPelanggan_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxNamaPelanggan.Text == "")
        //    {
        //        textBoxNamaPelanggan.Text = "Anton Mario";

        //        textBoxNamaPelanggan.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxNamaPelanggan_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxNamaPelanggan.Text == "Anton Mario")
        //    {
        //        textBoxNamaPelanggan.Text = "";

        //        textBoxNamaPelanggan.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxAlamat_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxAlamat.Text == "")
        //    {
        //        textBoxAlamat.Text = "Jln. Raya Diponegoro 123";

        //        textBoxAlamat.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxAlamat_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxAlamat.Text == "Jln. Raya Diponegoro 123")
        //    {
        //        textBoxAlamat.Text = "";

        //        textBoxAlamat.ForeColor = Color.Black;
        //    }
        //}

        //private void textBoxTelepon_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxTelepon.Text == "")
        //    {
        //        textBoxTelepon.Text = "(031) 5344562";

        //        textBoxTelepon.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxTelepon_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxTelepon.Text == "(031) 5344562")
        //    {
        //        textBoxTelepon.Text = "";

        //        textBoxTelepon.ForeColor = Color.Black;
        //    }
        //}
    }
}
