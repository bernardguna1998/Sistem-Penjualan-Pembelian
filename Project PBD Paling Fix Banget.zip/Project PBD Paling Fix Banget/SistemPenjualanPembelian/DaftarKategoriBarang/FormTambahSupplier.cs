﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormTambahSupplier : Form
    {
        FormDaftarSupplier form;

        public FormTambahSupplier()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarSupplier)this.Owner;
            form.FormDaftarSupplier_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeSupplier.Clear();
            textBoxNama.Clear();
            richTextBoxAlamat.Clear();

            FormTambahSupplier_Load(buttonKosongi, e);
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Supplier s = new Supplier();
                s.KodeSupplier = int.Parse(textBoxKodeSupplier.Text);
                s.NamaSupplier = textBoxNama.Text;
                s.Alamat = richTextBoxAlamat.Text;

                DaftarSupplier daftar = new DaftarSupplier();

                string hasilTambah = daftar.TambahData(s);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data supplier berhasil ditambahkan", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data supplier tidak berhasil ditambahkan. Pesan kesalahan : " + hasilTambah, " Kesalahan");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menambah data. Pesan kesalahan: " + ex.Message, "Info");
            }
        }

        private void FormTambahSupplier_Load(object sender, EventArgs e)
        {
            //textBoxNama_Leave(sender, e);
            //richTextBoxAlamat_Leave(sender, e);

            textBoxNama.MaxLength = 30;
            richTextBoxAlamat.MaxLength = 100;

            DaftarSupplier daftar = new DaftarSupplier();

            string hasil = daftar.GenerateCode();

            if (hasil == "sukses")
            {
                textBoxKodeSupplier.Text = daftar.KodeTerbaru.ToString();
                textBoxKodeSupplier.Enabled = false;
            }
            else
            {
                MessageBox.Show("Generate kode gagal dilakukan. Pesan kesalahan : " + hasil);
            }
        }

        private void FormTambahSupplier_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarSupplier)this.Owner;
            form.FormDaftarSupplier_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar)) e.Handled = true; // user bisa input ketika inputannya bukan angka
        }

        //private void textBoxNama_Leave(object sender, EventArgs e)
        //{
        //    if (textBoxNama.Text == "")
        //    {
        //        textBoxNama.Text = "UD. Subur Selalu";

        //        textBoxNama.ForeColor = Color.Silver;
        //    }
        //}

        //private void textBoxNama_Enter(object sender, EventArgs e)
        //{
        //    if (textBoxNama.Text == "UD. Subur Selalu")
        //    {
        //        textBoxNama.Text = "";

        //        textBoxNama.ForeColor = Color.Black;
        //    }
        //}

        //private void richTextBoxAlamat_Enter(object sender, EventArgs e)
        //{
        //    if (richTextBoxAlamat.Text == "Raya Jemursari 123")
        //    {
        //        richTextBoxAlamat.Text = "";

        //        richTextBoxAlamat.ForeColor = Color.Black;
        //    }
        //}

        //private void richTextBoxAlamat_Leave(object sender, EventArgs e)
        //{
        //    if (richTextBoxAlamat.Text == "")
        //    {
        //        richTextBoxAlamat.Text = "Raya Jemursari 123";

        //        richTextBoxAlamat.ForeColor = Color.Silver;
        //    }
        //}
    }
}
