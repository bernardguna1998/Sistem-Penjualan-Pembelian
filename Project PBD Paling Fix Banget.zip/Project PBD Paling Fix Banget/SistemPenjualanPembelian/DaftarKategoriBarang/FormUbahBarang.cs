﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormUbahBarang : Form
    {
        FormDaftarBarang form;
        
        public FormUbahBarang()
        {
            InitializeComponent();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarBarang)this.Owner;
            form.FormDaftarBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
                try
                {
                    string kodeKategori = comboBoxKodeKategori.Text.Substring(0, 2); //dimulai dari 0, diambilnya cuman 2
                    string namaKategori = comboBoxKodeKategori.Text.Substring(5, comboBoxKodeKategori.Text.Length - 5);

                    Kategori kat = new Kategori(kodeKategori, namaKategori);

                    Barang b = new Barang();
                    b.KodeBarang = textBoxKodeBarang.Text;
                    b.NamaBarang = textBoxNamaBarang.Text;
                    b.HargaJual = int.Parse(textBoxHargaJual.Text);
                    b.Stok = int.Parse(textBoxStok.Text);
                    b.KategoriBarang = kat;

                    DaftarBarang daftar = new DaftarBarang();

                    string hasil = daftar.UbahData(b);
                    if (hasil == "sukses")
                    {
                        MessageBox.Show("Data telah tersimpan", "Info");
                        buttonKosongi_Click(buttonSimpan, e);
                    }
                    else
                    {
                        MessageBox.Show("Data gagal disimpan. Pesan kesalahan : " + hasil, "Kesalahan");
                    }
                }
                catch (Exception ex)
                {
                    if (textBoxStok.Text == "")
                    {
                        MessageBox.Show("Gagal mengubah data. Stok tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                    else if (textBoxHargaJual.Text == "")
                    {
                        MessageBox.Show("Gagal mengubah data. Harga Jual tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                    else if(textBoxKodeBarang.Text == "")
                    {
                        MessageBox.Show("Gagal mengubah data. Kode Barang tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                    else
                    {
                        MessageBox.Show("Gagal mengubah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                }
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeBarang.Clear();
            textBoxNamaBarang.Clear();
            textBoxHargaJual.Clear();
            textBoxStok.Clear();
            comboBoxKodeKategori.SelectedIndex = 0;
        }

        private void FormUbahBarang_Load(object sender, EventArgs e)
        {

            textBoxKodeBarang.MaxLength = 5;
            textBoxNamaBarang.MaxLength = 45;
            textBoxHargaJual.MaxLength = 11;
            textBoxStok.MaxLength = 6;

            DaftarKategori daftarKat = new DaftarKategori();
            string hasilBaca = daftarKat.BacaSemuaData();

            if (hasilBaca == "sukses")
            {
                comboBoxKodeKategori.Items.Clear();

                for (int i = 0; i < daftarKat.JumlahKategoriBarang; i++)
                {
                    comboBoxKodeKategori.Items.Add(daftarKat.DaftarKategoriBarang[i].KodeKategori + " - " + daftarKat.DaftarKategoriBarang[i].NamaKategori);
                }
            }
            else
            {
                MessageBox.Show("Kategori gagal ditampilkan di comboBox. Pesan kesalahan : " + hasilBaca);
            }

            comboBoxKodeKategori.SelectedIndex = 0;
        }

        private void textBoxKodeBarang_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodeBarang.Text.Length == textBoxKodeBarang.MaxLength)
            {
                DaftarBarang daftar = new DaftarBarang();
                string hasil = daftar.CariData("KodeBarang", textBoxKodeBarang.Text);
                if (hasil == "sukses")
                {
                    if (daftar.JumlahBarang > 0)
                    {
                        textBoxNamaBarang.Text = daftar.ListBarang[0].NamaBarang;
                        textBoxStok.Text = daftar.ListBarang[0].Stok.ToString();
                        comboBoxKodeKategori.Text = daftar.ListBarang[0].KategoriBarang.KodeKategori + " - " + daftar.ListBarang[0].KategoriBarang.NamaKategori;
                        textBoxHargaJual.Text = daftar.ListBarang[0].HargaJual.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Kode barang tidak ditemukan. Proses Ubah Data tidak bisa dilakukan.");
                        //ketemu = false;
                        textBoxHargaJual.Clear();
                        textBoxNamaBarang.Clear();
                        textBoxStok.Clear();
                        textBoxKodeBarang.Clear();
                        comboBoxKodeKategori.SelectedIndex = 0;
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }
            else if (textBoxKodeBarang.Text == "")
            {
                textBoxHargaJual.Clear();
                textBoxNamaBarang.Clear();
                textBoxStok.Clear();
                comboBoxKodeKategori.SelectedIndex = 0;
            }
        }

        private void FormUbahBarang_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarBarang)this.Owner;
            form.FormDaftarBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNamaBarang_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        private void textBoxHargaJual_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBoxStok_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
