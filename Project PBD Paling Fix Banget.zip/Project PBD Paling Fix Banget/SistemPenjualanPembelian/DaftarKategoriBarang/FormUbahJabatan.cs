﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormUbahJabatan : Form
    {
        FormDaftarJabatan form;
        
        public FormUbahJabatan()
        {
            InitializeComponent();
        }

        private void FormUbahJabatan_Load(object sender, EventArgs e)
        {

            textBoxIdJabatan.Focus();
            textBoxIdJabatan.Select();

            textBoxIdJabatan.MaxLength = 2;
            textBoxNama.MaxLength = 45;
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Jabatan j = new Jabatan();
                j.IdJabatan = textBoxIdJabatan.Text;
                j.NamaJabatan = textBoxNama.Text;

                DaftarJabatan daftar = new DaftarJabatan();

                string hasilTambah = daftar.UbahData(j);

                if (hasilTambah == "sukses")
                {
                    MessageBox.Show("Data jabatan berhasil diubah", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data jabatan tidak berhasil diubah. Pesan kesalahan : " + hasilTambah, " Kesalahan");
                }
            }
            catch(Exception ex)
            {
                if(textBoxIdJabatan.Text == "")
                {
                    MessageBox.Show("Gagal mengubah data. Id jabatan tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
                else
                {
                    MessageBox.Show("Data jabatan tidak berhasil diubah. Pesan kesalahan : " + ex.Message, "Info Kesalahan");
                }
            }
                
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxIdJabatan.Clear();
            textBoxNama.Clear();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarJabatan)this.Owner;
            form.FormDaftarJabatan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxIdJabatan_TextChanged(object sender, EventArgs e)
        {
            if (textBoxIdJabatan.Text.Length == textBoxIdJabatan.MaxLength)
            {
                DaftarJabatan daftar = new DaftarJabatan();
                string hasil = daftar.CariData("IdJabatan", textBoxIdJabatan.Text);
                if (hasil == "sukses")
                {
                    if (daftar.JumlahJabatan> 0)
                    {
                        textBoxNama.Text = daftar.ListJabatan[0].NamaJabatan;
                        
                    }
                    else
                    {
                        MessageBox.Show("Id Jabatan tidak ditemukan. Proses ubah data tidak bisa dilakukan");
                        textBoxNama.Text = "";
                        textBoxIdJabatan.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }

            else if (textBoxIdJabatan.Text == "")
            {
                textBoxNama.Clear();
            }
        }

        private void FormUbahJabatan_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarJabatan)this.Owner;
            form.FormDaftarJabatan_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNama_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }
    }
}
