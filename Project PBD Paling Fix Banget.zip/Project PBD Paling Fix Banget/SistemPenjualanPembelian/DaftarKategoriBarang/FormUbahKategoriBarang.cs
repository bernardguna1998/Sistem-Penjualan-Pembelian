﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormUbahKategoriBarang : Form
    {
        FormDaftarKategoriBarang form;
        
        public FormUbahKategoriBarang()
        {
            InitializeComponent();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Kategori k = new Kategori();
                k.KodeKategori = textBoxKodeKategori.Text;
                k.NamaKategori = textBoxNamaKategori.Text;

                DaftarKategori daftar = new DaftarKategori();

                string hasilUbah = daftar.UpdateData(k);

                if (hasilUbah == "sukses")
                {
                    MessageBox.Show("Data kategori telah diubah", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data kategori tidak berhasil diubah. Pesan Kesalahan : " + hasilUbah, " Kesalahan");
                }
            }
            catch(Exception ex)
            {
                if(textBoxKodeKategori.Text == "")
                {
                    MessageBox.Show("Gagal mengubah data. Kode kategori tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
                else
                {
                    MessageBox.Show("Gagal menambah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                }
            }
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodeKategori.Text = "";
            textBoxNamaKategori.Text = "";
            textBoxKodeKategori.Focus();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarKategoriBarang)this.Owner;
            form.FormDaftarKategoriBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
            this.Close();
        }

        private void FormUbahKategoriBarang_Load(object sender, EventArgs e)
        {
            textBoxKodeKategori.MaxLength = 2;
            textBoxNamaKategori.MaxLength = 30;
        }

        private void textBoxKodeKategori_TextChanged(object sender, EventArgs e)
        {
            if(textBoxKodeKategori.Text.Length == textBoxKodeKategori.MaxLength)
            {
                DaftarKategori daftar = new DaftarKategori();
                string hasil = daftar.CariData("KodeKategori", textBoxKodeKategori.Text);
                if(hasil == "sukses")
                {
                    if(daftar.JumlahKategoriBarang > 0)
                    {
                        textBoxNamaKategori.Text = daftar.DaftarKategoriBarang[0].NamaKategori;
                    }
                    else
                    {
                        MessageBox.Show("Kode kategori tidak ditemukan. Proses ubah data tidak bisa dilakukan");
                        textBoxKodeKategori.Clear();
                        textBoxNamaKategori.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }
            
            else if (textBoxKodeKategori.Text == "")
            {
                textBoxNamaKategori.Clear();
            }
                    
        }

        private void FormUbahKategoriBarang_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarKategoriBarang)this.Owner;
            form.FormDaftarKategoriBarang_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNamaKategori_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }
    }
}
