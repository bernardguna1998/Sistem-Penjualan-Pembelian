﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormUbahPegawai : Form
    {
        FormDaftarPegawai form;
        
        public FormUbahPegawai()
        {
            InitializeComponent();
        }

        private void FormUbahPegawai_Load(object sender, EventArgs e)
        {

            textBoxUsername.Enabled = false;

            textBoxKodePegawai.MaxLength = 11; //max lengthnya kode pegawai 11 (untuk mencegah kesalahan input, karena max length di database juga 11)
            textBoxPwd.MaxLength = 8; //max lengthnya password adalah 8
            textBoxUsername.MaxLength = 8;//max lengthnya username adalah 8
            textBoxUlangiPwd.MaxLength = 8; //max lengthnya password adalah 8
            textBoxNamaPegawai.MaxLength = 45; //max lengthnya nama pegawai = 45
            richTextBoxAlamat.MaxLength = 100; //max lengthnya alamat adalah 100

            DaftarJabatan daftarJ = new DaftarJabatan();

            string hasil = daftarJ.BacaSemuaData();

            if (hasil == "sukses")
            {
                comboBoxJabatan.Items.Clear(); //dihapus dulu di comboboxnya

                for (int i = 0; i < daftarJ.JumlahJabatan; i++) //isi combobox dengan perulangan/looping dengan memanggil list jabatan
                {
                    comboBoxJabatan.Items.Add(daftarJ.ListJabatan[i].IdJabatan + " - " + daftarJ.ListJabatan[i].NamaJabatan);
                }

                comboBoxJabatan.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Id Jabatan gagal ditampilkan di comboBox. Pesan kesalahan : " + hasil);
            }
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarPegawai)this.Owner;
            form.FormDaftarPegawai_Load(buttonKeluar, e); //method refresh

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxKodePegawai_TextChanged(object sender, EventArgs e)
        {
            if (textBoxKodePegawai.Text.Length <= textBoxKodePegawai.MaxLength)
            {
                DaftarPegawai daftar = new DaftarPegawai();

                string hasil = daftar.CariData("KodePegawai", textBoxKodePegawai.Text);

                if (hasil == "sukses")
                {
                    if (textBoxKodePegawai.Text == "")
                    {
                        textBoxNamaPegawai.Clear();
                        textBoxPwd.Clear();
                        comboBoxJabatan.SelectedIndex = 0;
                        textBoxUsername.Clear();
                        dateTimePickerTglLhr.Value = DateTime.Now;
                        textBoxGaji.Clear();
                        richTextBoxAlamat.Clear();
                    }
                    else if (daftar.JumlahPegawai > 0)
                    {
                        textBoxNamaPegawai.Text = daftar.ListPegawai[0].Nama;
                        dateTimePickerTglLhr.Value = DateTime.Parse(daftar.ListPegawai[0].TanggalLahir);
                        richTextBoxAlamat.Text = daftar.ListPegawai[0].Alamat;
                        textBoxUsername.Text = daftar.ListPegawai[0].Username;
                        textBoxUsername.Enabled = false;
                        textBoxPwd.Text = daftar.ListPegawai[0].Pwd;
                        textBoxGaji.Text = daftar.ListPegawai[0].Gaji.ToString();
                        comboBoxJabatan.Text = daftar.ListPegawai[0].Jabatan.IdJabatan + " - " + daftar.ListPegawai[0].Jabatan.NamaJabatan;

                    }
                    else
                    {
                        MessageBox.Show("Kode pegawai tidak ditemukan. Proses Ubah Data tidak bisa dilakukan.");
                        textBoxKodePegawai.Clear();
                        textBoxNamaPegawai.Clear();
                        textBoxPwd.Clear();
                        comboBoxJabatan.SelectedIndex = 0;
                        textBoxUsername.Clear();
                        dateTimePickerTglLhr.Value = DateTime.Now;
                        textBoxGaji.Clear();
                        richTextBoxAlamat.Clear();
                    }


                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodePegawai.Clear();
            textBoxNamaPegawai.Clear();
            textBoxPwd.Clear();
            comboBoxJabatan.SelectedIndex = 0;
            textBoxUsername.Clear();
            dateTimePickerTglLhr.Value = DateTime.Now;
            textBoxGaji.Clear();
            richTextBoxAlamat.Clear();
            textBoxUlangiPwd.Clear();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            
                try
                {
                    if (textBoxPwd.Text == textBoxUlangiPwd.Text)
                    {
                        string kodeJab = comboBoxJabatan.Text.Substring(0, 2); //dimulai dari 0, diambilnya cuman 2
                        string namaJab = comboBoxJabatan.Text.Substring(5, comboBoxJabatan.Text.Length - 5);

                        Jabatan j = new Jabatan(kodeJab, namaJab);

                        Pegawai p = new Pegawai();
                        p.KodePegawai = int.Parse(textBoxKodePegawai.Text);
                        p.Nama = textBoxNamaPegawai.Text;
                        p.TanggalLhr = dateTimePickerTglLhr.Value;
                        p.Alamat = richTextBoxAlamat.Text;
                        p.Gaji = int.Parse(textBoxGaji.Text);
                        p.Username = textBoxUsername.Text;
                        p.Pwd = textBoxPwd.Text;
                        p.Jabatan = j;

                        DaftarPegawai daftar = new DaftarPegawai();

                        string hasilTambah = daftar.UbahData(p);

                        if (hasilTambah == "sukses")
                        {
                            MessageBox.Show("Data pegawai telah diubah", "Info");

                            buttonKosongi_Click(buttonSimpan, e);
                            FormUbahPegawai_Load(buttonSimpan, e);
                        }
                        else
                        {
                            MessageBox.Show("Data barang gagal tersimpan. Pesan kesalahan : " + hasilTambah, "Kesalahan");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password yang Anda Masukan Tidak Sama. Mohon periksa kembali password anda");
                    }
                }
                catch (Exception ex)
                {
                    if (textBoxGaji.Text == "")
                    {
                        MessageBox.Show("Gagal mengubah data. Gaji tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                    else if (textBoxKodePegawai.Text == "")
                    {
                        MessageBox.Show("Gagal mengubah data. Kode pegawai tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                    else
                    {
                        MessageBox.Show("Gagal mengubah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                }
        }

        private void FormUbahPegawai_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarPegawai)this.Owner;
            form.FormDaftarPegawai_Load(buttonKeluar, e);

            this.Owner.Enabled = true;
        }

        private void textBoxNamaPegawai_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }

        private void textBoxGaji_KeyPress(object sender, KeyPressEventArgs e)
        {
            //This code only allowing numbers and the backspace.
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
