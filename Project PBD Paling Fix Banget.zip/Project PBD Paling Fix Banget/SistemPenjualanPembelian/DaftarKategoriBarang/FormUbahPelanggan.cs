﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PenjualanPembelian_LIB;

namespace DaftarKategoriBarang
{
    public partial class FormUbahPelanggan : Form
    {
        FormDaftarPelanggan form;
        

        public FormUbahPelanggan()
        {
            InitializeComponent();
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            try
            {
                Pelanggan p = new Pelanggan();
                p.KodePelanggan = int.Parse(textBoxKodePelanggan.Text);
                p.NamaPelanggan = textBoxNamaPelanggan.Text;
                p.Alamat = textBoxAlamat.Text;
                p.Telepon = textBoxTelepon.Text;

                DaftarPelanggan daftar = new DaftarPelanggan();

                string hasil = daftar.UbahData(p);
                if (hasil == "sukses")
                {
                    MessageBox.Show("Data telah tersimpan", "Info");
                    buttonKosongi_Click(buttonSimpan, e);
                }
                else
                {
                    MessageBox.Show("Data gagal disimpan. Pesan kesalahan : " + hasil, "kesalahan");
                }
            }
            catch(Exception ex)
            {
                    if (textBoxKodePelanggan.Text == "")
                    {
                        MessageBox.Show("Gagal mengubah data. Kode pelanggan tidak boleh dikosongi. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
                    else
                    {
                        MessageBox.Show("Gagal mengubah data. Pesan kesalahan : " + ex.Message, "Pesan Kesalahan");
                    }
            }
                
        }

        private void buttonKosongi_Click(object sender, EventArgs e)
        {
            textBoxKodePelanggan.Text = "";
            textBoxNamaPelanggan.Text = "";
            textBoxAlamat.Text = "";
            textBoxTelepon.Text = "";
            textBoxKodePelanggan.Focus();
        }

        private void buttonKeluar_Click(object sender, EventArgs e)
        {
            form = (FormDaftarPelanggan)this.Owner;
            form.FormDaftarPelanggan_Load(buttonKeluar, e); //method refresh

            this.Owner.Enabled = true;
            this.Close();
        }

        private void textBoxKodePelanggan_TextChanged(object sender, EventArgs e)
        {
            if(textBoxKodePelanggan.Text.Length <= textBoxKodePelanggan.MaxLength)
            {
                DaftarPelanggan daftar = new DaftarPelanggan();
                string hasil = daftar.CariData("KodePelanggan", textBoxKodePelanggan.Text);
                if(hasil == "sukses")
                {
                    if (textBoxKodePelanggan.Text == "") //kalau misalnya kosong, maka semua field yang ada di form dihapus
                    {
                        textBoxNamaPelanggan.Clear();
                        textBoxTelepon.Clear();
                        textBoxAlamat.Clear();
                    }   
                    else if(daftar.JumlahPelanggan > 0)
                    {
                        textBoxNamaPelanggan.Text = daftar.DaftarInformasiPelanggan[0].NamaPelanggan;
                        textBoxAlamat.Text = daftar.DaftarInformasiPelanggan[0].Alamat;
                        textBoxTelepon.Text = daftar.DaftarInformasiPelanggan[0].Telepon;
                    }
                    else
                    {
                        MessageBox.Show("Kode pelanggan tidak ditemukan. Proses Ubah Data tidak bisa dilakukan.");
                        textBoxKodePelanggan.Clear();
                        textBoxNamaPelanggan.Clear();
                        textBoxTelepon.Clear();
                        textBoxAlamat.Clear();
                    }   

                    
                }
                else
                {
                    MessageBox.Show("Perintah SQL gagal dijalankan. Pesan Kesalahan : " + hasil);
                }
            }

        }

        private void FormUbahPelanggan_Load(object sender, EventArgs e)
        {
            textBoxKodePelanggan.MaxLength = 11; //max karakter kode pelanggan adalah 11
            textBoxTelepon.MaxLength = 20; //max karakter telepon adalah 20
            textBoxNamaPelanggan.MaxLength = 50; //max karakter nama pelanggan adalah 50
            textBoxAlamat.MaxLength = 100; //max karakter alamat pelanggan adalah 100
        }

        private void FormUbahPelanggan_FormClosing(object sender, FormClosingEventArgs e)
        {
            form = (FormDaftarPelanggan)this.Owner;
            form.FormDaftarPelanggan_Load(buttonKeluar, e); //method refresh

            this.Owner.Enabled = true;
        }

        private void textBoxTelepon_KeyDown(object sender, KeyEventArgs e)
        {
            //digit = angka
            //suppressKey berfungsi untuk mencegah apakah inputan boleh dimasukkan ke textBox atau tidak           
            if (!Char.IsDigit((char)e.KeyValue)) //artinya kalao karakternya bukan digit (means: huruf) maka lakukan perintah dibaah ini
            {
                if (e.KeyCode == Keys.Back || e.KeyCode == Keys.OemCloseBrackets || e.KeyCode == Keys.OemOpenBrackets || e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Oemplus)
                {
                    e.SuppressKeyPress = false;
                }
                else
                {
                    e.SuppressKeyPress = true; //selain back/hapus, (, ), -, maka tidak bisa diakses
                }
            }        
        }

        private void textBoxNamaPelanggan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space);
        }
    }
}
