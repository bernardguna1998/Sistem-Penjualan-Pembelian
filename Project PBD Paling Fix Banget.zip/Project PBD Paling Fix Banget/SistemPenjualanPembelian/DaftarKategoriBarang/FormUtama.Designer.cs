﻿namespace DaftarKategoriBarang
{
    partial class FormUtama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kategoriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pelangganToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pegawaiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jabatanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaksiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.penjualanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pembelianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanMasterBarang = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanMasterKategori = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanMasterPelanggan = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanMasterSupplier = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanMasterPegawai = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanTransaksiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanTransaksiPenjualan = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanTransaksiPembelian = new System.Windows.Forms.ToolStripMenuItem();
            this.keluarSistemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.labelKodePegawai = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelNamaPegawai = new System.Windows.Forms.Label();
            this.labelJabatan = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.transaksiToolStripMenuItem,
            this.laporanToolStripMenuItem,
            this.keluarSistemToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(689, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.AccessibleName = "";
            this.masterToolStripMenuItem.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.barangToolStripMenuItem,
            this.kategoriToolStripMenuItem,
            this.pelangganToolStripMenuItem,
            this.supplierToolStripMenuItem,
            this.pegawaiToolStripMenuItem1,
            this.jabatanToolStripMenuItem});
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.masterToolStripMenuItem.Text = "Master";
            this.masterToolStripMenuItem.Click += new System.EventHandler(this.masterToolStripMenuItem_Click);
            // 
            // barangToolStripMenuItem
            // 
            this.barangToolStripMenuItem.Name = "barangToolStripMenuItem";
            this.barangToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.barangToolStripMenuItem.Text = "Barang";
            this.barangToolStripMenuItem.Click += new System.EventHandler(this.barangToolStripMenuItem_Click);
            // 
            // kategoriToolStripMenuItem
            // 
            this.kategoriToolStripMenuItem.Name = "kategoriToolStripMenuItem";
            this.kategoriToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.kategoriToolStripMenuItem.Text = "Kategori";
            this.kategoriToolStripMenuItem.Click += new System.EventHandler(this.kategoriToolStripMenuItem_Click);
            // 
            // pelangganToolStripMenuItem
            // 
            this.pelangganToolStripMenuItem.Name = "pelangganToolStripMenuItem";
            this.pelangganToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.pelangganToolStripMenuItem.Text = "Pelanggan";
            this.pelangganToolStripMenuItem.Click += new System.EventHandler(this.pelangganToolStripMenuItem_Click);
            // 
            // supplierToolStripMenuItem
            // 
            this.supplierToolStripMenuItem.Name = "supplierToolStripMenuItem";
            this.supplierToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.supplierToolStripMenuItem.Text = "Supplier";
            this.supplierToolStripMenuItem.Click += new System.EventHandler(this.supplierToolStripMenuItem_Click);
            // 
            // pegawaiToolStripMenuItem1
            // 
            this.pegawaiToolStripMenuItem1.Name = "pegawaiToolStripMenuItem1";
            this.pegawaiToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.pegawaiToolStripMenuItem1.Text = "Pegawai";
            this.pegawaiToolStripMenuItem1.Click += new System.EventHandler(this.pegawaiToolStripMenuItem1_Click);
            // 
            // jabatanToolStripMenuItem
            // 
            this.jabatanToolStripMenuItem.Name = "jabatanToolStripMenuItem";
            this.jabatanToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.jabatanToolStripMenuItem.Text = "Jabatan";
            this.jabatanToolStripMenuItem.Click += new System.EventHandler(this.jabatanToolStripMenuItem_Click);
            // 
            // transaksiToolStripMenuItem
            // 
            this.transaksiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.penjualanToolStripMenuItem,
            this.pembelianToolStripMenuItem});
            this.transaksiToolStripMenuItem.Name = "transaksiToolStripMenuItem";
            this.transaksiToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.transaksiToolStripMenuItem.Text = "Transaksi";
            // 
            // penjualanToolStripMenuItem
            // 
            this.penjualanToolStripMenuItem.Name = "penjualanToolStripMenuItem";
            this.penjualanToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.penjualanToolStripMenuItem.Text = "Penjualan";
            this.penjualanToolStripMenuItem.Click += new System.EventHandler(this.penjualanToolStripMenuItem_Click);
            // 
            // pembelianToolStripMenuItem
            // 
            this.pembelianToolStripMenuItem.Name = "pembelianToolStripMenuItem";
            this.pembelianToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.pembelianToolStripMenuItem.Text = "Pembelian";
            this.pembelianToolStripMenuItem.Click += new System.EventHandler(this.pembelianToolStripMenuItem_Click);
            // 
            // laporanToolStripMenuItem
            // 
            this.laporanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laporanMasterToolStripMenuItem,
            this.laporanTransaksiToolStripMenuItem});
            this.laporanToolStripMenuItem.Name = "laporanToolStripMenuItem";
            this.laporanToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.laporanToolStripMenuItem.Text = "Laporan";
            // 
            // laporanMasterToolStripMenuItem
            // 
            this.laporanMasterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laporanMasterBarang,
            this.laporanMasterKategori,
            this.laporanMasterPelanggan,
            this.laporanMasterSupplier,
            this.laporanMasterPegawai});
            this.laporanMasterToolStripMenuItem.Name = "laporanMasterToolStripMenuItem";
            this.laporanMasterToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.laporanMasterToolStripMenuItem.Text = "Laporan Master";
            // 
            // laporanMasterBarang
            // 
            this.laporanMasterBarang.Name = "laporanMasterBarang";
            this.laporanMasterBarang.Size = new System.Drawing.Size(152, 22);
            this.laporanMasterBarang.Text = "Barang";
            this.laporanMasterBarang.Click += new System.EventHandler(this.laporanMasterBarang_Click);
            // 
            // laporanMasterKategori
            // 
            this.laporanMasterKategori.Name = "laporanMasterKategori";
            this.laporanMasterKategori.Size = new System.Drawing.Size(152, 22);
            this.laporanMasterKategori.Text = "Kategori";
            this.laporanMasterKategori.Click += new System.EventHandler(this.laporanMasterKategori_Click);
            // 
            // laporanMasterPelanggan
            // 
            this.laporanMasterPelanggan.Name = "laporanMasterPelanggan";
            this.laporanMasterPelanggan.Size = new System.Drawing.Size(152, 22);
            this.laporanMasterPelanggan.Text = "Pelanggan";
            this.laporanMasterPelanggan.Click += new System.EventHandler(this.laporanMasterPelanggan_Click);
            // 
            // laporanMasterSupplier
            // 
            this.laporanMasterSupplier.Name = "laporanMasterSupplier";
            this.laporanMasterSupplier.Size = new System.Drawing.Size(152, 22);
            this.laporanMasterSupplier.Text = "Supplier";
            this.laporanMasterSupplier.Click += new System.EventHandler(this.laporanMasterSupplier_Click);
            // 
            // laporanMasterPegawai
            // 
            this.laporanMasterPegawai.Name = "laporanMasterPegawai";
            this.laporanMasterPegawai.Size = new System.Drawing.Size(152, 22);
            this.laporanMasterPegawai.Text = "Pegawai";
            this.laporanMasterPegawai.Click += new System.EventHandler(this.laporanMasterPegawai_Click);
            // 
            // laporanTransaksiToolStripMenuItem
            // 
            this.laporanTransaksiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laporanTransaksiPenjualan,
            this.laporanTransaksiPembelian});
            this.laporanTransaksiToolStripMenuItem.Name = "laporanTransaksiToolStripMenuItem";
            this.laporanTransaksiToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.laporanTransaksiToolStripMenuItem.Text = "Laporan Transaksi";
            // 
            // laporanTransaksiPenjualan
            // 
            this.laporanTransaksiPenjualan.Name = "laporanTransaksiPenjualan";
            this.laporanTransaksiPenjualan.Size = new System.Drawing.Size(152, 22);
            this.laporanTransaksiPenjualan.Text = "Penjualan";
            this.laporanTransaksiPenjualan.Click += new System.EventHandler(this.laporanTransaksiPenjualan_Click);
            // 
            // laporanTransaksiPembelian
            // 
            this.laporanTransaksiPembelian.Name = "laporanTransaksiPembelian";
            this.laporanTransaksiPembelian.Size = new System.Drawing.Size(152, 22);
            this.laporanTransaksiPembelian.Text = "Pembelian";
            this.laporanTransaksiPembelian.Click += new System.EventHandler(this.laporanTransaksiPembelian_Click);
            // 
            // keluarSistemToolStripMenuItem
            // 
            this.keluarSistemToolStripMenuItem.Name = "keluarSistemToolStripMenuItem";
            this.keluarSistemToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.keluarSistemToolStripMenuItem.Text = "Keluar Sistem";
            this.keluarSistemToolStripMenuItem.Click += new System.EventHandler(this.keluarSistemToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(363, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Anda login sebagai : ";
            // 
            // labelKodePegawai
            // 
            this.labelKodePegawai.AutoSize = true;
            this.labelKodePegawai.Location = new System.Drawing.Point(475, 2);
            this.labelKodePegawai.Name = "labelKodePegawai";
            this.labelKodePegawai.Size = new System.Drawing.Size(35, 13);
            this.labelKodePegawai.TabIndex = 2;
            this.labelKodePegawai.Text = "Kode ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(516, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "-";
            // 
            // labelNamaPegawai
            // 
            this.labelNamaPegawai.AutoSize = true;
            this.labelNamaPegawai.Location = new System.Drawing.Point(530, 2);
            this.labelNamaPegawai.Name = "labelNamaPegawai";
            this.labelNamaPegawai.Size = new System.Drawing.Size(79, 13);
            this.labelNamaPegawai.TabIndex = 4;
            this.labelNamaPegawai.Text = "Nama Pegawai";
            // 
            // labelJabatan
            // 
            this.labelJabatan.AutoSize = true;
            this.labelJabatan.Location = new System.Drawing.Point(630, 2);
            this.labelJabatan.Name = "labelJabatan";
            this.labelJabatan.Size = new System.Drawing.Size(45, 13);
            this.labelJabatan.TabIndex = 5;
            this.labelJabatan.Text = "Jabatan";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(614, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "-";
            // 
            // FormUtama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 417);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelJabatan);
            this.Controls.Add(this.labelNamaPegawai);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelKodePegawai);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormUtama";
            this.Text = "Sistem Informasi Penjualan dan Pembelian";
            this.Load += new System.EventHandler(this.FormUtama_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem keluarSistemToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem barangToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem kategoriToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem pelangganToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem supplierToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem pegawaiToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem transaksiToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem penjualanToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem pembelianToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem laporanToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem laporanMasterToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem laporanMasterBarang;
        public System.Windows.Forms.ToolStripMenuItem laporanMasterKategori;
        public System.Windows.Forms.ToolStripMenuItem laporanMasterPelanggan;
        public System.Windows.Forms.ToolStripMenuItem laporanMasterSupplier;
        public System.Windows.Forms.ToolStripMenuItem laporanMasterPegawai;
        public System.Windows.Forms.ToolStripMenuItem laporanTransaksiToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem laporanTransaksiPenjualan;
        public System.Windows.Forms.ToolStripMenuItem laporanTransaksiPembelian;
        public System.Windows.Forms.ToolStripMenuItem jabatanToolStripMenuItem;
        public System.Windows.Forms.Label labelKodePegawai;
        public System.Windows.Forms.Label labelNamaPegawai;
        public System.Windows.Forms.Label labelJabatan;
        private System.Windows.Forms.Label label2;
    }
}