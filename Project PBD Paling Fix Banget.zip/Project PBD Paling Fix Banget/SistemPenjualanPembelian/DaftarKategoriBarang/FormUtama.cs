﻿using SistemPenjualanPembelian;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaftarKategoriBarang
{
    public partial class FormUtama : Form
    {
        public FormUtama()
        {
            InitializeComponent();
        }

        private void FormUtama_Load(object sender, EventArgs e)
        {
            //ubah form utama menjadi fullscreen
            this.WindowState = FormWindowState.Maximized;

            //ubah formutama menjadi mdiparent (mdicontainer)
            this.IsMdiContainer = true;

            //agar form utama tdk bisa diakses jika blm login
            this.Enabled = false;

            //menampilkan form log in ketika dijalankan
            FormLogin formLog = new FormLogin();
            formLog.Owner = this;
            formLog.Show();
        }

        private void barangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarBarang"];

            if (form == null)
            {
                FormDaftarBarang formBrg = new FormDaftarBarang();
                formBrg.MdiParent = this;
                formBrg.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void kategoriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarKategoriBarang"];

            if (form == null)
            {
                FormDaftarKategoriBarang formCat = new FormDaftarKategoriBarang();
                formCat.MdiParent = this;
                formCat.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }

            //FormDaftarKategoriBarang formCat = new FormDaftarKategoriBarang();
            //formCat.MdiParent = this;
            //formCat.Show();
        }

        private void pelangganToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //kalo form ini
            //form nya hanya bsia diklik 1 kali dan 1 kali muncul aja
            Form form = Application.OpenForms["FormDaftarPelanggan"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormDaftarPelanggan formPel = new FormDaftarPelanggan();
                formPel.MdiParent = this;
                formPel.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }

            //FormDaftarPelanggan formPel = new FormDaftarPelanggan();
            //formPel.MdiParent = this;
            //formPel.Show();
        }

        private void jabatanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarJabatan"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormDaftarJabatan formJ = new FormDaftarJabatan();
                formJ.MdiParent = this;
                formJ.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void pegawaiToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarPegawai"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormDaftarPegawai formP = new FormDaftarPegawai();
                formP.MdiParent = this;
                formP.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void keluarSistemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void masterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void supplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarSupplier"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormDaftarSupplier formN = new FormDaftarSupplier();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void penjualanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarNotaJual"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormDaftarNotaJual formN = new FormDaftarNotaJual();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void pembelianToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormDaftarNotaBeli"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormDaftarNotaBeli formN = new FormDaftarNotaBeli();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanTransaksiPenjualan_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportPenjualan"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportPenjualan formN = new FormReportPenjualan();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanTransaksiPembelian_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportPembelian"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportPembelian formN = new FormReportPembelian();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanMasterBarang_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportBarang"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportBarang formN = new FormReportBarang();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanMasterKategori_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportKategori"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportKategori formN = new FormReportKategori();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanMasterPelanggan_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportPelanggan"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportPelanggan formN = new FormReportPelanggan();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanMasterSupplier_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportSupplier"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportSupplier formN = new FormReportSupplier();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }

        private void laporanMasterPegawai_Click(object sender, EventArgs e)
        {
            Form form = Application.OpenForms["FormReportPegawai"]; //bisa pake form1 soalnya masih pake nama avriable form yg sebelumnya

            if (form == null)
            {
                FormReportPegawai formN = new FormReportPegawai();
                formN.MdiParent = this;
                formN.Show();
            }
            else
            {
                form.Show();
                form.BringToFront();
            }
        }
    }
}
