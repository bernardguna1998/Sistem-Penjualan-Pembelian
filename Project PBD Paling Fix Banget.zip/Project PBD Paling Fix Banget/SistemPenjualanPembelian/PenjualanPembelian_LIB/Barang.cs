﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class Barang //one to many
    {
        #region DATAMEMBER
        private string kodeBarang;
        private string namaBarang;
        private int hargaJual;
        private int stok;
        private Kategori kategoriBarang;
        #endregion

        #region PROPERTIES
        public string KodeBarang
        {
            get { return kodeBarang; }
            set 
            { 
                kodeBarang = value; 

                if(kodeBarang == "")
                {
                    throw (new Exception("Mohon maaf, kode barang tidak boleh dikosongi."));
                }
            }
        }

        public string NamaBarang
        {
            get { return namaBarang; }
            set
            {
                namaBarang = value;

                if (namaBarang == "")
                {
                    throw (new Exception("Mohon maaf, nama barang tidak boleh dikosongi."));
                }
            }
        }

        public int HargaJual
        {
            get 
            { 
                return hargaJual; 
            } //get itu untuk menampilkan, contohnya kyk System.Console.Write(person.Name);  
            set 
            {
                hargaJual = value; 

                if(hargaJual > 0) //ketika hargaJual > 0
                {
                    hargaJual = value; 
                }
                else if(hargaJual <= 0) //ketika hargaJual <= 0, maka tampilkan pesan error
                {
                    throw (new ArgumentOutOfRangeException("Harga Jual tidak boleh bernilai nol atau negatif."));
                } 
            } //set itu untuk ngeset field kyk input, contoh person.Name = "Joe";
        }

        public int Stok
        {
            get 
            {
                return stok;
            }
            set
            {
                stok = value;

                if (stok > 0) //ketika stok > 0
                {
                    stok = value;
                }
                else if(stok <= 0) //ketika stok <= 0, maka tampilkan pesan error
                {
                    throw (new ArgumentOutOfRangeException("Stok minimal satu."));
                }
            }
            
        }

        public int GetStok
        {
            get
            {
                return stok;
            }
        }

        //public string KodeKategoriBarang
        //{
        //    get { return kategoriBarang.KodeKategori; }
        //    set { KodeKategoriBarang = value; }
        //}

        //public string NamaKategoriBarang
        //{
        //    get { return kategoriBarang.NamaKategori; }
        //    set { NamaKategoriBarang = value; }
        //}

        public Kategori KategoriBarang
        {
            get { return kategoriBarang; } //mendapatkan isi dr Class Kategori Barang
            set { kategoriBarang = value; }
        }
        #endregion

        #region CONSTRUCTOR

        public Barang()
        {
            kodeBarang = "";
            namaBarang = "";
            hargaJual = 0;
            stok = 0;
            kategoriBarang = new Kategori();
        }

        public Barang(string kodeBrg, string namaBrg, int hrgJual, int stokBarang, Kategori kategoriBrg)
        {
            kodeBarang = kodeBrg;
            namaBarang = namaBrg;
            hargaJual = hrgJual;
            stok = stokBarang;
            kategoriBarang = kategoriBrg;
        }

        #endregion
    }
}
