﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
using System.Drawing.Printing;
using PQScan.BarcodeCreator;//agar barcode bisa digunakan
using System.Drawing.Imaging;//agar imageformat bisa digunakan

namespace PenjualanPembelian_LIB
{
    public class Cetak
    {
        #region DATAMEMBER
        private Font jenisFont;
        private StreamReader fileCetak;
        float marginKiriKertas, marginKananKertas, marginAtasKertas, marginBawahKertas;

        //untuk generate barcode
        private Barcode barcodeGenerator;
        
        //menyimpan image hasil generate barcode
        private Image gambarBarcode;
        #endregion

        #region PROPERTIES
        public Font JenisFont
        {
            get { return jenisFont; }
            set { jenisFont = value; }
        }

        public StreamReader FileCetak
        {
            get { return fileCetak; }
            set { fileCetak = value; }
        }

        public float MarginKiriKertas
        {
            get { return marginKiriKertas; }
            set { marginKiriKertas = value; }
        }

        public float MarginKananKertas
        {
            get { return marginKananKertas; }
            set { marginKananKertas = value; }
        }

        public float MarginAtasKertas
        {
            get { return marginAtasKertas; }
            set { marginAtasKertas = value; }
        }

        public float MarginBawahKertas
        {
            get { return marginBawahKertas; }
            set { marginBawahKertas = value; }
        }

        public Barcode BarcodeGenerator
        {
            get { return barcodeGenerator; }
            set { barcodeGenerator = value; }
        }

        public Image GambarBarcode
        {
            get { return gambarBarcode; }
        }
        #endregion

        #region CONSTRUCTOR
        public Cetak(string namaFile)
        {
            fileCetak = new StreamReader(namaFile);
            jenisFont = new Font("Arial", 10);
            marginKiriKertas = (float)10.5;
            marginKananKertas = (float)10.5;
            marginAtasKertas = (float)10.5;
            marginBawahKertas = (float)10.5;
        }

        public Cetak(string namaFile, string namaFont, int ukuranFont, float marginKiri, float marginKanan, float marginAtas, float marginBawah)
        {
            fileCetak = new StreamReader(namaFile);
            jenisFont = new Font(namaFont, ukuranFont);
            marginKiriKertas = marginKiri;
            marginKananKertas = marginKanan;
            marginAtasKertas = marginAtas;
            marginBawahKertas = marginBawah;
        }

        //constructor untuk mencetak barcode
        public Cetak(string namaFileBarcode, string dataBarcode, int panjang, int lebar)
        {
            barcodeGenerator = new Barcode();

            //tipe barcode
            barcodeGenerator.BarType = BarCodeType.Code39;

            //barcode akan di-generate sesuai kode barang tertentu
            barcodeGenerator.Data = dataBarcode;

            //set panjang dan lebar file gambar barcode
            barcodeGenerator.Width = lebar;
            barcodeGenerator.Height = panjang;

            //atur format file barcode
            barcodeGenerator.PictureFormat = ImageFormat.Jpeg;

            //secara default file barcode akan terimpan di folder yang sama dengan file aplikasi (.exe)
            barcodeGenerator.CreateBarcode(namaFileBarcode);

            //create image dari hasil file barcode yang telah dibuat
            gambarBarcode = Image.FromFile(namaFileBarcode);

            //atur margin kertas
            marginKiriKertas = (float)10.5;
            marginKananKertas = (float)10.5;
            marginAtasKertas = (float)10.5;
            marginBawahKertas = (float)10.5;
        }
        #endregion

        #region METHOD
        private void CetakTulisan(object sender, PrintPageEventArgs e)
        {
            int jumlahBarisPerHalaman = (int)((e.MarginBounds.Height - marginBawahKertas) / jenisFont.GetHeight(e.Graphics));
            float y = marginKananKertas;
            int jumBaris = 0;

            string tulisanCetak = fileCetak.ReadLine();

            while (jumBaris < jumlahBarisPerHalaman && tulisanCetak != null)
            {
                y = marginKananKertas + (jumBaris * jenisFont.GetHeight(e.Graphics));

                e.Graphics.DrawString(tulisanCetak, jenisFont, Brushes.Black, marginKiriKertas, y);

                jumBaris++;

                tulisanCetak = fileCetak.ReadLine();
            }

            if (tulisanCetak != null)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
            }
        }

        public string CetakKePrinter()
        {
            try
            {
                PrintDocument p = new PrintDocument();
                p.PrintPage += new PrintPageEventHandler(CetakTulisan);
                p.Print();

                fileCetak.Close();

                return "sukses";
            }
            catch (Exception e)
            {
                return "Proses cetak gagal. Pesan kesalahan : " + e.Message;
            }
        }

        private void CetakBarcode(object sender, PrintPageEventArgs e)
        {
            //cetak image barcode
            e.Graphics.DrawImage(gambarBarcode, marginKiriKertas, marginAtasKertas, (float)barcodeGenerator.Width, (float)barcodeGenerator.Height);
        
        }

        public string CetakKePrinter(string tipe)
        {
            try
            {
                //buat objek untuk mencetak
                PrintDocument p = new PrintDocument();

                if (tipe == "tulisan")
                {
                    //tambahkan eventhandler untuk mencetak tulisan
                    p.PrintPage += new PrintPageEventHandler(CetakTulisan);

                }
                else if (tipe == "barcode")
                {
                    //tambahkan event handler untuk mencetak barcode
                    p.PrintPage += new PrintPageEventHandler(CetakBarcode);

                }

                //cetak tulisan
                p.Print();

                fileCetak.Close();

                return "sukses";
            }
            catch (Exception ex)
            {
                return "Proses cetak gagal. Pesan kesalahan : " + ex.Message;
            }
        }
        #endregion
    }
}
