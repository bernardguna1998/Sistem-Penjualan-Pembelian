﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Drawing;

namespace PenjualanPembelian_LIB
{
    public class DaftarBarang
    {
        #region DATAMEMBER
        //isinya class ini untuk update delete update
        private List<Barang> listBarang;
        private string kodeTerbaru;
        #endregion

        #region PROPERTIES
        public List<Barang> ListBarang
        {
            get { return listBarang; }
        }

        public string KodeTerbaru
        {
            get { return kodeTerbaru; }
        }

        public int JumlahBarang
        {
            get { return listBarang.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarBarang()
        {
            listBarang = new List<Barang>();
            kodeTerbaru = "B0001";
        }
        #endregion

        #region METHOD
        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT B.KodeBarang, B.Nama, B.HargaJual, B.Stok, K.KodeKategori, K.Nama AS Kategori "
                + "FROM barang B INNER JOIN kategori K ON B.KodeKategori = K.KodeKategori";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();
           
                while(data.Read() == true)
                {
                    string kode = data.GetValue(0).ToString();
                    string nama = data.GetValue(1).ToString();
                    int hrgJual = int.Parse(data.GetValue(2).ToString());
                    int stok = int.Parse(data.GetValue(3).ToString());
                    string kdKategori = data.GetValue(4).ToString();
                    string namaKategori = data.GetValue(5).ToString();

                    Kategori kat = new Kategori(kdKategori, namaKategori);

                    Barang brg = new Barang(kode, nama, hrgJual, stok, kat);

                    listBarang.Add(brg);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();

            string sql = "";
            
            if(kriteria == "NamaKategori")
            {
                kriteria = "Nama";

                sql = "SELECT B.KodeBarang, B.Nama, B.HargaJual, B.Stok, K.KodeKategori, K.Nama AS Kategori FROM barang B " +
                "INNER JOIN kategori K ON B.KodeKategori = K.KodeKategori WHERE K." + kriteria + " LIKE '%" + nilaiKriteria + "%'";
            }
            else
            {
                sql = "SELECT B.KodeBarang, B.Nama, B.HargaJual, B.Stok, K.KodeKategori, K.Nama AS Kategori FROM barang B " +
                "INNER JOIN kategori K ON B.KodeKategori = K.KodeKategori WHERE B." + kriteria + " LIKE '%" + nilaiKriteria + "%'";
            }
            
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    string kode = data.GetValue(0).ToString();
                    string nama = data.GetValue(1).ToString();
                    int hrgJual = int.Parse(data.GetValue(2).ToString());
                    int stok = int.Parse(data.GetValue(3).ToString());
                    string kdKategori = data.GetValue(4).ToString();
                    string namaKategori = data.GetValue(5).ToString();

                    Kategori kat = new Kategori(kdKategori, namaKategori);

                    Barang brg = new Barang(kode, nama, hrgJual, stok, kat);

                    listBarang.Add(brg);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string GenerateCode()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT SUBSTRING(KodeBarang,2,4) FROM barang ORDER BY KodeBarang DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                if(data.Read() == true)
                {
                    int kdTerbaru = int.Parse(data.GetValue(0).ToString()) + 1;
                    kodeTerbaru = kdTerbaru.ToString();

                    if(kodeTerbaru.Length == 1)
                    {
                        kodeTerbaru = "B000" + kodeTerbaru;
                    }
                    else if(kodeTerbaru.Length == 2)
                    {
                        kodeTerbaru = "B00" + kodeTerbaru;
                    }
                    else if(kodeTerbaru.Length == 3)
                    {
                        kodeTerbaru = "B0" + kodeTerbaru;
                    }
                    else
                    {
                        kodeTerbaru = "B" + kodeTerbaru;
                    }
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string TambahData(Barang brg)
        {
                Koneksi k = new Koneksi();
                k.Connect();
                //tuliskan perintah SQL yang akan dijalankan
                string sql = "INSERT INTO barang(KodeBarang, Nama, HargaJual, Stok, KodeKategori) VALUES ('" + brg.KodeBarang + "','" + brg.NamaBarang + "','" + brg.HargaJual + "','" + brg.Stok + "','" + brg.KategoriBarang.KodeKategori + "')";

                //buat Mysqlcommand
                MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);
                try
                {
                    c.ExecuteNonQuery();
                    return "sukses";
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }    
        }

        public string HapusData(Barang brg)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan

            //DELETE FROM `barang` WHERE `barang`.`KodeBarang` = \'B0005\'"
            string sql = "DELETE FROM barang WHERE barang.KodeBarang = '" + brg.KodeBarang + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string UbahData(Barang brg)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //UPDATE `barang` SET `HargaJual` = '100000', `Stok` = '506', `KodeKategori` = '03' WHERE `barang`.`KodeBarang` = 'B0001';
            //tuliskan perintah SQL yang akan dijalankan
            string sql = "UPDATE barang SET Nama = '" + brg.NamaBarang 
                + "', HargaJual = '" + brg.HargaJual + "', Stok = '" + brg.Stok 
                + "', KodeKategori = '" + brg.KategoriBarang.KodeKategori + "' WHERE barang.KodeBarang = '" + brg.KodeBarang + "'"; 
            
            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string CetakBarcode(Barang brg)
        {
            try
            {
                //cetak barcode ke printer dengan ukuran 50x100
                //hasil barcode disimpan dengan nama file 'HasilBarcode-B0001' jika kode barang B0001, dst
                Cetak c = new Cetak("HasilBarcode-" + brg.KodeBarang + ".jpg", brg.KodeBarang, 50, 100);

                c.CetakKePrinter("barcode");

                return "sukses";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        public int HitungJumlahBarang()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah_barang=0;

            string sql = "SELECT COUNT(KodeBarang) FROM barang";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah_barang = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah_barang;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion
    }
}
