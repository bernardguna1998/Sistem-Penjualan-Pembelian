﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PenjualanPembelian_LIB
{
    public class DaftarJabatan
    {
        #region DATAMEMBER
        //isinya untuk update delete update
        private List<Jabatan> listJabatan;
        private string kodeTerbaru;
        #endregion

        #region PROPERTIES
        public List<Jabatan> ListJabatan
        {
            get { return listJabatan; }
        }

        public string KodeTerbaru
        {
            get { return kodeTerbaru; }
        }

        public int JumlahJabatan
        {
            get { return listJabatan.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarJabatan()
        {
            listJabatan = new List<Jabatan>();
            kodeTerbaru = "J1";
        }
        #endregion

        #region METHOD
        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT * FROM jabatan";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    string kode = data.GetValue(0).ToString();
                    string nama = data.GetValue(1).ToString();

                    Jabatan j = new Jabatan(kode, nama);

                    listJabatan.Add(j);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT * FROM jabatan WHERE " + kriteria + " LIKE '%" + nilaiKriteria + "%'";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    string kode = data.GetValue(0).ToString();
                    string nama = data.GetValue(1).ToString();

                    Jabatan j = new Jabatan(kode, nama);

                    listJabatan.Add(j);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string GenerateCode()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT SUBSTRING(IdJabatan,2,1) FROM jabatan ORDER BY IdJabatan DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                if (data.Read() == true)
                {
                    int kdTerbaru = int.Parse(data.GetValue(0).ToString()) + 1;
                    kodeTerbaru = kdTerbaru.ToString();

                    if (kodeTerbaru.Length == 1)
                    {
                        kodeTerbaru = "J" + kodeTerbaru;
                    }
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string TambahData(Jabatan j)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "INSERT INTO jabatan(IdJabatan, Nama) VALUES ('" + j.IdJabatan + "','" + j.NamaJabatan + "')";


            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string HapusData(Jabatan j)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan

            string sql = "DELETE FROM jabatan WHERE IdJabatan = '" + j.IdJabatan + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string UbahData(Jabatan j)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "UPDATE jabatan SET Nama = '" + j.NamaJabatan + "' WHERE IdJabatan = '" + j.IdJabatan + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public int HitungJumlahJabatan()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(IdJabatan) FROM jabatan";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion
    }
}
