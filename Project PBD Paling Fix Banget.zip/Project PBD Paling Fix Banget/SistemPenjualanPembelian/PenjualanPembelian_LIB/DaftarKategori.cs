﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PenjualanPembelian_LIB
{
    public class DaftarKategori
    {
        #region DATAMEMBER
        private List<Kategori> listKategori; //menyimpan kategori yg ada d dlm tbl
        private string kodeTerakhir;
        #endregion

        #region PROPERTIES
        public List<Kategori> DaftarKategoriBarang
        {
            get { return listKategori; }
        }

        public int JumlahKategoriBarang
        {
            get { return listKategori.Count; }
        }

        public string KodeTerakhir
        {
            get { return kodeTerakhir; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarKategori()
        {
            listKategori = new List<Kategori>();
            kodeTerakhir = "01";
        }
        #endregion

        #region METHOD
        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();

            //tuliskan perintah SQL yg akan dijalankan
            string sql = "SELECT * FROM Kategori";

            //buat mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                //gunakan mysqlreader dan execute reader untuk menjalankan perintah select
                MySqlDataReader data = c.ExecuteReader();

                //selama data reader msh bs dibaca ( selama masih ada data)
                while (data.Read() == true)
                {
                    //mendapatkan kode kategori dr hsl data reader
                    string kode = data.GetValue(0).ToString(); //0, 1 itu index dr kolomnya
                    string nama = data.GetValue(1).ToString();

                    //buat object bertipe kategori
                    Kategori kt = new Kategori(kode, nama);

                    //simPn ke list
                    listKategori.Add(kt);
                }
                //hapus mysqlcommand setelah selesai spy printah yg dibawa dihapus artie hemat memori
                c.Dispose();
                data.Dispose();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT * FROM Kategori WHERE " + kriteria + " LIKE '%" + nilaiKriteria + "%'";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while( data.Read() == true)
                {
                    string kode = data.GetValue(0).ToString();
                    string nama = data.GetValue(1).ToString();

                    Kategori kt = new Kategori(kode, nama);

                    listKategori.Add(kt);
                }

                c.Dispose();

                data.Dispose();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string GenerateCode()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT KodeKategori FROM Kategori ORDER BY KodeKategori DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                if (data.Read() == true)
                {
                    int kdTerbaru = int.Parse(data.GetValue(0).ToString()) + 1;
                    kodeTerakhir = kdTerbaru.ToString();
                    if(kodeTerakhir.Length == 1 )
                    {
                        kodeTerakhir = "0" + kodeTerakhir;
                    }
                    
                }

                c.Dispose();

                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string TambahData(Kategori ket)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "INSERT INTO kategori(KodeKategori, Nama) VALUES ('" + ket.KodeKategori + "','" + ket.NamaKategori + "')";


            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }

        }

        public string UpdateData(Kategori ket)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //code update
            //UPDATE `kategori` SET `Nama` = 'Kamar' WHERE `kategori`.`KodeKategori` = '77';

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "UPDATE kategori SET Nama = '" + ket.NamaKategori + "' WHERE KodeKategori = '" + ket.KodeKategori + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string HapusData(Kategori ket)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //code update
            //UPDATE `kategori` SET `Nama` = 'Kamar' WHERE `kategori`.`KodeKategori` = '77';

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "DELETE FROM kategori WHERE KodeKategori = '" + ket.KodeKategori + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public int HitungJumlahKategori()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(KodeKategori) FROM kategori";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion
    }
}

