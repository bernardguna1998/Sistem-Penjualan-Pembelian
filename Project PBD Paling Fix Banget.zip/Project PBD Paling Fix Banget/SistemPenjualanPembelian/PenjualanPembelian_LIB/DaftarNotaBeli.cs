﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.IO;

namespace PenjualanPembelian_LIB
{
    public class DaftarNotaBeli
    {
        #region DATAMEMBER
        private List<NotaBeli> listNotaBeli;
        private string noNotaTerbaru;
        #endregion

        #region PROPERTIES
        public List<NotaBeli> ListNotaBeli
        {
            get { return listNotaBeli; }
        }

        public string NoNotaTerbaru
        {
            get { return noNotaTerbaru; }
        }

        public int JumlahNotaBeli
        {
            get { return listNotaBeli.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarNotaBeli()
        {
            listNotaBeli = new List<NotaBeli>();
            noNotaTerbaru = "20170101001";
        }
        #endregion

        #region METHOD
        public string GenerateNoNota()
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //perintah SQL : mendapatkan nomor urut transaksi terakhir di tanggal hari ini(tanggal komputer)
            string sql = "SELECT SUBSTRING(NoNota, 9, 3) AS noUrutTransaksi " + "FROM NotaBeli WHERE Date(Tanggal) = Date(CURRENT_DATE) " + "ORDER BY NoNota DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);
            try
            {
                MySqlDataReader data = c.ExecuteReader();

                string noUrutTransTerbaru = "";

                if(data.Read() == true)
                {
                    int noUrutTrans = int.Parse(data.GetValue(0).ToString()) + 1;
                    noUrutTransTerbaru = noUrutTrans.ToString();

                    if(noUrutTransTerbaru.Length == 1)
                    {
                        noUrutTransTerbaru = "00" + noUrutTransTerbaru;
                    }
                    else if(noUrutTransTerbaru.Length == 2)
                    {
                        noUrutTransTerbaru = "0" + noUrutTransTerbaru;
                    }
                }
                else
                {
                    noUrutTransTerbaru = "001";
                }

                //generate nomor nota terbaru
                //format nomor nota : yyyymmddxxx(yyyy: tahun, mm: bulan, dd, tanggal, xxx no urut transaksi di tgl tsb)
                //mendapatkan tahun dari tanggal komputer
                string tahun = DateTime.Now.Year.ToString();
                //mendapatkan bulan dari tanggal komputer
                string bulan = DateTime.Now.Month.ToString();

                if(bulan.Length == 1)
                {
                    bulan = "0" + bulan;
                }

                //mendapatkan tanggal(hari) dari tanggal komputer
                string tanggal = DateTime.Now.Day.ToString();
            
                if(tanggal.Length == 1)
                {
                    tanggal = "0" + tanggal;
                }

                //generate nomor nota terbaru sesuai format
                noNotaTerbaru = tahun + bulan + tanggal + noUrutTransTerbaru.ToString();

                c.Dispose();
                data.Dispose();
                return "sukses";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public string TambahData(NotaBeli nota)
        {
            Koneksi k1 = new Koneksi();
            k1.Connect();

            string sql1 = "INSERT INTO NotaBeli(NoNota, Tanggal, KodeSupplier, KodePegawai) VALUES ('" + nota.NoNota + "','" + nota.Tanggal.ToString("yyyy-MM-dd hh:mm:ss") + "','" + nota.Supplier.KodeSupplier + "','" + nota.Pegawai.KodePegawai + "')";
            MySqlCommand c1 = new MySqlCommand(sql1, k1.KoneksiDB);

            try
            {
                c1.ExecuteNonQuery();

                for(int i=0; i<nota.JumlahBarangNota; i++)
                {
                    Koneksi k2 = new Koneksi();
                    k2.Connect();

                    string sql2 = "INSERT INTO NotaBeliDetil(NoNota, KodeBarang, Harga, Jumlah) VALUES ('" + nota.NoNota + "','" +
                        nota.ListDetilNotaBeli[i].BarangNota.KodeBarang + "','" + nota.ListDetilNotaBeli[i].HargaJual + "','" + nota.ListDetilNotaBeli[i].JumlahBeli + "')";

                    MySqlCommand c2 = new MySqlCommand(sql2, k2.KoneksiDB);

                    c2.ExecuteNonQuery();

                    string hasilUpdateBarang = UpdateStokBarang(nota.ListDetilNotaBeli[i]);
                }

                return "sukses";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();
            k.Connect();

            string sql = "SELECT n.NoNota, n.Tanggal, n.KodeSupplier, s.Nama AS NamaSupplier, s.Alamat AS AlamatSupplier, n.KodePegawai, peg.Nama AS NamaPegawai FROM NotaBeli n INNER JOIN Supplier s ON n.KodeSupplier = s.KodeSupplier INNER JOIN Pegawai peg ON n.KodePegawai = peg.KodePegawai ORDER BY n.NoNota DESC";
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);
            try
            {
                MySqlDataReader data = c.ExecuteReader();
                while (data.Read() == true)
                {
                    string nomorNota = data.GetValue(0).ToString();

                    DateTime tglNota = DateTime.Parse(data.GetValue(1).ToString());

                    string kodeSup = data.GetValue(2).ToString();
                    string namaSup = data.GetValue(3).ToString();
                    string alamatSup = data.GetValue(4).ToString();
                    Supplier s = new Supplier();
                    s.KodeSupplier = int.Parse(kodeSup);
                    s.NamaSupplier = namaSup;
                    s.Alamat = alamatSup;

                    int kodePeg = int.Parse(data.GetValue(5).ToString());
                    string namaPeg = data.GetValue(6).ToString();
                    Pegawai peg = new Pegawai();
                    peg.KodePegawai = kodePeg;
                    peg.Nama = namaPeg;

                    List<NotaBeliDetil> listDetilNota = new List<NotaBeliDetil>();
                    Koneksi k2 = new Koneksi();
                    k2.Connect();

                    string sql2 = "SELECT  nbd.KodeBarang, b.Nama, nbd.Harga, nbd.Jumlah FROM NotaBeli n INNER JOIN NotaBeliDetil nbd ON n.NoNota=nbd.NoNota INNER JOIN Barang b ON nbd.KodeBarang=b.KodeBarang WHERE n.NoNota = '" + nomorNota + "'";

                    MySqlCommand c2 = new MySqlCommand(sql2, k2.KoneksiDB);

                    MySqlDataReader data2 = c2.ExecuteReader();
                    while (data2.Read() == true)
                    {
                        string kodeBrg = data2.GetValue(0).ToString();
                        string namaBrg = data2.GetValue(1).ToString();
                        Barang brg = new Barang();
                        brg.KodeBarang = kodeBrg;
                        brg.NamaBarang = namaBrg;

                        int hargaBeli = int.Parse(data2.GetValue(2).ToString());
                        int jumlahBeli = int.Parse(data2.GetValue(3).ToString());

                        NotaBeliDetil detilNota = new NotaBeliDetil(brg, hargaBeli, jumlahBeli);

                        listDetilNota.Add(detilNota);
                    }
                    c2.Dispose();
                    data2.Dispose();

                    NotaBeli nota = new NotaBeli(nomorNota, tglNota, s, peg, listDetilNota);

                    listNotaBeli.Add(nota);
                }
                c.Dispose();
                data.Dispose();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            string sql = "SELECT n.NoNota, n.Tanggal, n.KodeSupplier, s.Nama AS NamaSupplier, s.Alamat AS AlamatSupplier, n.KodePegawai, peg.Nama AS NamaPegawai FROM NotaBeli n INNER JOIN Supplier s ON n.KodeSupplier= s.KodeSupplier INNER JOIN Pegawai peg ON n.KodePegawai=peg.KodePegawai WHERE " + kriteria + " LIKE '%" + nilaiKriteria + "%'";
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);
            try
            {
                MySqlDataReader data = c.ExecuteReader();
                while (data.Read() == true)
                {
                    string nomorNota = data.GetValue(0).ToString();

                    DateTime tglNota = DateTime.Parse(data.GetValue(1).ToString());

                    string kodeSup = data.GetValue(2).ToString();
                    string namaSup = data.GetValue(3).ToString();
                    string alamatSup = data.GetValue(4).ToString();
                    Supplier s = new Supplier();
                    s.KodeSupplier = int.Parse(kodeSup);
                    s.NamaSupplier = namaSup;
                    s.Alamat = alamatSup;

                    int kodePeg = int.Parse(data.GetValue(5).ToString());
                    string namaPeg = data.GetValue(6).ToString();
                    Pegawai peg = new Pegawai();
                    peg.KodePegawai = kodePeg;
                    peg.Nama = namaPeg;

                    List<NotaBeliDetil> listDetilNota = new List<NotaBeliDetil>();
                    Koneksi k2 = new Koneksi();
                    k2.Connect();

                    string sql2 = "SELECT  nbd.KodeBarang, b.Nama, nbd.Harga, nbd.Jumlah FROM NotaBeli n INNER JOIN NotaBeliDetil nbd ON n.NoNota=nbd.NoNota INNER JOIN Barang b ON nbd.KodeBarang=b.KodeBarang WHERE n.NoNota = '" + nomorNota + "'";

                    MySqlCommand c2 = new MySqlCommand(sql2, k2.KoneksiDB);

                    MySqlDataReader data2 = c2.ExecuteReader();
                    while (data2.Read() == true)
                    {
                        string kodeBrg = data2.GetValue(0).ToString();
                        string namaBrg = data2.GetValue(1).ToString();
                        Barang brg = new Barang();
                        brg.KodeBarang = kodeBrg;
                        brg.NamaBarang = namaBrg;

                        int hargaBeli = int.Parse(data2.GetValue(2).ToString());
                        int jumlahBeli = int.Parse(data2.GetValue(3).ToString());

                        NotaBeliDetil detilNota = new NotaBeliDetil(brg, hargaBeli, jumlahBeli);

                        listDetilNota.Add(detilNota);
                    }
                    c2.Dispose();
                    data2.Dispose();

                    NotaBeli nota = new NotaBeli(nomorNota, tglNota, s, peg, listDetilNota);

                    listNotaBeli.Add(nota);
                }
                c.Dispose();
                data.Dispose();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string UpdateStokBarang(NotaBeliDetil detilNota)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            string sql = "";
            sql = "UPDATE barang SET stok = stok + " + detilNota.JumlahBeli + " WHERE KodeBarang = '" + detilNota.BarangNota.KodeBarang + "'";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public void CetakNota(string kriteria, string nilaiKriteria, string namaFile)
        {
            CariData(kriteria, nilaiKriteria);

            StreamWriter file = new StreamWriter(namaFile); //untuk menyimpan file nya

            for (int i = 0; i < listNotaBeli.Count; i++)
            {
                file.WriteLine("");
                file.WriteLine("SISTEM PENJUALAN PEMBELIAN TOKO ABC");
                file.WriteLine("Jl. Raya Kalirungkut Surabaya");
                file.WriteLine("Telp. (031) -  12345678");
                file.WriteLine("==================================================");

                file.WriteLine("No. Nota : " + listNotaBeli[i].NoNota);
                file.WriteLine("Tanggal : " + listNotaBeli[i].Tanggal);
                file.WriteLine("");
                file.WriteLine("Supplier : " + listNotaBeli[i].Supplier.NamaSupplier);
                file.WriteLine("Alamat : " + listNotaBeli[i].Supplier.Alamat);
                file.WriteLine("");
                file.WriteLine("Kasir : " + listNotaBeli[i].Pegawai.Nama);
                file.WriteLine("==================================================");

                int grandTotal = 0;
                for (int j = 0; j < listNotaBeli[i].JumlahBarangNota; j++)
                {
                    string nama = listNotaBeli[i].ListDetilNotaBeli[j].BarangNota.NamaBarang;

                    if (nama.Length > 30)
                    {
                        nama = nama.Substring(0, 30);
                    }

                    int jumlah = listNotaBeli[i].ListDetilNotaBeli[j].JumlahBeli;
                    int harga = listNotaBeli[i].ListDetilNotaBeli[j].HargaJual;
                    int subTotal = jumlah * harga;
                    file.Write(nama);
                    file.Write(SpasiTambahan(nama.Length, 30));
                    file.Write(jumlah);
                    file.Write(SpasiTambahan(nama.Length, 30));
                    file.Write(harga.ToString("0,###"));
                    file.Write(SpasiTambahan(nama.Length, 30));
                    file.Write(subTotal.ToString("0, ###"));
                    file.WriteLine("");
                    grandTotal = grandTotal + jumlah * harga;
                }
                file.WriteLine("==================================================");
                file.WriteLine("TOTAL : " + grandTotal.ToString("0,###"));
                file.WriteLine("==================================================");
            }
            file.Close();
            Cetak c = new Cetak(namaFile, "Courier New", 8, 10, 10, 10, 10);
            c.CetakKePrinter();
        }

        private string SpasiTambahan(int jumlahKarakterSaatIni, int jumlahKarakterMaksimal)
        {
            string spasi = "";
            for (int i = 0; i < jumlahKarakterMaksimal; i++)
            {
                spasi = spasi + " ";
            }
            return spasi;
        }

        public int HitungJumlahNotaBeli()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(notabelidetil.NoNota) FROM notabelidetil";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion
    }
}
