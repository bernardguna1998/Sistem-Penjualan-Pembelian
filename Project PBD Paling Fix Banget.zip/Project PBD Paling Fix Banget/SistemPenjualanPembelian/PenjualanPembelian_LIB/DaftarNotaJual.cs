﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.IO;

namespace PenjualanPembelian_LIB
{
    public class DaftarNotaJual
    {
        #region DATAMEMBER
        private List<NotaJual> listNotaJual;
        private string noNotaTerbaru;
        #endregion

        #region PROPERTIES
        public List<NotaJual> ListNotaJual
        {
            get { return listNotaJual; }
        }

        public string NoNotaTerbaru
        {
            get { return noNotaTerbaru; }
        }

        public int JumlahNotaJual
        {
            get { return listNotaJual.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarNotaJual()
        {
            listNotaJual = new List<NotaJual>();
            noNotaTerbaru = "20170101001";
        }
        #endregion

        #region METHOD
        public string GenerateCode()
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //perintah SQL : mendapatkan nomor urut transaksi terakhir di tanggal hari ini(tanggal komputer)
            string sql = "SELECT SUBSTRING(NoNota, 9, 3) AS noUrutTransaksi FROM NotaJual WHERE Date(Tanggal) = Date(CURRENT_DATE) ORDER BY NoNota DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);
            try
            {
                MySqlDataReader data = c.ExecuteReader();

                string noUrutTransTerbaru = "";

                if (data.Read() == true)
                {
                    int noUrutTrans = int.Parse(data.GetValue(0).ToString()) + 1;
                    
                    noUrutTransTerbaru = noUrutTrans.ToString();

                    if (noUrutTransTerbaru.Length == 1)
                    {
                        noUrutTransTerbaru = "00" + noUrutTransTerbaru;
                    }
                    else if (noUrutTransTerbaru.Length == 2)
                    {
                        noUrutTransTerbaru = "0" + noUrutTransTerbaru;
                    }
                }
                else
                {
                    noUrutTransTerbaru = "001";
                }

                //generate nomor nota terbaru
                //format nomor nota : yyyymmddxxx(yyyy: tahun, mm: bulan, dd, tanggal, xxx no urut transaksi di tgl tsb)
                //mendapatkan tahun dari tanggal komputer
                string tahun = DateTime.Now.Year.ToString();
                //mendapatkan bulan dari tanggal komputer
                string bulan = DateTime.Now.Month.ToString();

                if (bulan.Length == 1)
                {
                    bulan = "0" + bulan;
                }

                //mendapatkan tanggal(hari) dari tanggal komputer
                string tanggal = DateTime.Now.Day.ToString();

                if (tanggal.Length == 1)
                {
                    tanggal = "0" + tanggal;
                }

                //generate nomor nota terbaru sesuai format
                noNotaTerbaru = tahun + bulan + tanggal + noUrutTransTerbaru.ToString();

                c.Dispose();
                data.Dispose();
                return "sukses";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string TambahData(NotaJual nota)
        {
            Koneksi k1 = new Koneksi();
            k1.Connect();

            string sql1 = "INSERT INTO NotaJual(NoNota, Tanggal, KodePelanggan, KodePegawai) VALUES ('" + nota.NoNota + "','" + nota.Tanggal.ToString("yyyy-MM-dd hh:mm:ss") + "','" + nota.Pelanggan.KodePelanggan + "','" + nota.Pegawai.KodePegawai + "')";
            MySqlCommand c1 = new MySqlCommand(sql1, k1.KoneksiDB);

            try
            {
                c1.ExecuteNonQuery();

                for (int i = 0; i < nota.JumlahBarangNota; i++)
                {
                    
                    Koneksi k2 = new Koneksi();
                    k2.Connect();

                    string hasilUpdateBarang = UpdateStokBarang(nota.ListDetilNota[i]); 

                    if(hasilUpdateBarang == "sukses")
                    {
                        string sql2 = "INSERT INTO NotaJualDetil(NoNota, KodeBarang, Harga, Jumlah) VALUES ('" + nota.NoNota + "','" +
                        nota.ListDetilNota[i].BarangNota.KodeBarang + "','" + nota.ListDetilNota[i].HargaJual + "','" + nota.ListDetilNota[i].JumlahJual + "')";

                        MySqlCommand c2 = new MySqlCommand(sql2, k2.KoneksiDB);

                        c2.ExecuteNonQuery();
                    }
                    else
                    {
                        return hasilUpdateBarang;
                    }


                }

                return "sukses";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string UpdateStokBarang(NotaJualDetil detilNota)
        {
            try
            {
                Koneksi k = new Koneksi();
                k.Connect();

                DaftarBarang d = new DaftarBarang();
                string baca = d.BacaSemuaData();
                for(int i=0; i<d.JumlahBarang;i++)
                {
                    if(detilNota.BarangNota.KodeBarang == d.ListBarang[i].KodeBarang )
                    {
                        int stok = d.ListBarang[i].Stok;
                    }

                }

                string sql = "";

                sql = "UPDATE barang SET Stok = Stok - " + detilNota.JumlahJual +
                    " WHERE KodeBarang = '" + detilNota.BarangNota.KodeBarang+ "'";

                MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

                try
                {
                    c.ExecuteNonQuery();

                    return "sukses";
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public string BacaSemuaData()
        {
            Koneksi k1 = new Koneksi();
            k1.Connect();

            string sql = "SELECT n.NoNota, n.Tanggal, n.KodePelanggan, plg.Nama AS NamaPelanggan, plg.Alamat AS AlamatPelanggan, n.KodePegawai, peg.Nama AS NamaPegawai FROM NotaJual n INNER JOIN Pelanggan plg ON n.KodePelanggan = plg.KodePelanggan INNER JOIN Pegawai peg ON n.KodePegawai = peg.KodePegawai ORDER BY n.NoNota DESC";

            MySqlCommand c1 = new MySqlCommand(sql, k1.KoneksiDB);
            try
            {
                MySqlDataReader data1 = c1.ExecuteReader();

                while (data1.Read() == true)
                {
                    string nomorNota = data1.GetValue(0).ToString();

                    DateTime tglNota = DateTime.Parse(data1.GetValue(1).ToString());

                    string kodePlg = data1.GetValue(2).ToString();
                    string namaPlg = data1.GetValue(3).ToString();
                    string alamatPlg = data1.GetValue(4).ToString();
                    Pelanggan plg = new Pelanggan();
                    plg.KodePelanggan = int.Parse(kodePlg);
                    plg.NamaPelanggan = namaPlg;
                    plg.Alamat = alamatPlg;

                    int kodePeg = int.Parse(data1.GetValue(5).ToString());
                    string namaPeg = data1.GetValue(6).ToString();
                    Pegawai peg = new Pegawai();
                    peg.KodePegawai = kodePeg;
                    peg.Nama = namaPeg;

                    List<NotaJualDetil> listDetilNota = new List<NotaJualDetil>();

                    Koneksi k2 = new Koneksi();
                    k2.Connect();

                    string sql2 = "SELECT  njd.KodeBarang, b.Nama, njd.Harga, njd.Jumlah FROM NotaJual n INNER JOIN NotaJualDetil njd ON n.NoNota=njd.NoNota INNER JOIN Barang b ON njd.KodeBarang=b.KodeBarang WHERE n.NoNota = '" + nomorNota + "'";

                    MySqlCommand c2 = new MySqlCommand(sql2, k2.KoneksiDB);

                    MySqlDataReader data2 = c2.ExecuteReader();
                    while (data2.Read() == true)
                    {
                        string kodeBrg = data2.GetValue(0).ToString();
                        string namaBrg = data2.GetValue(1).ToString();

                        Barang brg = new Barang();
                        brg.KodeBarang = kodeBrg;
                        brg.NamaBarang = namaBrg;

                        int hrgJual = int.Parse(data2.GetValue(2).ToString());
                        int jumlahJual = int.Parse(data2.GetValue(3).ToString());

                        NotaJualDetil detilNota = new NotaJualDetil(brg, hrgJual, jumlahJual);
                        listDetilNota.Add(detilNota);
                    }
                    c2.Dispose();
                    data2.Dispose();

                    NotaJual nota = new NotaJual(nomorNota, tglNota, plg, peg, listDetilNota);

                    listNotaJual.Add(nota);
                }
                c1.Dispose();
                data1.Dispose();
                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k1 = new Koneksi();

            k1.Connect();

            string sql1 = "SELECT n.NoNota, n.Tanggal, n.KodePelanggan, plg.Nama AS NamaPelanggan, plg.Alamat AS AlamatPelanggan, n.KodePegawai, peg.Nama AS NamaPegawai FROM NotaJual n INNER JOIN Pelanggan plg ON n.KodePelanggan= plg.KodePelanggan INNER JOIN Pegawai peg ON n.KodePegawai=peg.KodePegawai WHERE " + kriteria + " LIKE '%" + nilaiKriteria + "%'";

            MySqlCommand c1 = new MySqlCommand(sql1, k1.KoneksiDB);
            try
            {
                MySqlDataReader data1 = c1.ExecuteReader();

                while (data1.Read() == true)
                {
                    string nomorNota = data1.GetValue(0).ToString();

                    DateTime tglNota = DateTime.Parse(data1.GetValue(1).ToString());

                    string kodePlg = data1.GetValue(2).ToString();
                    string namaPlg = data1.GetValue(3).ToString();
                    string alamatPlg = data1.GetValue(4).ToString();

                    Pelanggan plg = new Pelanggan();
                    plg.KodePelanggan = int.Parse(kodePlg);
                    plg.NamaPelanggan = namaPlg;
                    plg.Alamat = alamatPlg;

                    string kode = data1.GetValue(5).ToString();
                    string namaPeg = data1.GetValue(6).ToString();

                    Pegawai peg = new Pegawai();
                    peg.KodePegawai = int.Parse(kode);
                    peg.Nama = namaPeg;

                    List<NotaJualDetil> listDetilNota = new List<NotaJualDetil>();

                    Koneksi k2 = new Koneksi();
                    k2.Connect();

                    string sql2 = "SELECT  njd.KodeBarang, b.Nama, njd.Harga, njd.Jumlah FROM NotaJual n INNER JOIN NotaJualDetil njd ON n.NoNota=njd.NoNota INNER JOIN Barang b ON njd.KodeBarang=b.KodeBarang WHERE n.NoNota = '" + nomorNota + "'";

                    MySqlCommand c2 = new MySqlCommand(sql2, k2.KoneksiDB);

                    MySqlDataReader data2 = c2.ExecuteReader();
                    while (data2.Read() == true)
                    {
                        string kodeBrg = data2.GetValue(0).ToString();
                        string namaBrg = data2.GetValue(1).ToString();

                        Barang brg = new Barang();
                        brg.KodeBarang = kodeBrg;
                        brg.NamaBarang = namaBrg;

                        int hrgJual = int.Parse(data2.GetValue(2).ToString());
                        int jumlahJual = int.Parse(data2.GetValue(3).ToString());

                        NotaJualDetil detilNota = new NotaJualDetil(brg, hrgJual, jumlahJual);
                        listDetilNota.Add(detilNota);
                    }
                    c2.Dispose();
                    data2.Dispose();

                    NotaJual nota = new NotaJual(nomorNota, tglNota, plg, peg, listDetilNota);

                    listNotaJual.Add(nota);
                }
                c1.Dispose();
                data1.Dispose();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public void CetakNota(string kriteria, string nilaiKriteria, string namaFile)
        {
            CariData(kriteria, nilaiKriteria);

            StreamWriter file = new StreamWriter(namaFile); //untuk menyimpan file nya

            for (int i = 0; i < listNotaJual.Count; i++)
            {
                file.WriteLine("");
                file.WriteLine("SISTEM PENJUALAN PEMBELIAN TOKO ABC");
                file.WriteLine("Jl. Raya Kalirungkut Surabaya");
                file.WriteLine("Telp. (031) -  12345678");
                file.WriteLine("==================================================");

                file.WriteLine("No. Nota : " + listNotaJual[i].NoNota);
                file.WriteLine("Tanggal : " + listNotaJual[i].Tanggal);
                file.WriteLine("");
                file.WriteLine("Pelanggan : " + listNotaJual[i].Pelanggan.NamaPelanggan);
                file.WriteLine("Alamat : " + listNotaJual[i].Pelanggan.Alamat);
                file.WriteLine("");
                file.WriteLine("Kasir : " + listNotaJual[i].Pegawai.Nama);
                file.WriteLine("==================================================");

                int grandTotal = 0;
                for (int j = 0; j < listNotaJual[i].JumlahBarangNota; j++)
                {
                    string nama = listNotaJual[i].ListDetilNota[j].BarangNota.NamaBarang;

                    if (nama.Length > 30)
                    {
                        nama = nama.Substring(0, 30);
                    }

                    int jumlah = listNotaJual[i].ListDetilNota[j].JumlahJual;
                    int harga = listNotaJual[i].ListDetilNota[j].HargaJual;
                    int subTotal = jumlah * harga;
                    file.Write(nama);
                    file.Write(SpasiTambahan(nama.Length, 30));
                    file.Write(jumlah);
                    file.Write(SpasiTambahan(nama.Length, 30));
                    file.Write(harga.ToString("0,###"));
                    file.Write(SpasiTambahan(nama.Length, 30));
                    file.Write(subTotal.ToString("0,###"));
                    file.WriteLine("");
                    grandTotal = grandTotal + jumlah * harga;
                }
                file.WriteLine("==================================================");
                file.WriteLine("TOTAL : " + grandTotal.ToString("0,###"));
                file.WriteLine("==================================================");
                file.WriteLine("Terimakasih Atas Kunjungan Anda");
                file.WriteLine("");
            }
            file.Close();
            Cetak c = new Cetak(namaFile, "Courier New", 9, 10, 10, 10, 10);
            c.CetakKePrinter("tulisan");
        }

        private string SpasiTambahan(int jumlahKarakterSaatIni, int jumlahKarakterMaksimal)
        {
            string spasi = "";
            for (int i = 0; i < jumlahKarakterMaksimal; i++)
            {
                spasi = spasi + " ";
            }
            return spasi;
        }

        public int HitungJumlahNotaJual()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(notajualdetil.NoNota) FROM notajualdetil";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion
        }
    }

