﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PenjualanPembelian_LIB
{
    public class DaftarPegawai
    {
        #region DATAMEMBER
        //isinya untuk update delete update
        private List<Pegawai> listPegawai;
        private string kodeTerbaru;
        #endregion

        #region PROPERTIES
        public List<Pegawai> ListPegawai
        {
            get { return listPegawai; }
        }

        public string KodeTerbaru
        {
            get { return kodeTerbaru; }
        }

        public int JumlahPegawai
        {
            get { return listPegawai.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarPegawai()
        {
            listPegawai = new List<Pegawai>();
            kodeTerbaru = "1";
        }
        #endregion


        #region METHOD
        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT p.KodePegawai, p.Nama, p.TglLahir, p.Alamat, p.Gaji, p.Username, p.Password, j.IdJabatan, j.Nama FROM pegawai p, jabatan j WHERE p.IdJabatan = j.IdJabatan";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    int kode = int.Parse(data.GetValue(0).ToString());
                    string nama = data.GetValue(1).ToString();
                    string tgl = data.GetValue(2).ToString();
                    string alamat = data.GetValue(3).ToString();
                    int gaji = int.Parse(data.GetValue(4).ToString());
                    string username = data.GetValue(5).ToString();
                    string password = data.GetValue(6).ToString();
                    string idJabatan = data.GetValue(7).ToString();
                    string namaJabatan = data.GetValue(8).ToString();

                    Jabatan j = new Jabatan(idJabatan, namaJabatan);

                    Pegawai p = new Pegawai(kode, nama, DateTime.Parse(tgl), alamat, gaji, username, password, j);

                    listPegawai.Add(p);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();

            string sql = "";

            if(kriteria == "NamaJabatan")
            {
                kriteria = "Nama";

                sql = "SELECT p.KodePegawai, p.Nama, p.TglLahir, p.Alamat, p.Gaji, p.Username, p.Password, j.IdJabatan, j.Nama FROM pegawai p, jabatan j WHERE p.IdJabatan = j.IdJabatan AND j." + kriteria + " LIKE '%" + nilaiKriteria + "%'";
            }
            else
            {
                sql = "SELECT p.KodePegawai, p.Nama, p.TglLahir, p.Alamat, p.Gaji, p.Username, p.Password, j.IdJabatan, j.Nama FROM pegawai p, jabatan j WHERE p.IdJabatan = j.IdJabatan AND p." + kriteria + " LIKE '%" + nilaiKriteria + "%'";
            }

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    //UPDATE `pegawai` SET `Nama` = 'yek', `TglLahir` = '1988-07-13', `Alamat` = 'Bulak'
                    //, `Gaji` = '10', `Username` = 'une', `Password` = '098'
                    //, `IdJabatan` = 'J2' WHERE `pegawai`.`KodePegawai` = 6;

                    int kode = int.Parse(data.GetValue(0).ToString());
                    string nama = data.GetValue(1).ToString();
                    string tgl = data.GetValue(2).ToString();
                    string alamat = data.GetValue(3).ToString();
                    int gaji = int.Parse(data.GetValue(4).ToString());
                    string username = data.GetValue(5).ToString();
                    string password = data.GetValue(6).ToString();
                    string idJabatan = data.GetValue(7).ToString();
                    string namaJabatan = data.GetValue(8).ToString();

                    Jabatan j = new Jabatan(idJabatan, namaJabatan);

                    Pegawai p = new Pegawai(kode, nama, DateTime.Parse(tgl), alamat, gaji, username, password, j);

                    listPegawai.Add(p);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string GenerateCode()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT KodePegawai FROM pegawai ORDER BY KodePegawai DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                if (data.Read() == true)
                {
                    int kdTerbaru = int.Parse(data.GetValue(0).ToString()) + 1;
                    kodeTerbaru = kdTerbaru.ToString();
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string TambahData(Pegawai p)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //INSERT INTO `pegawai` (`KodePegawai`, `Nama`, `TglLahir`, `Alamat`, `Gaji`, `Username`, `Password`, `IdJabatan`) VALUES ('11', 'Yeye', '2017-10-09', 'Huh', '1000', 'hehe', 'hehe', 'J1');

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "INSERT INTO pegawai(KodePegawai, Nama, TglLahir, Alamat, Gaji, Username, Password, IdJabatan) VALUES ('" + p.KodePegawai + "','" + p.Nama + "','" + p.TanggalLahir + "','" + p.Alamat + "','" + p.Gaji + "','" + p.Username + "','" + p.Pwd + "','" + p.Jabatan.IdJabatan+ "')";


            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();

                string hasilBuatUser = BuatUserBaru(p, "localhost");
                if(hasilBuatUser == "sukses")
                {
                    string hasilBeriHak = BeriHakAkses(p, "localhost");
                    if(hasilBeriHak == "sukses")
                    {
                        return "sukses";
                    }
                    else
                    {
                        return "Gagal memberikan hak akses pada user. Pesan kesalahan = " + hasilBeriHak;
                    }
                }
                else
                {
                    return "Gagal membuat user baru. Pesan kesalahan = " + hasilBuatUser;
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string HapusData(Pegawai p)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan

            //"DELETE FROM `pegawai` WHERE `pegawai`.`KodePegawai` = 11"?
            string sql = "DELETE FROM pegawai WHERE pegawai.KodePegawai = '" + p.KodePegawai + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                string hasil = HapusUser(p, "localhost");
                if(hasil == "sukses")
                {
                    return "sukses";
                }
                else
                {
                    return "Gagal menghapus user. Pesan kesalahan = " + hasil;
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string UbahData(Pegawai p)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //UPDATE `pegawai` SET `Nama` = 'yek', `TglLahir` = '1988-07-13', `Alamat` = 'Bulak'
            //, `Gaji` = '10', `Username` = 'une', `Password` = '098'
            //, `IdJabatan` = 'J2' WHERE `pegawai`.`KodePegawai` = 6;
            //tuliskan perintah SQL yang akan dijalankan

            string sql = "UPDATE pegawai SET Nama = '" + p.Nama + "', TglLahir = '" + p.TanggalLahir + "', Alamat = '" +
                    p.Alamat + "', Gaji = '" + p.Gaji + "', Username = '" + p.Username + "', Password = '" + p.Pwd + "', IdJabatan = '" + p.Jabatan.IdJabatan +"' WHERE pegawai.KodePegawai = '" + p.KodePegawai + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();

                string hasil = UbahPassword(p, "localhost");
                if(hasil == "sukses")
                {
                    return "sukses";
                }
                else
                {
                    return "Gagal mengubah password user. Pesan kesalahan = " + hasil;
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string BuatUserBaru(Pegawai peg, string namaServer)
        {
            Koneksi k = new Koneksi();

            k.Connect();

            string sql = "CREATE USER '" + peg.Username + "'@'" + namaServer + "' IDENTIFIED BY '" + peg.Pwd + "'";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string BeriHakAkses(Pegawai peg, string namaServer)
        {
            Koneksi k = new Koneksi();

            k.Connect();
            string sql = "";

            sql = "GRANT ALL PRIVILEGES ON *.* TO '" + peg.Username + "'@'" + namaServer + "' WITH GRANT OPTION";
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        //SET PASSWORD FOR 'bernard'@'localhost'=PASSWORD('abc') 
        public string UbahPassword(Pegawai peg, string namaServer)
        {
            Koneksi k = new Koneksi();

            k.Connect();
            string sql = "";

            sql = "SET PASSWORD FOR '" + peg.Username + "'@'" + namaServer + "' =PASSWORD('" + peg.Pwd + "')";
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        //DROP USER ‘namauser’ @’namaserver’
        public string HapusUser(Pegawai peg, string namaServer)
        {
            Koneksi k = new Koneksi();

            k.Connect();
            string sql = "";

            sql = "DROP USER '" + peg.Username + "'@'" + namaServer + "'";
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public int HitungJumlahPegawai()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(KodePegawai) FROM pegawai";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion

    }
}
