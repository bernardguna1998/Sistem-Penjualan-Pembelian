﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PenjualanPembelian_LIB
{
    public class DaftarPelanggan
    {
        #region DATAMEMBER
        private List<Pelanggan> listPelanggan; //menyimpan kategori yg ada d dlm tbl
        private string kodeTerakhir;
        #endregion

        #region PROPERTIES
        public List<Pelanggan> DaftarInformasiPelanggan
        {
            get { return listPelanggan;}
        }

        public int JumlahPelanggan
        {
            get { return listPelanggan.Count; }
        }

        public string KodeTerakhir
        {
            get { return kodeTerakhir; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarPelanggan()
        {
            listPelanggan = new List<Pelanggan>();
            kodeTerakhir = "01";
        }
        #endregion

        #region METHOD
        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();

            //tuliskan perintah SQL yg akan dijalankan
            string sql = "SELECT * FROM Pelanggan";

            //buat mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                //gunakan mysqlreader dan execute reader untuk menjalankan perintah select
                MySqlDataReader data = c.ExecuteReader();

                //selama data reader msh bs dibaca ( selama masih ada data)
                while (data.Read() == true)
                {
                    //mendapatkan kode kategori dr hsl data reader
                    string kode = data.GetValue(0).ToString(); //0, 1 itu index dr kolomnya
                    string nama = data.GetValue(1).ToString();
                    string alamat = data.GetValue(2).ToString();
                    string telp = data.GetValue(3).ToString();

                    //buat object bertipe kategori
                    Pelanggan p = new Pelanggan(int.Parse(kode), nama, alamat, telp);

                    //simPn ke list
                    listPelanggan.Add(p);
                }
                //hapus mysqlcommand setelah selesai spy printah yg dibawa dihapus artie hemat memori
                c.Dispose();
                data.Dispose();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT * FROM Pelanggan WHERE " + kriteria + " LIKE '%" + nilaiKriteria + "%'";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while( data.Read() == true)
                {
                    //mendapatkan kode kategori dr hsl data reader
                    string kode = data.GetValue(0).ToString(); //0, 1 itu index dr kolomnya
                    string nama = data.GetValue(1).ToString();
                    string alamat = data.GetValue(2).ToString();
                    string telp = data.GetValue(3).ToString();

                    //buat object bertipe kategori
                    Pelanggan p = new Pelanggan(int.Parse(kode), nama, alamat, telp);

                    listPelanggan.Add(p);
                }

                c.Dispose();

                data.Dispose();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string GenerateCode()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT KodePelanggan FROM Pelanggan ORDER BY KodePelanggan DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                if (data.Read() == true)
                {
                    int kdTerbaru = int.Parse(data.GetValue(0).ToString()) + 1;
                    kodeTerakhir = kdTerbaru.ToString();
                    if(kodeTerakhir.Length == 1 )
                    {
                        kodeTerakhir = "0" + kodeTerakhir;
                    }
                    
                }

                c.Dispose();

                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string TambahData(Pelanggan p)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "INSERT INTO pelanggan(KodePelanggan, Nama, Alamat, Telepon) VALUES ('" + p.KodePelanggan + "','" + p.NamaPelanggan + "','" + p.Alamat + "','" + p.Telepon + "')";


            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }

        }

        public string UbahData(Pelanggan p)
        {
            try
            {
                Koneksi k = new Koneksi();
                string sql = "UPDATE pelanggan SET Nama='" + p.NamaPelanggan + "', Alamat= '" + p.Alamat + "', Telepon= '" + p.Telepon + "' WHERE KodePelanggan =" + p.KodePelanggan;
                MySqlCommand com = new MySqlCommand(sql, k.KoneksiDB);

                //jalankan perintah sql (INSERT/UPDATE/DELETE)
                com.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string HapusData(Pelanggan p)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //code update
            //UPDATE `kategori` SET `Nama` = 'Kamar' WHERE `kategori`.`KodeKategori` = '77';

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "DELETE FROM Pelanggan WHERE KodePelanggan = '" + p.KodePelanggan + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public int HitungJumlahPelanggan()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(pelanggan.KodePelanggan) FROM pelanggan";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }
        #endregion
    }
}
