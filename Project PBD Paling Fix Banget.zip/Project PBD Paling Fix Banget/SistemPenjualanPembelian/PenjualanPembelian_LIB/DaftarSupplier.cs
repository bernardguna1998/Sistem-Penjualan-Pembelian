﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PenjualanPembelian_LIB
{
    public class DaftarSupplier
    {
        #region DATAMEMBER
        //isinya untuk update delete update
        private List<Supplier> listSupplier;
        private int kodeTerbaru;
        #endregion

        #region PROPERTIES
        public List<Supplier> ListSupplier
        {
            get { return listSupplier; }
        }

        public int KodeTerbaru
        {
            get { return kodeTerbaru; }
        }

        public int JumlahSupplier
        {
            get { return listSupplier.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public DaftarSupplier()
        {
            listSupplier = new List<Supplier>();
            kodeTerbaru = 1;
        }
        #endregion

        #region METHOD
        public string BacaSemuaData()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT * FROM supplier";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();
           
                while(data.Read() == true)
                {
                    int kode = int.Parse(data.GetValue(0).ToString());
                    string nama = data.GetValue(1).ToString();
                    string alamat = data.GetValue(2).ToString();

                    Supplier s = new Supplier(kode, nama, alamat);

                    listSupplier.Add(s);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string CariData(string kriteria, string nilaiKriteria)
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT * FROM supplier WHERE " + kriteria + " LIKE '%" + nilaiKriteria + "%'";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    int kode = int.Parse(data.GetValue(0).ToString());
                    string nama = data.GetValue(1).ToString();
                    string alamat = data.GetValue(2).ToString();

                    Supplier s = new Supplier(kode, nama, alamat);

                    listSupplier.Add(s);
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string GenerateCode()
        {
            Koneksi k = new Koneksi();

            string sql = "SELECT KodeSupplier FROM supplier ORDER BY KodeSupplier DESC LIMIT 1";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                if(data.Read() == true)
                {
                    kodeTerbaru = int.Parse(data.GetValue(0).ToString()) + 1;
                }

                c.Dispose();
                data.Dispose();

                return "sukses";
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        public string TambahData(Supplier s)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "INSERT INTO supplier(KodeSupplier, Nama, Alamat) VALUES ('" + s.KodeSupplier + "','" + s.NamaSupplier + "','"+ s.Alamat + "')";


            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string HapusData(Supplier s)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan

            string sql = "DELETE FROM supplier WHERE KodeSupplier = '" + s.KodeSupplier + "'";

            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public string UbahData(Supplier s)
        {
            Koneksi k = new Koneksi();
            k.Connect();

            //tuliskan perintah SQL yang akan dijalankan
            string sql = "UPDATE supplier SET Nama = '" + s.NamaSupplier + "', Alamat = '" + s.Alamat + "' WHERE KodeSupplier = '" + s.KodeSupplier + "'"; 
            
            //buat Mysqlcommand
            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                c.ExecuteNonQuery();
                return "sukses";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
        public int HitungJumlahPelanggan()
        {
            Koneksi k = new Koneksi();
            k.Connect();
            int jumlah = 0;

            string sql = "SELECT COUNT(supplier.KodeSupplier) FROM supplier";

            MySqlCommand c = new MySqlCommand(sql, k.KoneksiDB);

            try
            {
                MySqlDataReader data = c.ExecuteReader();

                while (data.Read() == true)
                {
                    jumlah = int.Parse(data.GetValue(0).ToString());
                }

                c.Dispose();
                data.Dispose();

                return jumlah;
            }
            catch (Exception e)
            {
                return -1;
            }
        }

        #endregion
    }
}
