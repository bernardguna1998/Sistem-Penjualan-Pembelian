﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class Jabatan
    {
        #region DATAMEMBER
        private string idJabatan;
        private string namaJabatan;
        #endregion

        #region PROPERTIES
        public string IdJabatan
        {
            get { return idJabatan; }
            set
            {
                idJabatan = value;

                if (idJabatan == "")
                {
                    throw (new Exception("Mohon cek id jabatan anda kembali."));
                }
            }
        }

        public string NamaJabatan
        {
            get { return namaJabatan; }
            set 
            { 
                namaJabatan = value; 

                if(namaJabatan == "")
                {
                    throw (new Exception("Mohon maaf, nama jabatan tidak boleh dikosongi."));
                }
            }
        }
        #endregion

        #region CONSTRUCOR

        public Jabatan()
        {
            idJabatan = "";
            namaJabatan = "";
        }

        public Jabatan(string id, string nama)
        {
            idJabatan = id;
            namaJabatan = nama;
        }

        public Jabatan(string id)
        {
            idJabatan = id;
        }
        #endregion
    }
}
