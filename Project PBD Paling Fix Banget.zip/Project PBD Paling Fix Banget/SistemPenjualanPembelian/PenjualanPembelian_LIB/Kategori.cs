﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace PenjualanPembelian_LIB
{
    public class Kategori //class2 yg nanti nya berhuungan dg database , kalo projectnya utk menyimpan form2
    {
        #region DATAMEMEMBER
        private string kodeKategori;
        private string namaKategori;
        #endregion 

        #region PROPERTIES
        public string KodeKategori
        {
            get { return kodeKategori; }
            set
            {
                kodeKategori = value;

                if (kodeKategori == "")
                {
                    throw (new Exception("Mohon maaf, kode barang tidak boleh dikosongi."));
                }
            }
        }

        public string NamaKategori
        {
            get { return namaKategori; }
            set 
            {
                namaKategori = value;

                if (namaKategori == "")
                {
                    throw (new Exception("Mohon maaf, nama kategori tidak boleh dikosongi."));
                }
            
            }
        }
        #endregion 

        #region CONSTRUCTOR
        public Kategori()
        {
            kodeKategori = "";
            namaKategori = "";
        }

        public Kategori(string kode, string nama)
        {
            kodeKategori = kode;
            namaKategori = nama;
        }
        #endregion

        //mysql command, perintah mysql
        //execute non querry adl method dr mysqlcommand yg berguna utk insert update delete
        //execute reader adl method dr mysqlcommand yg berguna utk select

        #region METHOD
       
        #endregion
    }
}
