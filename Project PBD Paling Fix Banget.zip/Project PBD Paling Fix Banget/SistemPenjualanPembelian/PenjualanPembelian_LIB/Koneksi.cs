﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MySql.Data.MySqlClient;

using System.Configuration;

namespace PenjualanPembelian_LIB
{
    public class Koneksi //menghubungkan aplikasi dg database
    {
        #region DATAMEMBER
        private MySqlConnection koneksi;
        private string namaServer;
        private string namaDatabase;
        private string username;
        private string password;
        #endregion

        #region PROPERTIES
        public MySqlConnection KoneksiDB
        {
            get { return koneksi; }
            set { koneksi = value; }
        }

        public string NamaServer
        {
            get { return namaServer; }
            set { namaServer = value; }
        }

        public string NamaDatabase
        {
            get { return namaDatabase; }
            set { namaDatabase = value; }
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        #endregion

        #region CONSTRUCTOR

        public Koneksi()
        {
            koneksi = new MySqlConnection();

            koneksi.ConnectionString = ConfigurationManager.ConnectionStrings["KonfigurasiKoneksi"].ConnectionString;

            string hasilConnect = Connect();
        }

        public Koneksi(string server, string database, string user, string pwd)
        {
            namaServer = server;
            namaDatabase = database;
            username = user;
            password = pwd; //it can be data member or properties

            koneksi = new MySqlConnection();

            string stringKoneksi = "server=" + namaServer + "; database=" + namaDatabase + "; uid=" + username + "; pwd=" + password;

            koneksi.ConnectionString = stringKoneksi;

            string hasilConnect = Connect();

            if (hasilConnect == "sukses")
            {
                UpdateAppConfig(stringKoneksi);
            }
        }

        #endregion

        #region METHOD
        public string Connect()
        {
            try
            {
                if (koneksi.State == System.Data.ConnectionState.Open)
                {
                    koneksi.Close();
                }
                koneksi.Open();
                return "sukses";
            }

            catch(Exception e)
            {
                return e.Message;
            }
        }

        public void UpdateAppConfig(string _stringKoneksi)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);


            config.ConnectionStrings.ConnectionStrings["KonfigurasiKoneksi"].ConnectionString = _stringKoneksi;

            config.Save(ConfigurationSaveMode.Modified, true);

            ConfigurationManager.RefreshSection("connectionStrings");
        }
        #endregion
    }
}
