﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class NotaBeli
    {
        #region DATAMEMBER
        private string noNota;
        private DateTime tanggal;
        private Supplier supplier;
        private Pegawai pegawai;

        //dalam 1 nota bisa terdiri dari banyak barang
        private List<NotaBeliDetil> listDetilNotaBeli;
        #endregion

        #region PROPERTIES
        public string NoNota
        {
            get { return noNota; }
            set { noNota = value; }
        }

        public DateTime Tanggal
        {
            get { return tanggal; }
            set { tanggal = value; }
        }

        public Supplier Supplier
        {
            get { return supplier; }
            set { supplier = value; }
        }

        public Pegawai Pegawai
        {
            get { return pegawai; }
            set { pegawai = value; }
        }

        public List<NotaBeliDetil> ListDetilNotaBeli
        {
            get { return listDetilNotaBeli; }
        }

        public int JumlahBarangNota
        {
            get { return listDetilNotaBeli.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public NotaBeli()
        {
            noNota = "";
            tanggal = new DateTime();
            supplier = new Supplier();
            pegawai = new Pegawai();
            listDetilNotaBeli = new List<NotaBeliDetil>();
        }

        public NotaBeli(string nomorNota, DateTime tanggalNota, Supplier supplierNota, Pegawai pembuat, List<NotaBeliDetil> listNotaBeliDetil)
        {
            noNota = nomorNota;
            tanggal = tanggalNota;
            supplier = supplierNota;
            pegawai = pembuat;
            listDetilNotaBeli = listNotaBeliDetil;
        }

        #endregion
    }
}
