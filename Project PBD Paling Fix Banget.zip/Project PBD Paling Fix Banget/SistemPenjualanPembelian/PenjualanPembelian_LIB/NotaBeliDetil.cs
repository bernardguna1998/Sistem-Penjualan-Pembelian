﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class NotaBeliDetil
    {
        #region DATAMEMBER
        private Barang barangNota;
        private int hargaJual;
        private int jumlahJual;
        #endregion

        #region PROPERTIES
        public Barang BarangNota
        {
            get { return barangNota; }
            set { barangNota = value; }
        }

        public int HargaJual
        {
            get { return hargaJual; }
            set { hargaJual = value; }
        }

        public int JumlahBeli
        {
            get { return jumlahJual; }
            set { jumlahJual = value; }
        }
        #endregion

        #region CONSTRUCTOR
        public NotaBeliDetil()
        {
            barangNota = new Barang();
            hargaJual = 0;
            jumlahJual = 0;
        }

        public NotaBeliDetil(Barang barang, int harga, int jumlah)
        {
            barangNota = barang;
            hargaJual = harga;
            jumlahJual = jumlah;
        }
        #endregion
    }
}
