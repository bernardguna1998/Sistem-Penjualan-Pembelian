﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class NotaJual
    {
        #region DATAMEMBER
        private string noNota;
        private DateTime tanggal;
        private Pelanggan pelanggan;
        private Pegawai pegawai;

        //dalam 1 nota bisa terdiri dari banyak barang
        private List<NotaJualDetil> listDetilNota;
        #endregion

        #region PROPERTIES
        public string NoNota
        {
            get { return noNota; }
            set { noNota = value; }
        }

        public DateTime Tanggal
        {
            get { return tanggal; }
            set { tanggal = value; }
        }

        public Pelanggan Pelanggan
        {
            get { return pelanggan; }
            set { pelanggan = value; }
        }

        public Pegawai Pegawai
        {
            get { return pegawai; }
            set { pegawai = value; }
        }

        public List<NotaJualDetil> ListDetilNota
        {
            get { return listDetilNota; }
        }

        public int JumlahBarangNota
        {
            get { return listDetilNota.Count; }
        }
        #endregion

        #region CONSTRUCTOR
        public NotaJual()
        {
            noNota = "";
            tanggal = new DateTime();
            pelanggan = new Pelanggan();
            pegawai = new Pegawai();
            listDetilNota = new List<NotaJualDetil>();
        }

        public NotaJual(string nomorNota, DateTime tanggalNota, Pelanggan pelangganNota, Pegawai pembuat, List<NotaJualDetil> listNotaJualDetil)
        {
            noNota = nomorNota;
            tanggal = tanggalNota;
            pelanggan = pelangganNota;
            pegawai = pembuat;
            listDetilNota = listNotaJualDetil;
        }

        #endregion

    }
}
