﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class Pegawai
    {
        #region DATAMEMBER
        private int kodePegawai;
        private string nama;
        private DateTime tanggalLhr;
        private string alamat;
        private int gaji;
        private string username;
        private string pwd;
        private Jabatan jabatan;
        #endregion

        #region PROPERTIES
        public int KodePegawai
        {
            get { return kodePegawai; }
            set
            {
                kodePegawai = value;
            }
        }

        public string Nama
        {
            get { return nama; }
            set
            {
                nama = value;

                if (nama == "")
                {
                    throw (new Exception("Mohon maaf, nama pegawai tidak boleh dikosongi."));
                }
            }
        }

        public DateTime TanggalLhr
        {
            get { return tanggalLhr; }
            set 
            { 
                tanggalLhr = value; 
            }
        }

        public string TanggalLahir
        {
            get { return tanggalLhr.ToString("yyyy-MM-dd"); } //convert tipe DateTime ke String
        }

        public string Alamat
        {
            get { return alamat; }
            set
            {
                alamat = value;

                if (alamat == "")
                {
                    throw (new Exception("Mohon maaf, alamat pegawai tidak boleh dikosongi."));
                }
            }
        }

        public int Gaji
        {
            get { return gaji; }
            set 
            { 
                gaji = value; 

                if(gaji>0)
                {
                    gaji = value;
                }
                else if(gaji <=0)
                {
                    throw (new Exception("Mohon maaf, gaji tidak boleh nol atau negatif."));
                }
            }
        }

        public string Username
        {
            get { return username; }
            set 
            { 
                username = value;

                if (username == "")
                {
                    throw (new Exception("Mohon maaf, username pegawai tidak boleh dikosongi."));
                }
            }
        }

        public string Pwd
        {
            get { return pwd; }
            set 
            {
                pwd = value;

                if (pwd == "")
                {
                    throw (new Exception("Mohon maaf, password pegawai tidak boleh dikosongi."));
                }
            }
        }

        public Jabatan Jabatan
        {
            get { return jabatan; }
            set { jabatan = value; }
        }
        #endregion

        #region CONSTRUCTOR
        public Pegawai()
        {
            kodePegawai = 0;
            nama = "";
            tanggalLhr = DateTime.Now;
            alamat = "";
            gaji = 0;
            username = "";
            pwd = "";
            jabatan = new Jabatan();
        }

        public Pegawai(int kod, string name, DateTime tgl, string address, int salary, string user, string pass, Jabatan jab)
        {
            kodePegawai = kod;
            nama = name;
            tanggalLhr = tgl;
            alamat = address;
            gaji = salary;
            username = user;
            pwd = pass;
            jabatan = jab;
        }
        #endregion
    }
}
