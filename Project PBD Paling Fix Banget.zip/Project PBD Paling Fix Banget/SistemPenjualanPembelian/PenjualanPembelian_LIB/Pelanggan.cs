﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace PenjualanPembelian_LIB
{
    public class Pelanggan
    {
        #region DATAMEMEMBER
        private int kodePelanggan;
        private string namaPelanggan;
        private string alamat;
        private string telepon;
        #endregion

        #region PROPERTIES
        public int KodePelanggan
        {
            get { return kodePelanggan; }
            set { kodePelanggan = value; }
        }

        public string NamaPelanggan
        {
            get { return namaPelanggan; }
            set 
            {
                namaPelanggan = value;

                if (namaPelanggan == "")
                {
                    throw (new Exception("Mohon maaf, nama pelanggan tidak boleh dikosongi."));
                }
            }
        }

        public string Alamat
        {
            get { return alamat; }
            set
            {
                alamat = value;

                if (alamat == "")
                {
                    throw (new Exception("Mohon maaf, alamat tidak boleh dikosongi."));
                }
            }
        }

        public string Telepon
        {
            get { return telepon; }
            set
            {
                telepon = value;

                if (telepon == "") 
                {
                    throw (new Exception("Mohon maaf, telepon tidak boleh dikosongi."));
                }
            }
        }
        #endregion

        #region CONSTRUCTOR
        public Pelanggan()
        {
            kodePelanggan = 0;
            namaPelanggan = "";
            alamat = "";
            telepon = "";
        }

        public Pelanggan(int kode_pelanggan, string nama_pelanggan, string alamat_, string telp)
        {
            kodePelanggan = kode_pelanggan;
            namaPelanggan = nama_pelanggan;
            alamat = alamat_;
            telepon = telp;
        }

        public Pelanggan(int kode_pelanggan, string nama_pelanggan)
        {
            kodePelanggan = kode_pelanggan;
            namaPelanggan = nama_pelanggan;
        }
        #endregion
        }
    }
