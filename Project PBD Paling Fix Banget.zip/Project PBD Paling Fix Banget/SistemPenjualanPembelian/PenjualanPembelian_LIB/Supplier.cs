﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenjualanPembelian_LIB
{
    public class Supplier
    {
        #region DATAMEMEMBER
        private int kodeSupplier;
        private string namaSupplier;
        private string alamat;
        #endregion

        #region PROPERTIES
        public int KodeSupplier
        {
            get { return kodeSupplier; }
            set 
            { 
                kodeSupplier = value;

                if (kodeSupplier.ToString() == "")
                {
                    throw (new Exception("Kode Supplier tidak boleh dikosongi."));
                }
                else
                {
                    kodeSupplier = value;
                }
            }
        }

        public string NamaSupplier
        {
            get { return namaSupplier; }
            set 
            { 
                namaSupplier = value;

                if (namaSupplier == "")
                {
                    throw (new Exception("Nama Supplier tidak boleh dikosongi."));
                }
                else
                {
                    namaSupplier = value;
                }
            }
        }

        public string Alamat
        {
            get { return alamat; }
            set 
            { 
                alamat = value; 

                if(alamat == "")
                {
                    throw (new Exception("Alamat Supplier tidak boleh dikosongi."));
                }
                else
                {
                    alamat = value;
                }
            }
        }
        #endregion

        #region CONSTRUCTOR
        public Supplier()
        {
            kodeSupplier = 0;
            namaSupplier = "";
            alamat = "";
        }

        public Supplier(int kode_supplier, string nama_supplier, string alamat_)
        {
            kodeSupplier = kode_supplier;
            namaSupplier = nama_supplier;
            alamat = alamat_;
        }
        #endregion
    }
}
